# Django Q Setup Guide

## 1. Install

```bash
pip install django-q2 croniter
# Remove APScheduler (no longer needed):
pip uninstall apscheduler -y
```

## 2. Add to INSTALLED_APPS (settings.py)

```python
INSTALLED_APPS = [
    ...
    'django_q',
    'healthcheck',
    ...
]
```

## 3. Django Q Configuration (settings.py)

Add this block to your settings.py:

```python
# ── Django Q (task queue) ──────────────────────────────────────────────────
Q_CLUSTER = {
    'name': 'healthcheck',
    'workers': 4,               # number of parallel task workers
    'recycle': 500,             # recycle worker after N tasks (memory safety)
    'timeout': 7200,            # task hard timeout in seconds (2 hours)
    'retry': 7260,              # retry timeout (slightly > timeout)
    'compress': False,
    'save_limit': 500,          # keep last N finished tasks in DB
    'queue_limit': 50,
    'cpu_affinity': 1,
    'label': 'HC Tasks',
    'orm': 'default',           # use Django's default DB as broker
    # For Redis broker (optional, better performance):
    # 'redis': 'redis://localhost:6379',
}
```

## 4. Run database migrations (creates Django Q tables)

```bash
python manage.py migrate
```

## 5. Start the worker (keep this running in production)

```bash
python manage.py qcluster
```

In production (e.g. systemd service):

```ini
[Unit]
Description=Django Q Cluster - Healthcheck
After=network.target

[Service]
WorkingDirectory=/path/to/project
ExecStart=/path/to/venv/bin/python manage.py qcluster
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

## 6. Start the Django web server (unchanged)

```bash
python manage.py runserver
# or: gunicorn project.wsgi
```

## How it works

```
AppConfig.ready()
    └── start_scheduler()
            ├── _register_jobs()           → creates Django Q ONCE schedules in DB
            ├── refresh_schedules (CRON)   → re-registers every 5 min
            └── rerun_queue_poller (CRON)  → polls rerun_queue every 1 min

qcluster worker (separate process)
    ├── picks up ONCE schedules → calls _chain_run()
    │       ├── creates execution_run in DB
    │       ├── registers NEXT ONCE schedule (chain continues)
    │       └── calls _execute_run() → RunLauncher
    └── picks up CRON schedules → refresh_schedules, rerun_queue_poller
```

## Scheduler UI

- **Schedules Registered** badge = Django Q Schedule rows exist in DB
- **Worker Online** badge = qcluster process is running and accepting tasks
- Both must be green for scheduled runs to fire automatically.

## Cron expression → exact interval (preserved from v10)

User input `start_at=04:08`, cron `*/10 * * * *`:
- Fires at 04:08, 04:18, 04:28, 04:38 ... (exact +10 min from start_at)
- NOT clock-anchored (04:10, 04:20 ...) — interval is preserved

## Admin: Run Now

Immediately queues an `async_task` via Django Q.
Falls back to threading if the broker is unavailable.

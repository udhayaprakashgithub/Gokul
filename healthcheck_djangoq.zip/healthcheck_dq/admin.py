"""
healthcheck/admin.py
Full Django admin for all HC tables.
Bootstrap-style admin via django-jazzmin or vanilla admin with custom CSS.
"""
from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse
from healthcheck.models import (
    Customer, Environment, Server, OracleDatabase,
    TestCatalog, TestOverride, MailConfig, MailRecipient,
    MailTemplate, SystemConfig, EscalationConfig, Schedule,
    ExecutionRun, EnvRunStatus, ExecutionLog, ServerCheckResult,
    DBCheckResult, TablespaceUsage, RMANBackupDetail,
    IssueTracker, AlertHistory, RerunQueue, RunStepLog,
)

_DB = "healthcheck_db"


class HCAdmin(admin.ModelAdmin):
    """Base admin that reads/writes to healthcheck_db."""

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)

    def save_model(self, request, obj, form, change):
        obj.save(using=_DB)

    def delete_model(self, request, obj):
        obj.delete(using=_DB)

    def delete_queryset(self, request, queryset):
        queryset.using(_DB).delete()


# ──────────────────────────────────────────────────────────────
# Customer & related
# ──────────────────────────────────────────────────────────────

class EnvironmentInline(admin.TabularInline):
    model   = Environment
    extra   = 1
    fields  = ["env_type", "server_user", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


class ServerInline(admin.TabularInline):
    model   = Server
    extra   = 1
    fields  = ["server_role", "server_name", "host", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


@admin.register(Customer)
class CustomerAdmin(HCAdmin):
    list_display    = ["name", "code", "tenant_type", "is_active", "created_at"]
    list_filter     = ["is_active", "tenant_type"]
    search_fields   = ["name", "code"]
    inlines         = [EnvironmentInline]
    list_editable   = ["is_active"]


@admin.register(Environment)
class EnvironmentAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "server_user", "is_active"]
    list_filter   = ["env_type", "is_active"]
    search_fields = ["customer__name", "server_user"]
    inlines       = [ServerInline]

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields["server_pwd"].help_text = (
            "AES-256 encrypted. Use 'python manage.py encrypt_password' "
            "to encrypt a plain password.")
        return form


@admin.register(Server)
class ServerAdmin(HCAdmin):
    list_display   = ["server_name", "server_role", "host", "is_active"]
    list_filter    = ["server_role", "is_active"]
    search_fields  = ["server_name", "host"]


@admin.register(OracleDatabase)
class OracleDatabaseAdmin(HCAdmin):
    list_display   = ["db_name", "db_type", "server", "port", "is_active"]
    list_filter    = ["db_type", "is_active"]
    search_fields  = ["db_name"]


# ──────────────────────────────────────────────────────────────
# Test catalog
# ──────────────────────────────────────────────────────────────

@admin.register(TestCatalog)
class TestCatalogAdmin(HCAdmin):
    list_display  = ["id", "test_name", "category", "server_role", "db_type", "is_active"]
    list_filter   = ["category", "server_role", "db_type", "is_active"]
    list_editable = ["is_active"]
    ordering      = ["display_order"]


@admin.register(TestOverride)
class TestOverrideAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "test_catalog", "is_active", "reason"]
    list_filter   = ["is_active", "env_type"]
    search_fields = ["customer__name", "test_catalog__test_name"]


# ──────────────────────────────────────────────────────────────
# Mail config
# ──────────────────────────────────────────────────────────────

@admin.register(MailConfig)
class MailConfigAdmin(HCAdmin):
    list_display  = ["config_name", "smtp_host", "smtp_port", "from_address", "is_active"]
    list_editable = ["is_active"]


@admin.register(MailRecipient)
class MailRecipientAdmin(HCAdmin):
    list_display  = ["alert_type", "customer", "to_addresses_short", "is_active"]
    list_filter   = ["alert_type", "is_active"]

    def to_addresses_short(self, obj):
        return obj.to_addresses[:60]
    to_addresses_short.short_description = "TO Addresses"


@admin.register(MailTemplate)
class MailTemplateAdmin(HCAdmin):
    list_display  = ["template_key", "subject_template", "is_active"]
    list_editable = ["is_active"]


# ──────────────────────────────────────────────────────────────
# System config
# ──────────────────────────────────────────────────────────────

@admin.register(SystemConfig)
class SystemConfigAdmin(HCAdmin):
    list_display  = ["config_key", "config_value_short", "config_group"]
    list_filter   = ["config_group"]
    search_fields = ["config_key"]

    def config_value_short(self, obj):
        return obj.config_value[:60]
    config_value_short.short_description = "Value"


# ──────────────────────────────────────────────────────────────
# Escalation
# ──────────────────────────────────────────────────────────────

@admin.register(EscalationConfig)
class EscalationConfigAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "threshold", "interval_hours",
                     "is_paused", "paused_until"]
    list_filter   = ["is_paused", "env_type"]
    list_editable = ["is_paused"]


# ──────────────────────────────────────────────────────────────
# Schedules
# ──────────────────────────────────────────────────────────────

# ── IST-aware widget for start_at ────────────────────────────────────────
class ISTDateTimeLocalWidget(forms.DateTimeInput):
    """
    HTML5 datetime-local picker. User picks IST date+time visually.
    Backend converts IST → UTC for DB storage.
    """
    input_type = "datetime-local"

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("format", "%Y-%m-%dT%H:%M")
        kwargs.setdefault("attrs", {})
        kwargs["attrs"].update({
            "style": "width:240px",
            "title": "Pick date & time in IST (Asia/Kolkata). System converts to UTC.",
        })
        super().__init__(*args, **kwargs)

    def format_value(self, value):
        """Show the stored UTC value as IST in the picker."""
        if value is None:
            return ""
        # value may be a datetime or a string
        if hasattr(value, "strftime"):
            from healthcheck.ist_utils import utc_to_ist
            ist_val = utc_to_ist(value)
            return ist_val.strftime("%Y-%m-%dT%H:%M")
        return str(value)


class ScheduleAdminForm(forms.ModelForm):
    ENV_TYPE_CHOICES = [
        ("PRD",         "PRD — Production"),
        ("VAL",         "VAL — Validation"),
        ("DEV",         "DEV — Development"),
        ("PRD,VAL",     "PRD, VAL — Production + Validation"),
        ("PRD,VAL,DEV", "PRD, VAL, DEV — All Environments"),
    ]

    CRON_PRESETS = [
        ("",             "── Custom (edit below) ──"),
        ("*/5 * * * *",  "Every 5 minutes"),
        ("*/10 * * * *", "Every 10 minutes"),
        ("*/15 * * * *", "Every 15 minutes"),
        ("*/30 * * * *", "Every 30 minutes"),
        ("0 */1 * * *",  "Every 1 hour"),
        ("0 */2 * * *",  "Every 2 hours"),
        ("0 */4 * * *",  "Every 4 hours"),
        ("0 */6 * * *",  "Every 6 hours"),
        ("0 */12 * * *", "Every 12 hours"),
        ("0 0 * * *",    "Daily at midnight IST"),
        ("0 6 * * *",    "Daily at 6:00 AM IST"),
        ("0 8 * * *",    "Daily at 8:00 AM IST"),
        ("0 18 * * *",   "Daily at 6:00 PM IST"),
        ("0 8 * * 1-5",  "Weekdays at 8:00 AM IST"),
        ("0 0 * * 0",    "Weekly — Sunday midnight IST"),
    ]

    env_types = forms.ChoiceField(
        choices=ENV_TYPE_CHOICES,
        label="Environment(s)",
        help_text="Select which environment(s) this schedule will run against.",
    )

    cron_preset = forms.ChoiceField(
        choices=CRON_PRESETS,
        required=False,
        label="Cron Preset",
        help_text="Choose a preset to fill the cron expression, or type your own below.",
        widget=forms.Select(attrs={
            "onchange": (
                "var v=this.value;"
                "if(v){var f=document.getElementById('id_cron_expression');"
                "if(f){f.value=v;}}"
            ),
            "style": "width:320px",
        }),
    )

    start_at = forms.DateTimeField(
        required=False,
        widget=ISTDateTimeLocalWidget(),
        help_text=(
            "<strong style='color:#1565C0'>Pick date &amp; time in IST "
            "(Asia/Kolkata).</strong><br>"
            "Example: 2026-05-01 16:43 = 4:43 PM IST.<br>"
            "Leave blank → fires at very next cron tick after scheduler start."
        ),
        label="Start At (IST)",
        input_formats=["%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"],
    )

    class Meta:
        model  = Schedule
        fields = '__all__'
        widgets = {
            "cron_expression": forms.TextInput(attrs={
                "style": "width:280px; font-family:monospace",
                "placeholder": "e.g. 0 8 * * 1-5  (weekdays 8AM IST)",
                "id": "id_cron_expression",
            }),
            "schedule_name": forms.TextInput(attrs={"style": "width:350px"}),
            "notes": forms.TextInput(attrs={"style": "width:400px"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # If editing existing row, make env_types selectable even if not in list
        if self.instance and self.instance.pk and self.instance.env_types:
            existing = self.instance.env_types
            choices = [c[0] for c in self.ENV_TYPE_CHOICES]
            if existing not in choices:
                self.fields["env_types"].choices = (
                    self.ENV_TYPE_CHOICES + [(existing, existing)]
                )

    def clean_start_at(self):
        """Accept IST datetime-local input → convert to UTC for DB storage."""
        dt = self.cleaned_data.get('start_at')
        if dt is None:
            return None
        from datetime import timedelta
        IST_OFFSET = timedelta(hours=5, minutes=30)
        if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
            return dt  # already tz-aware → Django stores as UTC
        # Naive → treat as IST → subtract 5:30 → naive UTC
        return dt - IST_OFFSET


@admin.register(Schedule)
class ScheduleAdmin(HCAdmin):
    form = ScheduleAdminForm
    list_display  = ["schedule_name", "customer", "env_types",
                     "cron_expression", "start_at_ist", "is_active",
                     "last_run_ist", "next_run_ist"]
    list_filter   = ["is_active"]
    list_editable = ["is_active"]
    search_fields = ["schedule_name", "customer__name"]
    readonly_fields = ["last_run_ist", "next_run_ist", "start_at_ist",
                       "created_at", "updated_at"]

    def _ist(self, dt):
        if dt is None: return "—"
        try:
            from zoneinfo import ZoneInfo
            from datetime import timedelta
            if hasattr(dt,'tzinfo') and dt.tzinfo:
                v = dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
            else:
                v = dt + timedelta(hours=5, minutes=30)
            return v.strftime("%d-%b-%Y %I:%M %p IST")
        except Exception:
            return str(dt)

    def start_at_ist(self, obj):
        return self._ist(obj.start_at)
    start_at_ist.short_description = "Start At (IST)"

    def last_run_ist(self, obj):
        return self._ist(obj.last_run_at)
    last_run_ist.short_description = "Last Run (IST)"

    def next_run_ist(self, obj):
        return self._ist(obj.next_run_at)
    next_run_ist.short_description = "Next Run (IST)"

    def save_model(self, request, obj, form, change):
        """
        When start_at or cron_expression changes on an existing schedule,
        reschedule the Django Q ONCE trigger so it fires at the new time.

        ROOT-CAUSE FIX for MySQL error 1205 (Lock wait timeout):
        ─────────────────────────────────────────────────────────
        Django admin wraps save_model in a transaction on healthcheck_db.
        That transaction holds an InnoDB row-lock on the schedules row from
        the moment super().save_model() issues its UPDATE until the
        transaction commits. Meanwhile the background scheduler (_chain_run)
        runs its own pymysql connection and tries to UPDATE the same
        schedules row (last_run_at / next_run_at). That UPDATE blocks waiting
        for Django's lock — if the admin save takes longer than
        innodb_lock_wait_timeout it raises MySQL error 1205.

        Three-part fix applied here:
          1. Pre-read old values with a *separate autocommit connection* that
             is closed BEFORE super().save_model() opens the Django transaction.
             Autocommit=True means no row-lock is acquired during the read.
          2. All reschedule work is deferred via transaction.on_commit() so it
             runs only AFTER Django's transaction commits and releases its lock.
          3. on_commit uses using="healthcheck_db" to bind to the correct DB
             connection (not the default SQLite), ensuring the callback fires
             after the right transaction commits.
        See also:
          - settings.py  → ATOMIC_REQUESTS=False, innodb_lock_wait_timeout=15
          - db_manager.py → pymysql timeout raised to 30s, READ-COMMITTED
        """
        import logging as _log
        _logger = _log.getLogger("hc.admin")

        old_start_at = None
        old_cron = None

        if change and obj.pk:
            # Pre-read using a raw autocommit connection so no shared lock is
            # held when Django's write transaction starts. Using DBManager()
            # here would also work, but it uses autocommit=False internally,
            # which in some MySQL versions still acquires a brief shared lock
            # during SELECT on InnoDB; a plain autocommit connection is safer.
            try:
                import pymysql
                import pymysql.cursors
                from healthcheck.engine.core.config import DB_CONFIG
                cfg = DB_CONFIG
                _raw = pymysql.connect(
                    host=cfg.host, port=cfg.port,
                    user=cfg.user, password=cfg.password,
                    database=cfg.name, charset="utf8mb4",
                    cursorclass=pymysql.cursors.DictCursor,
                    autocommit=True,
                    connect_timeout=5,
                    init_command=(
                        "SET innodb_lock_wait_timeout=5, "
                        "transaction_isolation='READ-COMMITTED'"
                    ),
                )
                try:
                    with _raw.cursor() as _cur:
                        _cur.execute(
                            "SELECT start_at, cron_expression "
                            "FROM schedules WHERE id=%s",
                            (obj.pk,))
                        row = _cur.fetchone()
                    if row:
                        old_start_at = row["start_at"]
                        old_cron     = row["cron_expression"]
                finally:
                    _raw.close()   # connection fully closed before Django's UPDATE
            except Exception as _exc:
                _logger.warning(
                    f"[ScheduleAdmin] pre-read failed (non-fatal): {_exc}")

        # Django ORM write — begins (or joins) Django's DB transaction
        super().save_model(request, obj, form, change)

        # Normalise start_at for comparison (strip tzinfo added by Django forms)
        def _strip(dt):
            if dt is None:
                return None
            return dt.replace(tzinfo=None) if getattr(dt, "tzinfo", None) else dt

        start_at_changed = change and (_strip(old_start_at) != _strip(obj.start_at))
        cron_changed     = change and (old_cron != obj.cron_expression)

        if start_at_changed or cron_changed:
            # Defer reschedule until AFTER Django commits and releases the lock.
            # using="healthcheck_db" binds on_commit to the MySQL connection,
            # not the default SQLite connection — critical for correctness.
            from django.db import transaction as _dj_tx
            schedule_id = obj.pk

            def _do_reschedule():
                try:
                    from healthcheck.scheduler_service import reschedule_after_start_at_update
                    ok = reschedule_after_start_at_update(schedule_id)
                    if not ok:
                        _logger.warning(
                            f"[ScheduleAdmin] reschedule [{schedule_id}]: "
                            "scheduler not running — change will take effect "
                            "on next scheduler restart.")
                    else:
                        _logger.info(
                            f"[ScheduleAdmin] reschedule [{schedule_id}] OK "
                            f"(start_at_changed={start_at_changed}, "
                            f"cron_changed={cron_changed})")
                except Exception as exc:
                    _logger.error(
                        f"[ScheduleAdmin] reschedule [{schedule_id}] error: {exc}",
                        exc_info=True)

            _dj_tx.on_commit(_do_reschedule, using="healthcheck_db")

    def get_fieldsets(self, request, obj=None):
        return [
            ("Schedule Info", {
                "fields": ["schedule_name", "customer", "env_types"],
                "description": (
                    "<em>Select the environment(s) from the dropdown above.</em>"
                ),
            }),
            ("Timing", {
                "fields": ["cron_preset", "cron_expression", "start_at"],
                "description": (
                    "<strong>Cron Preset</strong>: choose a common interval — "
                    "it auto-fills the Cron Expression field.<br>"
                    "<strong>Cron Expression</strong>: fine-tune manually if needed "
                    "(format: <code>minute hour day month weekday</code> in IST).<br>"
                    "<strong>Start At</strong>: pick the first execution time (IST). "
                    "Leave blank to fire at the next cron tick immediately.<br>"
                    "<em>Changing Start At on an existing schedule reschedules from the new time.</em>"
                ),
            }),
            ("Status", {
                "fields": ["is_active", "notes"],
            }),
            ("Timestamps (IST display — read only)", {
                "fields": ["start_at_ist", "last_run_ist", "next_run_ist"],
                "classes": ["collapse"],
            }),
        ]


# ──────────────────────────────────────────────────────────────
# Execution runs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionRun)
class ExecutionRunAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "run_type", "status_badge",
                     "triggered_by", "started_at", "duration_display", "latest_step"]
    list_filter   = ["status", "run_type"]
    search_fields = ["customer__name"]
    readonly_fields = ["started_at", "completed_at", "error_summary", "latest_step"]
    ordering      = ["-id"]

    def status_badge(self, obj):
        colors = {
            "COMPLETED": "success", "FAILED": "danger",
            "PARTIAL": "warning", "IN_PROGRESS": "info",
            "PENDING": "secondary",
        }
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"

    def duration_display(self, obj):
        s = obj.duration_seconds()
        return f"{s}s" if s is not None else "—"
    duration_display.short_description = "Duration"


# ──────────────────────────────────────────────────────────────
# Logs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionLog)
class ExecutionLogAdmin(HCAdmin):
    list_display   = ["logged_at", "run_id", "log_level", "py_file", "py_function", "message_short"]
    list_filter    = ["log_level"]
    search_fields  = ["message", "py_file", "py_function"]
    readonly_fields = ["run", "logged_at", "py_file", "py_module",
                       "py_function", "py_line", "message"]

    def message_short(self, obj):
        return obj.message[:80]
    message_short.short_description = "Message"


# ──────────────────────────────────────────────────────────────
# Check results
# ──────────────────────────────────────────────────────────────

@admin.register(ServerCheckResult)
class ServerCheckResultAdmin(HCAdmin):
    list_display   = ["id", "server", "connection_ok", "disk_space_action",
                      "win_update_action", "checked_at"]
    list_filter    = ["connection_ok"]
    readonly_fields = [f.name for f in ServerCheckResult._meta.fields]


@admin.register(DBCheckResult)
class DBCheckResultAdmin(HCAdmin):
    list_display   = ["id", "oracle_db", "connection_ok", "tablespace_action",
                      "rman_action", "checked_at"]
    list_filter    = ["connection_ok", "rman_action"]
    readonly_fields = [f.name for f in DBCheckResult._meta.fields]


@admin.register(TablespaceUsage)
class TablespaceUsageAdmin(HCAdmin):
    list_display  = ["tablespace_name", "used_pct", "used_space_kb", "total_space_kb"]
    list_filter   = []
    search_fields = ["tablespace_name"]


@admin.register(RMANBackupDetail)
class RMANBackupDetailAdmin(HCAdmin):
    list_display  = ["start_time", "end_time", "backup_type", "status"]


# ──────────────────────────────────────────────────────────────
# Issue tracker
# ──────────────────────────────────────────────────────────────

@admin.register(IssueTracker)
class IssueTrackerAdmin(HCAdmin):
    list_display   = ["customer", "env_type", "test_catalog", "consecutive_failures",
                      "total_failures", "status_badge", "last_escalation_at"]
    list_filter    = ["status", "env_type"]
    search_fields  = ["customer__name", "test_catalog__test_name"]

    def status_badge(self, obj):
        colors = {"OPEN": "warning", "ESCALATED": "danger", "RESOLVED": "success"}
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Alert history
# ──────────────────────────────────────────────────────────────

@admin.register(AlertHistory)
class AlertHistoryAdmin(HCAdmin):
    list_display   = ["sent_at", "alert_type", "customer_name", "env_type",
                      "subject_short", "send_status_badge"]
    list_filter    = ["alert_type", "send_status"]
    search_fields  = ["subject", "customer_name"]
    readonly_fields = [f.name for f in AlertHistory._meta.fields]

    def subject_short(self, obj):
        return obj.subject[:60]
    subject_short.short_description = "Subject"

    def send_status_badge(self, obj):
        c = "success" if obj.send_status == "SENT" else "danger"
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.send_status)
    send_status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Rerun queue
# ──────────────────────────────────────────────────────────────

@admin.register(RerunQueue)
class RerunQueueAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "attempt_number",
                     "max_attempts", "status", "scheduled_at"]
    list_filter   = ["status"]


# ──────────────────────────────────────────────────────────────
# Run step log
# ──────────────────────────────────────────────────────────────

@admin.register(RunStepLog)
class RunStepLogAdmin(HCAdmin):
    list_display   = ["run_id", "step_order", "step_name", "status",
                      "started_at", "completed_at", "duration_ms"]
    list_filter    = ["status"]
    readonly_fields = [f.name for f in RunStepLog._meta.fields]


@admin.register(EnvRunStatus)
class EnvRunStatusAdmin(HCAdmin):
    list_display   = ["run_id", "customer", "env_type", "status",
                      "started_at", "completed_at"]
    list_filter    = ["status", "env_type"]
    readonly_fields = [f.name for f in EnvRunStatus._meta.fields]


# ── SchedulerTracker ──
from healthcheck.models import SchedulerTracker

@admin.register(SchedulerTracker)
class SchedulerTrackerAdmin(admin.ModelAdmin):
    list_display  = ("id", "customer", "env_types", "schedule_name", "status",
                     "scheduled_fire_at", "last_run_at", "next_run_at",
                     "run_id", "is_active", "triggered_by")
    list_filter   = ("status", "is_active", "customer")
    search_fields = ("schedule_name", "customer__name", "env_types")
    readonly_fields = ("created_at", "updated_at")
    ordering      = ("-scheduled_fire_at",)
    using         = "healthcheck_db"

    def get_queryset(self, request):
        return super().get_queryset(request).using("healthcheck_db")

    def save_model(self, request, obj, form, change):
        obj.save(using="healthcheck_db")

"""
scheduling/run_launcher.py  (v7 - full fix)
============================================
Fixes:
  - ALWAYS queues rerun on ANY failure (exception, kill, DB loss, manual)
  - Failure email ALWAYS sent even when run is killed mid-way
  - _queue_rerun: correct attempt counting (current >= mx check)
  - _queue_rerun: writes EXHAUSTED to rerun_queue with error reason
  - _queue_rerun: stores fail_reason in rerun_queue.last_error
  - DB loss during run: caught, run marked FAILED, rerun queued
"""
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from core.config import ConfigLoader, AppConfig
from core.db_manager import DBManager
from core.executor import HealthCheckExecutor
from core.issue_tracker import IssueTrackerService
from core.logger import RunLogger
from reports.excel_generator import ExcelReportGenerator
from notifications.email_service import EmailService

_TOTAL_STEPS = 6


class RunLauncher:
    def __init__(self, db: DBManager, run_id: int, cfg: AppConfig):
        self.db     = db
        self.run_id = run_id
        self.cfg    = cfg
        self._step_failures: List[Dict] = []

    # ──────────────────────────────────────────────────────────
    # Step log helpers
    # ──────────────────────────────────────────────────────────

    def _step_start(self, order: int, name: str) -> int:
        try:
            row_id = self.db.insert_get_id(
                """INSERT INTO run_step_log
                   (run_id, step_name, step_order, status, started_at)
                   VALUES (%s, %s, %s, 'RUNNING', NOW(3))""",
                (self.run_id, name, order))
            self.db.execute(
                "UPDATE execution_runs SET latest_step=%s WHERE id=%s",
                (f"[{order}/{_TOTAL_STEPS}] {name} — RUNNING", self.run_id))
            return row_id
        except Exception:
            return 0

    def _step_end(self, row_id: int, order: int, name: str,
                  status: str = "COMPLETED", notes: str = ""):
        try:
            self.db.execute(
                """UPDATE run_step_log
                   SET status=%s, completed_at=NOW(3),
                       duration_ms=TIMESTAMPDIFF(MICROSECOND, started_at, NOW(3)) DIV 1000,
                       notes=%s
                   WHERE id=%s""",
                (status, notes[:2000] if notes else None, row_id))
            self.db.execute(
                "UPDATE execution_runs SET latest_step=%s WHERE id=%s",
                (f"[{order}/{_TOTAL_STEPS}] {name} — {status}", self.run_id))
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # LAUNCH — never raises, always ensures rerun + email on failure
    # ──────────────────────────────────────────────────────────

    def launch(self):
        """Execute a run end-to-end. ALWAYS queues rerun on any failure."""
        run = self.db.fetch_one(
            "SELECT * FROM execution_runs WHERE id=%s", (self.run_id,))
        if not run:
            return

        customer_id = run["customer_id"]
        env_types   = [e.strip() for e in run["env_types"].split(",")]

        logger = RunLogger(
            run_id=self.run_id,
            log_dir=self.cfg.log_output_path,
            db=self.db,
            customer_id=customer_id)

        customer = self.db.fetch_one(
            "SELECT * FROM customers WHERE id=%s", (customer_id,))
        cname = customer["name"] if customer else str(customer_id)

        logger.section(
            f"Run #{self.run_id}  |  {cname}  |  {run['env_types']}  |  {run['run_type']}")

        email_svc    = EmailService(self.db, logger)
        final_status = "FAILED"
        has_action   = False
        fail_reason  = ""

        # Mark run as IN_PROGRESS so stuck-run watcher can detect kills
        try:
            self.db.execute(
                "UPDATE execution_runs SET status='IN_PROGRESS', started_at=NOW() WHERE id=%s",
                (self.run_id,))
        except Exception:
            pass

        try:
            # ── Step 1: Execute health checks ─────────────────────────
            step_id = self._step_start(1, "Health Checks")
            logger.step(1, _TOTAL_STEPS, "Executing health checks")
            try:
                executor     = HealthCheckExecutor(self.db, self.run_id, logger)
                final_status = executor.run()
                logger.info(f"Health check executor status: {final_status}")
                self._step_end(step_id, 1, "Health Checks", "COMPLETED",
                               f"Final status: {final_status}")
            except Exception as exc:
                fail_reason = f"Health Checks failed: {exc}"
                self._step_end(step_id, 1, "Health Checks", "FAILED", str(exc))
                self._step_failures.append({"step": "Health Checks", "reason": str(exc)})
                raise

            # ── Step 2: Issue tracking ─────────────────────────────────
            step_id = self._step_start(2, "Issue Tracking")
            logger.step(2, _TOTAL_STEPS, f"Running issue tracker ({len(env_types)} env(s))")
            issue_errors = []
            issue_svc = IssueTrackerService(self.db)
            for env_type in env_types:
                try:
                    issue_svc.process_run_results(
                        self.run_id, customer_id, env_type, logger)
                except Exception as exc:
                    issue_errors.append(f"{env_type}: {exc}")
                    logger.error(f"Issue tracking failed for {env_type}: {exc}")
            # ── Send resolved mail if enabled ──────────────────────
            try:
                for env_type in env_types:
                    resolved = issue_svc.get_resolved_this_run()
                    env_resolved = [r for r in resolved if r["env_type"] == env_type]
                    if env_resolved:
                        esc_cfg = self.db.fetch_one(
                            "SELECT send_resolved_mail, env_mail_enabled "
                            "FROM escalation_config "
                            "WHERE customer_id=%s AND env_type=%s",
                            (customer_id, env_type))
                        if (esc_cfg and
                                esc_cfg.get("send_resolved_mail") and
                                esc_cfg.get("env_mail_enabled", True)):
                            email_svc.send_resolved(
                                run_id=self.run_id,
                                customer_id=customer_id,
                                customer_name=cname,
                                env_type=env_type,
                                resolved_issues=env_resolved)
            except Exception as exc:
                logger.warning(f"Resolved mail failed: {exc}")

            if issue_errors:
                self._step_end(step_id, 2, "Issue Tracking", "FAILED",
                               "; ".join(issue_errors))
                self._step_failures.append(
                    {"step": "Issue Tracking", "reason": "; ".join(issue_errors)})
            else:
                self._step_end(step_id, 2, "Issue Tracking", "COMPLETED")

            # ── Step 3: Escalation check ───────────────────────────────
            step_id = self._step_start(3, "Escalation Check")
            logger.step(3, _TOTAL_STEPS, "Checking escalations")
            esc_errors = []
            for env_type in env_types:
                esc_cfg = self.db.fetch_one(
                    "SELECT * FROM escalation_config WHERE customer_id=%s AND env_type=%s",
                    (customer_id, env_type))

                # Respect pause
                if esc_cfg and esc_cfg["is_paused"]:
                    paused_until = esc_cfg["paused_until"]
                    if paused_until is None or datetime.now() < paused_until:
                        logger.info(
                            f"Escalation paused for {cname}/{env_type} — skipping")
                        continue
                    else:
                        self.db.execute(
                            "UPDATE escalation_config SET is_paused=0,paused_until=NULL WHERE id=%s",
                            (esc_cfg["id"],))
                        logger.info(f"Escalation auto-resumed for {cname}/{env_type}")

                interval  = esc_cfg["interval_hours"] if esc_cfg else 168
                threshold = esc_cfg["threshold"]      if esc_cfg else 1

                # Pass threshold to both calls for correct filtering
                escalated  = issue_svc.get_escalated_issues(customer_id, env_type,
                                                             threshold=threshold)
                due_issues = [
                    i for i in escalated
                    if issue_svc.should_send_escalation(i, interval, threshold=threshold)
                ]

                if due_issues:
                    max_consec = max(i["consecutive_failures"] for i in due_issues)
                    logger.warning(
                        f"Escalation: {len(due_issues)} issue(s) in {env_type}, "
                        f"max consecutive={max_consec} threshold={threshold}")
                    try:
                        email_svc.send_escalation(
                            customer_id=customer_id, customer_name=cname,
                            env_type=env_type, issues=due_issues,
                            escalation_count=max_consec)
                        for iss in due_issues:
                            issue_svc.mark_escalated(iss["id"])
                    except Exception as exc:
                        esc_errors.append(f"{env_type}: {exc}")
                        logger.error(f"Escalation email failed for {env_type}: {exc}")

            if esc_errors:
                self._step_end(step_id, 3, "Escalation Check", "FAILED",
                               "; ".join(esc_errors))
            else:
                self._step_end(step_id, 3, "Escalation Check", "COMPLETED")

            # ── Step 4: Excel report ───────────────────────────────────
            excel_path  = None
            email_title = cname
            if final_status in ("COMPLETED", "PARTIAL"):
                step_id = self._step_start(4, "Excel Generation")
                logger.step(4, _TOTAL_STEPS, "Generating Excel report")
                try:
                    gen = ExcelReportGenerator(self.db, self.run_id, logger)
                    excel_path, email_title = gen.generate()
                    has_action = email_title.startswith("Action Required -")
                    self._step_end(step_id, 4, "Excel Generation", "COMPLETED",
                                   f"File: {excel_path}")
                except Exception as exc:
                    self._step_end(step_id, 4, "Excel Generation", "FAILED", str(exc))
                    self._step_failures.append(
                        {"step": "Excel Generation", "reason": str(exc)})
                    logger.error(f"Excel generation failed: {exc}")
            else:
                step_id = self._step_start(4, "Excel Generation")
                self._step_end(step_id, 4, "Excel Generation", "SKIPPED",
                               f"Run status was {final_status}")
                logger.step(4, _TOTAL_STEPS, "Excel skipped (run did not complete)")

            # ── Step 5: Send emails ────────────────────────────────────
            step_id = self._step_start(5, "Email Notifications")
            logger.step(5, _TOTAL_STEPS, "Sending email notifications")
            env_types_str = run["env_types"]
            env_labels = ", ".join(
                {"PRD": "Production", "VAL": "Validation",
                 "DEV": "Development"}.get(e, e) for e in env_types)
            email_errors = []

            if final_status in ("COMPLETED", "PARTIAL"):
                try:
                    email_svc.send_success(
                        run_id=self.run_id, customer_id=customer_id,
                        customer_name=cname, env_label=env_labels,
                        report_title=email_title, excel_path=excel_path,
                        env_types=env_types_str,
                        triggered_by=run.get("triggered_by", "system"),
                        has_action=has_action,
                        step_failures=self._step_failures)
                except Exception as exc:
                    email_errors.append(f"SUCCESS: {exc}")
                    logger.error(f"Success email failed: {exc}")

            if final_status in ("FAILED", "PARTIAL"):
                for env_type in env_types:
                    try:
                        email_svc.send_failure(
                            run_id=self.run_id, customer_id=customer_id,
                            customer_name=cname, env_type=env_type,
                            error_message=(
                                f"Run #{self.run_id} status: {final_status}. "
                                f"Check execution_logs for details."),
                            triggered_by=run.get("triggered_by", "system"),
                            step_failures=self._step_failures)
                    except Exception as exc:
                        email_errors.append(f"FAILURE/{env_type}: {exc}")
                        logger.error(f"Failure email failed for {env_type}: {exc}")

            if email_errors:
                self._step_end(step_id, 5, "Email Notifications", "FAILED",
                               "; ".join(email_errors))
                self._step_failures.append(
                    {"step": "Email Notifications", "reason": "; ".join(email_errors)})
            else:
                self._step_end(step_id, 5, "Email Notifications", "COMPLETED")

            # ── Step 6: Queue rerun ────────────────────────────────────
            step_id = self._step_start(6, "Rerun Queue")
            logger.step(6, _TOTAL_STEPS, "Queuing rerun if needed")
            if final_status in ("FAILED", "PARTIAL"):
                fail_reason = f"Run status: {final_status}. Steps: {[f['step'] for f in self._step_failures]}"
                self._queue_rerun(customer_id, env_types_str, cname,
                                  logger, email_svc, fail_reason)
                self._step_end(step_id, 6, "Rerun Queue", "COMPLETED",
                               "Rerun queued or exhausted")
            else:
                self._step_end(step_id, 6, "Rerun Queue", "SKIPPED",
                               f"Run status: {final_status}")

        except Exception as exc:
            tb      = traceback.format_exc()
            fail_reason = f"{exc}\n{tb}"[:2000]
            logger.critical(f"Run #{self.run_id} ABORTED: {exc}\n{tb}")

            # Mark run FAILED
            try:
                self.db.execute(
                    "UPDATE execution_runs SET status='FAILED',error_summary=%s,"
                    "completed_at=NOW() WHERE id=%s",
                    (fail_reason[:2000], self.run_id))
            except Exception:
                pass

            # ALWAYS send failure email even on crash/kill
            try:
                for et in env_types:
                    email_svc.send_failure(
                        run_id=self.run_id, customer_id=customer_id,
                        customer_name=cname, env_type=et,
                        error_message=str(exc),
                        step_failures=self._step_failures)
            except Exception:
                pass

            # ALWAYS queue rerun even on crash
            try:
                self._queue_rerun(customer_id, env_types_str, cname,
                                  logger, email_svc, str(exc)[:500])
            except Exception as qe:
                logger.error(f"Failed to queue rerun after crash: {qe}")

        finally:
            try:
                logger.info(f"Run #{self.run_id} finished — status: {final_status}")
                logger.flush()
                logger.close()
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────
    # Rerun queue — fixed attempt counting + EXHAUSTED status
    # ──────────────────────────────────────────────────────────

    def _queue_rerun(self, customer_id: int, env_types: str,
                     cname: str, logger, email_svc, fail_reason: str = ""):
        """
        FIXED: Update the rerun_queue row that launched THIS run, then
        insert the NEXT pending attempt if retries remain.

        Key insight:
          - When view fires a manual rerun, it inserts a rerun_queue row with
            original_run_id = the ORIGINAL failed run id, status = IN_PROGRESS.
          - THIS execution_run's rerun_attempt = N, rerun_of_run_id = original.
          - We must UPDATE that row (original_run_id + attempt_number match).
          - Then INSERT next attempt row if current < max_attempts.
        """
        run = self.db.fetch_one(
            "SELECT rerun_attempt, rerun_of_run_id, status FROM execution_runs WHERE id=%s",
            (self.run_id,))
        current     = int(run["rerun_attempt"]) if run else 0
        orig_run_id = (run["rerun_of_run_id"]
                       if (run and run["rerun_of_run_id"]) else self.run_id)
        mx          = self.cfg.rerun_max_attempts

        final_row = self.db.fetch_one(
            "SELECT status FROM execution_runs WHERE id=%s", (self.run_id,))
        is_success = final_row and final_row["status"] in ("COMPLETED", "PARTIAL")

        if is_success:
            close_status = "COMPLETED"
        elif current >= mx:
            close_status = "EXHAUSTED"
        else:
            close_status = "FAILED"

        # ── Close the IN_PROGRESS queue row for THIS run ─────────────
        try:
            updated = self.db.execute(
                """UPDATE rerun_queue
                   SET status=%s, completed_at=NOW(), last_error=%s
                   WHERE original_run_id=%s
                     AND attempt_number=%s
                     AND status IN ('IN_PROGRESS','PENDING')""",
                (close_status,
                 (fail_reason[:2000] if fail_reason else None),
                 orig_run_id, current))
            if not updated:
                # fallback: close any open row for this original run
                self.db.execute(
                    """UPDATE rerun_queue
                       SET status=%s, completed_at=NOW(), last_error=%s
                       WHERE original_run_id=%s
                         AND status='IN_PROGRESS'""",
                    (close_status,
                     (fail_reason[:2000] if fail_reason else None),
                     orig_run_id))
            logger.info(
                f"Rerun queue closed: orig_run={orig_run_id} "
                f"attempt={current} → {close_status}")
        except Exception as exc:
            logger.error(f"Failed to close rerun_queue row: {exc}")

        if is_success:
            return

        # ── EXHAUSTED — notify and stop ───────────────────────────────
        if current >= mx:
            logger.warning(
                f"All reruns exhausted ({mx}) for original run #{orig_run_id} "
                f"— {cname}/{env_types}")
            try:
                ecs = self.db.fetch_all(
                    "SELECT notify_rerun_fail FROM escalation_config "
                    "WHERE customer_id=%s", (customer_id,))
                if any(e["notify_rerun_fail"] for e in ecs) if ecs else True:
                    email_svc.send_rerun_exhausted(
                        run_id=orig_run_id, customer_id=customer_id,
                        customer_name=cname, env_types=env_types,
                        max_attempts=mx)
            except Exception as exc:
                logger.error(f"Rerun exhausted email failed: {exc}")
            return

        # ── QUEUE NEXT ATTEMPT ────────────────────────────────────────
        nxt = current + 1
        already = self.db.fetch_one(
            "SELECT id FROM rerun_queue "
            "WHERE original_run_id=%s AND attempt_number=%s "
            "  AND status IN ('PENDING','IN_PROGRESS')",
            (orig_run_id, nxt))
        if already:
            logger.info(
                f"Next rerun attempt {nxt} already queued (rq_id={already['id']})")
            return

        # Always read rerun_interval_hours fresh from DB (bypasses cache)
        # so changes to system_config take effect immediately without restart.
        try:
            iv_row = self.db.fetch_one(
                "SELECT config_value FROM system_config "
                "WHERE config_key='rerun_interval_hours'")
            interval_hours = float(iv_row["config_value"]) if iv_row else self.cfg.rerun_interval_hours
        except Exception:
            interval_hours = self.cfg.rerun_interval_hours

        from datetime import timedelta as _td
        sched = datetime.utcnow() + _td(hours=interval_hours)
        new_rq_id = self.db.insert_get_id(
            """INSERT INTO rerun_queue
               (original_run_id, customer_id, env_types,
                attempt_number, max_attempts, status, scheduled_at, last_error)
               VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s)""",
            (orig_run_id, customer_id, env_types,
             nxt, mx, sched, fail_reason[:2000]))

        mins = round(interval_hours * 60, 1)
        logger.info(
            f"Rerun queued: attempt {nxt}/{mx} at "
            f"{sched.strftime('%Y-%m-%d %H:%M')} UTC "
            f"(+{mins} min | rq_id={new_rq_id})")


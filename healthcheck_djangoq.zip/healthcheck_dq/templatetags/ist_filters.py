"""
healthcheck/templatetags/ist_filters.py
========================================
Template filters for IST 12-hour format display.
Usage in templates:
  {% load ist_filters %}
  {{ schedule.last_run_at|ist }}        → 27-Apr-2026 04:43 PM IST
  {{ schedule.start_at|ist_full }}      → 27-Apr-2026 04:43:21 PM IST
  {{ run.started_at|ist }}
"""
from django import template
from datetime import timedelta

register = template.Library()

_IST_OFFSET = timedelta(hours=5, minutes=30)


def _to_ist(dt):
    if dt is None:
        return None
    try:
        from zoneinfo import ZoneInfo
        if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
            return dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
        return dt + _IST_OFFSET
    except Exception:
        if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
            return dt.replace(tzinfo=None) + _IST_OFFSET
        return dt + _IST_OFFSET


@register.filter(name="ist")
def ist_filter(dt):
    """Convert UTC datetime → IST 12-hour format: 27-Apr-2026 04:43 PM"""
    v = _to_ist(dt)
    if v is None:
        return "—"
    return v.strftime("%d-%b-%Y %I:%M %p")


@register.filter(name="ist_full")
def ist_full_filter(dt):
    """Convert UTC datetime → IST 12-hour with seconds: 27-Apr-2026 04:43:21 PM"""
    v = _to_ist(dt)
    if v is None:
        return "—"
    return v.strftime("%d-%b-%Y %I:%M:%S %p")


@register.filter(name="ist_time")
def ist_time_filter(dt):
    """Time only: 04:43 PM IST"""
    v = _to_ist(dt)
    if v is None:
        return "—"
    return v.strftime("%I:%M %p IST")


@register.filter(name="ist_date")
def ist_date_filter(dt):
    """Date only: 27-Apr-2026"""
    v = _to_ist(dt)
    if v is None:
        return "—"
    return v.strftime("%d-%b-%Y")


@register.filter
def get_item(dictionary, key):
    """Template filter to access dict by variable key: {{ my_dict|get_item:key }}"""
    if not dictionary:
        return None
    return dictionary.get(key)

"""
healthcheck/engine_bridge.py
=============================
Single place that sets up sys.path and provides all engine imports for Django.

The engine lives at  healthcheck/engine/
Engine uses flat imports: from core.config import ... 
So we add  healthcheck/engine/  to sys.path.

ALL Django code (views.py, scheduler_service.py) imports from here,
never directly from 'engine.xxx'.

DB config bridge:
  Django settings has healthcheck_db with the real host/port/name.
  We push those settings into the engine's env vars so DBManager
  picks up the correct connection automatically.
"""
import os
import sys


def _setup_engine_path():
    """Add healthcheck/engine to sys.path exactly once."""
    engine_dir = os.path.join(os.path.dirname(__file__), "engine")
    if engine_dir not in sys.path:
        sys.path.insert(0, engine_dir)


def _sync_db_config():
    """
    Copy Django's healthcheck_db settings into the HC_DB_* env vars
    so the engine's DBManager uses the same connection as Django.
    Only runs when Django settings are available.
    """
    try:
        from django.conf import settings
        db = settings.DATABASES.get("healthcheck_db", {})
        if db.get("HOST") and not os.environ.get("_HC_DB_SYNCED"):
            os.environ.setdefault("HC_DB_HOST",     db["HOST"])
            os.environ.setdefault("HC_DB_PORT",     str(db.get("PORT", "3306")))
            os.environ.setdefault("HC_DB_NAME",     db["NAME"])
            os.environ.setdefault("HC_DB_USER",     db["USER"])
            os.environ.setdefault("HC_DB_PASSWORD", db["PASSWORD"])
            os.environ["_HC_DB_SYNCED"] = "1"
    except Exception:
        pass  # Outside Django context - env vars must be set manually


def get_engine():
    """
    Returns a dict of all engine classes needed by Django code.
    Call once at the start of any view / service function.

    Usage:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            ...
    """
    _setup_engine_path()
    _sync_db_config()

    from core.db_manager import DBManager                       # noqa
    from core.config import ConfigLoader, DB_CONFIG             # noqa
    from core.logger import RunLogger, SilentLogger             # noqa
    from core.executor import HealthCheckExecutor               # noqa
    from core.issue_tracker import IssueTrackerService          # noqa
    from reports.excel_generator import ExcelReportGenerator    # noqa
    from scheduling.run_launcher import RunLauncher             # noqa
    from utils.crypto import encrypt_password, decrypt_password # noqa

    return {
        "DBManager":             DBManager,
        "ConfigLoader":          ConfigLoader,
        "DB_CONFIG":             DB_CONFIG,
        "RunLogger":             RunLogger,
        "SilentLogger":          SilentLogger,
        "HealthCheckExecutor":   HealthCheckExecutor,
        "IssueTrackerService":   IssueTrackerService,
        "ExcelReportGenerator":  ExcelReportGenerator,
        "RunLauncher":           RunLauncher,
        "encrypt_password":      encrypt_password,
        "decrypt_password":      decrypt_password,
    }


# Convenience: call setup immediately on import
_setup_engine_path()
_sync_db_config()

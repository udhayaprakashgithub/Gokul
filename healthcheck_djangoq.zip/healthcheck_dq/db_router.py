"""
Routes all models in the 'healthcheck' app's HC tables to healthcheck_db.
Django auth/session/admin models stay on default (SQLite).
"""

HC_MODELS = {
    # app_label -> use healthcheck_db
    "healthcheck_hc",  # we use this app_label for all HC models
}


class HCRouter:
    """
    Route healthcheck HC models to the healthcheck_db database.
    All other models (auth, sessions, admin) use the default DB.
    """

    def db_for_read(self, model, **hints):
        if getattr(model, "_hc_db", False):
            return "healthcheck_db"
        return None

    def db_for_write(self, model, **hints):
        if getattr(model, "_hc_db", False):
            return "healthcheck_db"
        return None

    def allow_relation(self, obj1, obj2, **hints):
        hc1 = getattr(obj1.__class__, "_hc_db", False)
        hc2 = getattr(obj2.__class__, "_hc_db", False)
        if hc1 and hc2:
            return True
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        # HC models: never migrate (managed=False, tables exist in hc_v5)
        if db == "healthcheck_db":
            return False
        # Django internal models: only migrate on default
        return True

import os
import logging
from django.apps import AppConfig

logger = logging.getLogger("hc.scheduler")


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """
        Called once when Django starts.
        Registers all HC schedules as Django Q Schedule objects in the DB.

        Guard against double-start:
        - Django's dev runserver spawns a *reloader* parent and a *worker* child.
          The child sets RUN_MAIN=true; we only register in the child.
        - In production (gunicorn/uwsgi) RUN_MAIN is absent, so we register always.
        - manage.py commands (migrate, shell, etc.) skip registration via
          DJANGO_MANAGEMENT_COMMAND=1.

        NOTE: This only creates Django Q Schedule DB rows.
        Actual task execution requires a running qcluster process:
            python manage.py qcluster
        """
        # Skip in management commands (migrate, collectstatic, shell, ...)
        if os.environ.get("DJANGO_MANAGEMENT_COMMAND") == "1":
            return

        import sys
        is_runserver = "runserver" in " ".join(sys.argv)
        run_main = os.environ.get("RUN_MAIN")

        # Dev reloader parent - skip
        if is_runserver and run_main != "true":
            return

        # Skip in qcluster worker itself (it imports Django but should not
        # re-register schedules on every worker spawn)
        if "qcluster" in " ".join(sys.argv):
            return

        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
            logger.info(
                "[HealthcheckConfig.ready] Django Q schedules registered. "
                "Start worker with: python manage.py qcluster")
        except Exception as e:
            logger.warning(f"Could not register Django Q schedules on startup: {e}")

"""
healthcheck/scheduler_service.py  (v11 – Django Q)
===================================================
APScheduler replaced with Django Q for fully async task scheduling.

ARCHITECTURE:
  - All HC scheduled jobs are stored as Django Q Schedule objects (in DB)
  - The self-scheduling DateTrigger chain is preserved:
      Schedule(ONCE) -> _chain_run(N)
          -> executes run
          -> creates next Schedule(ONCE) at (last_run + interval)
          -> _chain_run(N+1)  ...
  - start_at / next_run_at / last_run_at semantics identical to v10

DEPLOYMENT:
  python manage.py qcluster          # start Django Q worker - keep running

TIMEZONE: All inputs IST -> stored UTC -> displayed IST 12-hour.
"""
import logging
import threading
from datetime import datetime, timedelta, timezone as _dtz
from typing import Optional

logger = logging.getLogger("hc.scheduler")

_active_runs: dict = {}
_active_runs_lock = threading.Lock()

IST_OFFSET = timedelta(hours=5, minutes=30)

_scheduler_started = False
_scheduler_lock = threading.Lock()


# IST / UTC helpers
def _now_utc() -> datetime:
    return datetime.utcnow()


def _now_ist() -> datetime:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
    except Exception:
        return datetime.utcnow() + IST_OFFSET


def _utc_to_ist(dt: datetime) -> datetime:
    if dt is None:
        return None
    try:
        from zoneinfo import ZoneInfo
        if hasattr(dt, 'tzinfo') and dt.tzinfo:
            return dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
        return dt + IST_OFFSET
    except Exception:
        if hasattr(dt, 'tzinfo') and dt.tzinfo:
            return dt.replace(tzinfo=None) + IST_OFFSET
        return dt + IST_OFFSET


def _ist_to_utc(dt: datetime) -> datetime:
    if dt is None:
        return None
    if hasattr(dt, 'tzinfo') and dt.tzinfo:
        return dt.astimezone(_dtz.utc).replace(tzinfo=None)
    return dt - IST_OFFSET


def _strip_tz(dt: datetime) -> Optional[datetime]:
    if dt is None:
        return None
    return dt.replace(tzinfo=None) if (hasattr(dt, 'tzinfo') and dt.tzinfo) else dt


def _fmt(dt: datetime) -> str:
    if dt is None:
        return "Never"
    return _utc_to_ist(_strip_tz(dt)).strftime("%d-%b-%Y %I:%M %p IST")


def _cron_to_timedelta(cron_expr: str) -> timedelta:
    """Convert cron expression to timedelta interval using croniter."""
    try:
        from croniter import croniter
        base = datetime(2026, 1, 1, 0, 0, 0)
        ci = croniter(cron_expr, base)
        t1 = ci.get_next(datetime)
        t2 = ci.get_next(datetime)
        delta = t2 - t1
        if delta.total_seconds() < 60:
            logger.warning(f"Cron '{cron_expr}' interval < 60s - using 60s minimum")
            return timedelta(minutes=1)
        return delta
    except Exception as exc:
        logger.error(f"Cannot parse cron '{cron_expr}': {exc}. Defaulting to 1 hour.")
        return timedelta(hours=1)


def _db_err():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError:
        pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError:
        pass
    return types


def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


# Tracker helpers
def _update_tracker(db, tid: int, **kw):
    if not kw or not tid:
        return
    try:
        db.execute(
            "UPDATE scheduler_tracker SET " +
            ", ".join(f"{k}=%s" for k in kw) +
            ", updated_at=NOW() WHERE id=%s",
            list(kw.values()) + [tid])
    except Exception as e:
        logger.warning(f"tracker update: {e}")


def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, fire_utc,
                    triggered_by="django_q") -> int:
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id,customer_id,env_types,schedule_name,cron_expression,
                status,scheduled_fire_at,triggered_by,is_active,created_at,updated_at)
               VALUES(%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, fire_utc, triggered_by))
    except Exception as e:
        logger.warning(f"tracker insert: {e}")
        return 0


# Core execution
def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """
    Execute a HC run (load config -> RunLauncher -> update tracker).
    Called by Django Q worker, _chain_run, or manual run helpers.
    COM-safe on Windows.
    """
    _ci = False
    try:
        try:
            import pythoncom
            pythoncom.CoInitialize()
            _ci = True
        except Exception:
            pass

        eng = _get_engine()
        with _active_runs_lock:
            _active_runs[run_id] = label
        try:
            with eng["DBManager"]() as db:
                eng["ConfigLoader"].load(db)
                if tracker_id:
                    _update_tracker(db, tracker_id, run_id=run_id,
                                    status="RUNNING", actual_start_at=_now_utc())
                eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

            final = _get_status(run_id)
            logger.info(f"[Sched] Run #{run_id} ({label}) -> {final}")

            if tracker_id:
                with eng["DBManager"]() as db:
                    st = "COMPLETED" if final in ("COMPLETED", "PARTIAL") else "FAILED"
                    _update_tracker(db, tracker_id, status=st,
                                    completed_at=_now_utc(),
                                    error_message=None if st == "COMPLETED" else final)
        except Exception as exc:
            logger.error(f"[Sched] Run #{run_id} error: {exc}", exc_info=True)
            if tracker_id:
                try:
                    with eng["DBManager"]() as db:
                        _update_tracker(db, tracker_id, status="FAILED",
                                        completed_at=_now_utc(),
                                        error_message=str(exc)[:1000])
                except Exception:
                    pass
        finally:
            with _active_runs_lock:
                _active_runs.pop(run_id, None)
    finally:
        if _ci:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _get_status(run_id: int) -> str:
    try:
        with _get_engine()["DBManager"]() as db:
            r = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return r["status"] if r else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


# Rerun queue processor (called by Django Q CRON every minute)
def _process_rerun_queue():
    """
    Poll rerun_queue for PENDING entries whose scheduled_at has passed.
    Each entry is executed in its own background thread.
    """
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            pending = db.fetch_all(
                """SELECT rq.*, c.name AS cname
                   FROM rerun_queue rq
                   JOIN customers c ON c.id=rq.customer_id
                   WHERE rq.status='PENDING' AND rq.scheduled_at<=NOW()
                   ORDER BY rq.scheduled_at""")
    except Exception as exc:
        logger.error(f"[Rerun] Cannot fetch rerun_queue: {exc}")
        return

    if not pending:
        return

    logger.info(f"[Rerun] Processing {len(pending)} pending rerun(s)")
    for entry in pending:
        _fire_rerun_entry(entry)


def _fire_rerun_entry(entry: dict):
    """Execute one rerun_queue entry in a background thread."""
    entry_id  = entry["id"]
    cname     = entry.get("cname", str(entry["customer_id"]))
    env_types = entry["env_types"]
    label     = f"{cname}/{env_types}"

    def _do_rerun():
        _ci = False
        try:
            try:
                import pythoncom
                pythoncom.CoInitialize()
                _ci = True
            except Exception:
                pass

            eng = _get_engine()
            run_id = 0
            try:
                with eng["DBManager"]() as db:
                    eng["ConfigLoader"].load(db)
                    affected = db.execute(
                        "UPDATE rerun_queue SET status='IN_PROGRESS', started_at=NOW() "
                        "WHERE id=%s AND status='PENDING'",
                        (entry_id,))
                    if not affected:
                        return

                    run_id = db.insert_get_id(
                        """INSERT INTO execution_runs
                           (customer_id, env_types, run_type, status,
                            triggered_by, rerun_of_run_id, rerun_attempt)
                           VALUES (%s,%s,'RERUN','PENDING','djangoq_rerun',%s,%s)""",
                        (entry["customer_id"], env_types,
                         entry["original_run_id"], entry["attempt_number"]))

                logger.info(
                    f"[Rerun] {label} | attempt {entry['attempt_number']}/{entry['max_attempts']}"
                    f" -> Run #{run_id}")

                _execute_run(run_id, label)

                final_status = _get_status(run_id)
                if final_status == "COMPLETED":
                    with eng["DBManager"]() as db:
                        db.execute(
                            "UPDATE rerun_queue SET status='COMPLETED', completed_at=NOW() "
                            "WHERE id=%s", (entry_id,))
                    logger.info(f"[Rerun] {label} | Run #{run_id} COMPLETED - queue row closed")
                else:
                    logger.info(
                        f"[Rerun] {label} | Run #{run_id} status={final_status} "
                        f"(attempt {entry['attempt_number']}/{entry['max_attempts']}) "
                        f"- row managed by run_launcher")

            except Exception as exc:
                logger.error(f"[Rerun] entry {entry_id} error: {exc}", exc_info=True)
                try:
                    with eng["DBManager"]() as db:
                        db.execute(
                            "UPDATE rerun_queue SET status='FAILED', last_error=%s WHERE id=%s",
                            (str(exc)[:1000], entry_id))
                except Exception:
                    pass
        finally:
            if _ci:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    t = threading.Thread(target=_do_rerun, daemon=True, name=f"hc_rerun_{entry_id}")
    t.start()


# Django Q Schedule helpers
def _dq_upsert_once(name: str, func_path: str, args_tuple: tuple,
                    fire_at_utc: datetime):
    """
    Create or replace a Django Q ONCE schedule.
    fire_at_utc must be naive UTC; UTC tzinfo is attached here.
    """
    from django_q.models import Schedule as DQS

    fire_aware = fire_at_utc.replace(tzinfo=_dtz.utc)
    DQS.objects.update_or_create(
        name=name,
        defaults={
            'func': func_path,
            'args': repr(args_tuple),
            'schedule_type': DQS.ONCE,
            'next_run': fire_aware,
            'repeats': 1,
            'q_options': {'max_attempts': 1},
        }
    )


def _dq_upsert_cron(name: str, func_path: str, cron_expr: str):
    """Create or replace a Django Q CRON repeating schedule."""
    from django_q.models import Schedule as DQS

    DQS.objects.update_or_create(
        name=name,
        defaults={
            'func': func_path,
            'schedule_type': DQS.CRON,
            'cron': cron_expr,
            'repeats': -1,
            'q_options': {'max_attempts': 1},
        }
    )


# THE CHAIN RUNNER (called by Django Q ONCE schedule)
def _chain_run(schedule_id: int, customer_id: int, env_types: str,
               schedule_name: str, customer_name: str,
               cron_expression: str, run_number: int = 1):
    """
    Execute one HC run then register the NEXT Django Q ONCE schedule.

    Chain (preserves exact minute from start_at forever):
        ONCE schedule -> _chain_run(1)
            -> executes run
            -> registers ONCE at (now + interval) -> _chain_run(2)
            ...

    Example:
        start_at=04:08, cron=*/10 -> 04:08, 04:18, 04:28 ...
    """
    label   = f"{customer_name}/{env_types}"
    now_utc = _now_utc()
    now_ist = _utc_to_ist(now_utc)

    logger.info(
        f"[Sched] RUN #{run_number} '{schedule_name}' | {label} | "
        f"IST={now_ist.strftime('%d-%b-%Y %I:%M:%S %p')}")

    interval = _cron_to_timedelta(cron_expression)
    next_ist = now_ist + interval
    next_utc = _ist_to_utc(next_ist)

    eng = _get_engine()
    tracker_id = 0
    run_id     = 0

    try:
        # Step 1: READ-ONLY check
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            sch = db.fetch_one("SELECT is_active FROM schedules WHERE id=%s", (schedule_id,))
        if not sch or not sch["is_active"]:
            logger.info(f"[Sched] '{schedule_name}' deactivated - stopping chain.")
            return

        # Step 2: INSERT tracker + run
        with eng["DBManager"]() as db:
            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now_utc)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','django_q')""",
                (schedule_id, customer_id, env_types))

        # Step 3: UPDATE schedules (shortest lock window)
        with eng["DBManager"]() as db:
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

        # Step 4: UPDATE tracker with run_id + timestamps
        if tracker_id:
            with eng["DBManager"]() as db:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                last_run_at=now_utc,
                                next_run_at=next_utc)

        logger.info(
            f"[Sched] Run #{run_id} created | "
            f"last={now_ist.strftime('%I:%M %p IST')} | "
            f"next={next_ist.strftime('%I:%M %p IST')} "
            f"(+{int(interval.total_seconds() // 60)}min)")

        # Schedule NEXT run BEFORE executing this one
        # (chain survives even if this run crashes)
        _schedule_next(schedule_id, customer_id, env_types,
                       schedule_name, customer_name,
                       cron_expression, next_utc, run_number + 1)

        # Execute
        _execute_run(run_id, label, tracker_id)

    except Exception as exc:
        if isinstance(exc, _db_err()):
            logger.error(
                f"[Sched] DB down for '{schedule_name}'. "
                f"Rescheduling next in {int(interval.total_seconds() // 60)}min.")
            _schedule_next(schedule_id, customer_id, env_types,
                           schedule_name, customer_name,
                           cron_expression, next_utc, run_number + 1)
            return
        logger.error(f"[Sched] chain_run error '{schedule_name}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception:
                pass


def _schedule_next(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str, fire_at_utc: datetime,
                   run_number: int):
    """Register the next run as a Django Q ONCE schedule."""
    fire_ist = _utc_to_ist(fire_at_utc)
    try:
        _dq_upsert_once(
            name=f"sched_{schedule_id}",
            func_path='healthcheck.scheduler_service._chain_run',
            args_tuple=(schedule_id, customer_id, env_types,
                        schedule_name, customer_name,
                        cron_expression, run_number),
            fire_at_utc=fire_at_utc,
        )
        logger.info(
            f"[Sched] Next Django Q ONCE: run #{run_number} "
            f"'{schedule_name}' @ {fire_ist.strftime('%d-%b-%Y %I:%M %p IST')}")
    except Exception as exc:
        logger.error(f"[Sched] Failed to schedule next for '{schedule_name}': {exc}")


# Schedule loading
def _load_schedules() -> list:
    try:
        with _get_engine()["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s
                   JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


# Register all HC schedules as Django Q ONCE schedules
def _register_jobs():
    """
    Register each active HC schedule as a Django Q ONCE schedule.
    Called at startup and every 5 min by the 'refresh_schedules' CRON job.

    Logic per schedule:
      A) Has start_at AND never run  -> ONCE at start_at
      B) Has next_run_at (resume)    -> ONCE at next_run_at
      C) Missed run                  -> ONCE at next valid from anchor
      D) No start_at, no history     -> ONCE at now+5s
    """
    try:
        from django_q.models import Schedule as DQS  # noqa
    except ImportError:
        logger.error("[Sched] django_q not installed. Run: pip install django-q2")
        return

    DQS.objects.filter(name__startswith="sched_").delete()

    schedules = _load_schedules()
    logger.info(f"[Sched] Registering {len(schedules)} schedule(s) | tz=Asia/Kolkata")

    now_utc = _now_utc()

    for s in schedules:
        sid = s["id"]
        try:
            try:
                from croniter import croniter as _ci_cls
                _ci_cls(s["cron_expression"], datetime(2026, 1, 1))
            except Exception:
                logger.error(f"  x [{sid}] Invalid cron: '{s['cron_expression']}'")
                continue

            start_at_raw = _strip_tz(s.get("start_at"))
            last_run_raw = _strip_tz(s.get("last_run_at"))
            next_run_raw = _strip_tz(s.get("next_run_at"))
            already_ran  = last_run_raw is not None

            if not already_ran and start_at_raw is not None:
                if start_at_raw >= now_utc:
                    fire_utc = start_at_raw
                    mode = "start_at (FIRST)"
                else:
                    fire_utc = now_utc + timedelta(seconds=5)
                    mode = "start_at PAST -> immediate"
                run_num = 1

            elif next_run_raw is not None and next_run_raw > now_utc:
                fire_utc = next_run_raw
                run_num  = 2
                mode     = "next_run (RESUME)"

            elif already_ran and next_run_raw is not None and next_run_raw <= now_utc:
                interval = _cron_to_timedelta(s["cron_expression"])
                if start_at_raw is not None:
                    candidate = start_at_raw
                    while candidate <= now_utc:
                        candidate += interval
                    fire_utc = candidate
                else:
                    fire_utc = now_utc + interval
                run_num = 2
                mode    = "CATCHUP->next valid"

            else:
                fire_utc = now_utc + timedelta(seconds=5)
                run_num  = 1
                mode     = "immediate (no start_at)"

            fire_ist = _utc_to_ist(fire_utc)
            interval = _cron_to_timedelta(s["cron_expression"])

            _dq_upsert_once(
                name=f"sched_{sid}",
                func_path='healthcheck.scheduler_service._chain_run',
                args_tuple=(sid, s["customer_id"], s["env_types"],
                            s["schedule_name"], s["customer_name"],
                            s["cron_expression"], run_num),
                fire_at_utc=fire_utc,
            )

            logger.info(
                f"  + [{sid}] {s['schedule_name']} | "
                f"cron={s['cron_expression']} | "
                f"interval={int(interval.total_seconds() // 60)}min | "
                f"{mode} | fire={fire_ist.strftime('%d-%b-%Y %I:%M:%S %p IST')}")

        except Exception as exc:
            logger.error(f"  x [{sid}] {s.get('schedule_name', '?')}: {exc}")


# Lifecycle
def get_scheduler():
    """
    Returns True if Django Q HC schedules are registered.
    Used by views/templates that check scheduler state.
    """
    try:
        from django_q.models import Schedule as DQS
        return DQS.objects.filter(
            name__in=["refresh_schedules", "rerun_queue_poller"]
        ).exists()
    except Exception:
        return False


def start_scheduler():
    """
    Register all HC schedules + system jobs as Django Q Schedule objects.
    Idempotent - safe to call multiple times.

    NOTE: Requires 'python manage.py qcluster' to actually execute jobs.
    """
    global _scheduler_started
    with _scheduler_lock:
        if _scheduler_started:
            logger.info("[Sched] Already started (Django Q schedules registered)")
            return True

        try:
            from django_q.models import Schedule as DQS  # noqa
        except ImportError:
            logger.error("[Sched] django_q not installed. Run: pip install django-q2")
            return None

        try:
            _register_jobs()

            _dq_upsert_cron(
                name="refresh_schedules",
                func_path="healthcheck.scheduler_service._register_jobs",
                cron_expr="*/5 * * * *",
            )
            _dq_upsert_cron(
                name="rerun_queue_poller",
                func_path="healthcheck.scheduler_service._process_rerun_queue",
                cron_expr="* * * * *",
            )

            _scheduler_started = True
            logger.info(
                f"[Sched] Django Q schedules registered | tz=Asia/Kolkata | "
                f"IST={_now_ist().strftime('%d-%b-%Y %I:%M:%S %p')} | "
                f"Run 'python manage.py qcluster' to start worker.")
            return True

        except Exception as exc:
            logger.error(f"[Sched] Start failed: {exc}", exc_info=True)
            return None


def stop_scheduler():
    """Remove all Django Q Schedule objects registered by this app."""
    global _scheduler_started
    with _scheduler_lock:
        try:
            from django_q.models import Schedule as DQS
            n, _ = DQS.objects.filter(name__startswith="sched_").delete()
            DQS.objects.filter(name__in=["refresh_schedules", "rerun_queue_poller"]).delete()
            _scheduler_started = False
            logger.info(f"[Sched] Stopped - {n} HC schedule(s) removed")
        except Exception as exc:
            logger.error(f"[Sched] Stop failed: {exc}")


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """
    Return scheduler status dict compatible with views/templates.

    Fields:
        running          bool  - True if HC schedules are registered
        cluster_running  bool  - True if qcluster worker is alive
        job_count        int   - number of registered HC ONCE schedules
        jobs             list  - [{id, name, next_run, last_run}] in IST
        active_runs      list  - [{run_id, label}] currently IN_PROGRESS
        active_run_count int
        timezone         str
        server_time_ist  str
    """
    now_ist_str = _now_ist().strftime("%d-%b-%Y %I:%M:%S %p")

    cluster_running = False
    try:
        from django_q.status import Stat
        stats = Stat.get_all()
        cluster_running = bool(stats)
    except Exception:
        pass

    jobs = []
    has_hc_schedules = False
    try:
        from django_q.models import Schedule as DQS
        hc_scheds = DQS.objects.filter(name__startswith="sched_").order_by("name")
        has_hc_schedules = hc_scheds.exists()

        for sched in hc_scheds:
            nxt = sched.next_run
            nxt_str = (
                _utc_to_ist(nxt).strftime("%d-%b-%Y %I:%M:%S %p IST") if nxt else "—"
            )
            last = getattr(sched, 'last_run', None)
            last_str = (
                _utc_to_ist(last).strftime("%d-%b-%Y %I:%M:%S %p IST")
                if last else "Never"
            )
            jobs.append({
                "id":       sched.name,
                "name":     sched.name,
                "next_run": nxt_str,
                "last_run": last_str,
            })
    except Exception as exc:
        logger.debug(f"scheduler_status: Django Q query failed: {exc}")

    # Active runs: query DB (works cross-process with qcluster)
    active = []
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            active_db = db.fetch_all(
                """SELECT er.id, er.env_types, c.name AS cname
                   FROM execution_runs er
                   JOIN customers c ON c.id=er.customer_id
                   WHERE er.status='IN_PROGRESS'""")
        active = [
            {"run_id": r["id"], "label": f"{r['cname']}/{r['env_types']}"}
            for r in active_db
        ]
    except Exception:
        with _active_runs_lock:
            active = [{"run_id": r, "label": l} for r, l in _active_runs.items()]

    is_running = has_hc_schedules or _scheduler_started

    return {
        "running":          is_running,
        "cluster_running":  cluster_running,
        "job_count":        len(jobs),
        "jobs":             jobs,
        "active_runs":      active,
        "active_run_count": len(active),
        "timezone":         "Asia/Kolkata (IST)",
        "server_time_ist":  now_ist_str,
    }


# Manual run helpers
def run_now_sync(schedule_id: int) -> Optional[int]:
    """
    Admin Run Now - create run in DB synchronously, execute via Django Q.
    Returns run_id immediately; execution starts in qcluster worker.
    Falls back to threading if Django Q submission fails.
    """
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
        if not s:
            return None

        now_utc  = _now_utc()
        now_ist  = _utc_to_ist(now_utc)
        interval = _cron_to_timedelta(s["cron_expression"])
        next_utc = _ist_to_utc(now_ist + interval)

        with eng["DBManager"]() as db:
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))
            tid = _create_tracker(db, schedule_id, s["customer_id"], s["env_types"],
                                   s["schedule_name"], s["cron_expression"],
                                   now_utc, "admin:run_now")

        with eng["DBManager"]() as db:
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

        label = f"{s['cname']}/{s['env_types']}"
        _schedule_next(schedule_id, s["customer_id"], s["env_types"],
                       s["schedule_name"], s["cname"],
                       s["cron_expression"], next_utc, 2)

        _async_execute(run_id, label, tid)

        logger.info(
            f"[Sched] admin:run_now -> Run #{run_id} dispatched | "
            f"next={_utc_to_ist(next_utc).strftime('%I:%M %p IST')}")
        return run_id

    except Exception as exc:
        logger.error(f"run_now_sync: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """Manual run for customer/env - dispatches via Django Q async task."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust  = db.fetch_one("SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        label = f"{cname}/{env_types}"
        _async_execute(run_id, label, 0)
        return run_id

    except Exception as exc:
        logger.error(f"run_customer_now: {exc}", exc_info=True)
        return None


def _async_execute(run_id: int, label: str, tracker_id: int):
    """
    Submit _execute_run to Django Q async task queue.
    Falls back to threading if the broker is unavailable.
    """
    try:
        from django_q.tasks import async_task
        async_task(
            'healthcheck.scheduler_service._execute_run',
            run_id, label, tracker_id,
            q_options={'max_attempts': 1},
        )
        logger.info(f"[Sched] async_task queued: Run #{run_id} ({label})")
    except Exception as async_exc:
        logger.warning(
            f"[Sched] async_task failed ({async_exc}), falling back to thread for Run #{run_id}")
        t = threading.Thread(
            target=_execute_run, args=(run_id, label, tracker_id),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()


def reschedule_after_start_at_update(schedule_id: int) -> bool:
    """
    Called when admin changes start_at on a scheduled row.
    Resets last_run_at/next_run_at and re-registers Django Q ONCE schedule.
    Retries up to 3x on MySQL 1205 lock timeout.
    """
    import time as _time

    eng = _get_engine()

    try:
        with eng["DBManager"]() as db:
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
        if not s:
            logger.error(f"[Sched] reschedule: schedule {schedule_id} not found")
            return False
    except Exception as exc:
        logger.error(f"[Sched] reschedule_after_start_at_update read error: {exc}", exc_info=True)
        return False

    start_at_raw = _strip_tz(s.get("start_at"))
    now_utc_val  = _now_utc()

    if start_at_raw is None:
        fire_utc = now_utc_val + timedelta(seconds=5)
    elif start_at_raw > now_utc_val:
        fire_utc = start_at_raw
    else:
        interval  = _cron_to_timedelta(s["cron_expression"])
        candidate = start_at_raw
        while candidate <= now_utc_val:
            candidate += interval
        fire_utc = candidate

    MAX_RETRIES = 3
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with eng["DBManager"]() as db:
                db.execute(
                    "UPDATE schedules SET last_run_at=NULL, next_run_at=%s WHERE id=%s",
                    (fire_utc, schedule_id))
            break
        except Exception as exc:
            err_str = str(exc)
            is_lock = any(kw in err_str for kw in ("1205", "1213", "Lock wait", "Deadlock"))
            if is_lock and attempt < MAX_RETRIES:
                wait = attempt * 2
                logger.warning(
                    f"[Sched] reschedule UPDATE lock conflict "
                    f"(attempt {attempt}/{MAX_RETRIES}), retrying in {wait}s - {exc}")
                _time.sleep(wait)
                continue
            logger.error(f"[Sched] reschedule_after_start_at_update error: {exc}", exc_info=True)
            return False

    fire_ist = _utc_to_ist(fire_utc)
    logger.info(
        f"[Sched] reschedule_after_start_at_update [{schedule_id}] "
        f"'{s['schedule_name']}' -> fire @ {fire_ist.strftime('%d-%b-%Y %I:%M %p IST')}")

    try:
        _schedule_next(
            schedule_id, s["customer_id"], s["env_types"],
            s["schedule_name"], s["cname"],
            s["cron_expression"], fire_utc, 1)
        return True
    except Exception as exc:
        logger.error(f"[Sched] reschedule schedule_next error: {exc}", exc_info=True)
        return False

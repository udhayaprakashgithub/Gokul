"""
healthcheck/views.py  (v6 clean)
All user-facing and admin views.
"""
import os
import sys
import threading
from datetime import datetime, timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.http import FileResponse, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from healthcheck.models import (
    AlertHistory, Customer, DBCheckResult, Environment, EnvRunStatus,
    EscalationConfig, ExecutionLog, ExecutionRun, IssueTracker,
    MailConfig, MailRecipient, RerunQueue, RMANBackupDetail,
    RunStepLog, Schedule, Server, ServerCheckResult,
    SystemConfig, TablespaceUsage,
)

_DB = "healthcheck_db"
is_admin = user_passes_test(lambda u: u.is_staff)


def _q(qs):
    """Apply .using(healthcheck_db) to a queryset."""
    return qs.using(_DB)


def _engine_path():
    path = os.path.join(os.path.dirname(__file__), "engine")
    if path not in sys.path:
        sys.path.insert(0, path)
    return path


# ──────────────────────────────────────────────────────────────
# AUTH
# ──────────────────────────────────────────────────────────────

def login_view(request):
    from django.contrib.auth import authenticate, login
    error = None
    if request.method == "POST":
        u = authenticate(request,
                         username=request.POST.get("username"),
                         password=request.POST.get("password"))
        if u:
            login(request, u)
            return redirect(request.GET.get("next", "/"))
        error = "Invalid username or password."
    return render(request, "healthcheck/login.html", {"error": error})


def logout_view(request):
    from django.contrib.auth import logout
    logout(request)
    return redirect("/login/")


# ──────────────────────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    from healthcheck.scheduler_service import scheduler_status

    runs = _q(
        ExecutionRun.objects.select_related("customer").order_by("-id")[:20]
    )
    open_issues = _q(
        IssueTracker.objects.select_related("customer", "test_catalog")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")[:20]
    )
    pending_reruns = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")[:10]
    )
    paused_escalations = _q(
        EscalationConfig.objects.select_related("customer").filter(is_paused=True)
    )
    recent_alerts = _q(AlertHistory.objects.order_by("-sent_at")[:10])
    sched_status  = scheduler_status()

    return render(request, "healthcheck/dashboard.html", {
        "runs":                runs,
        "open_issues":         open_issues,
        "pending_reruns":      pending_reruns,
        "paused_escalations":  paused_escalations,
        "recent_alerts":       recent_alerts,
        "scheduler_status":    sched_status,
        "active_page":         "dashboard",
    })


# ──────────────────────────────────────────────────────────────
# REPORTS
# ──────────────────────────────────────────────────────────────

@login_required
def reports_list(request):
    qs = _q(
        ExecutionRun.objects.select_related("customer")
        .filter(status__in=["COMPLETED", "PARTIAL", "FAILED"])
        .order_by("-id")
    )
    customer_id    = request.GET.get("customer")
    env_type_filter = request.GET.get("env")
    status_filter  = request.GET.get("status")

    if customer_id:
        qs = qs.filter(customer_id=customer_id)
    if env_type_filter:
        qs = qs.filter(env_types__contains=env_type_filter)
    if status_filter:
        qs = qs.filter(status=status_filter)

    page = Paginator(qs, 20).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))

    return render(request, "healthcheck/reports_list.html", {
        "page_obj":          page,
        "customers":         customers,
        "active_page":       "reports",
        "selected_customer": customer_id,
        "selected_env":      env_type_filter,
        "selected_status":   status_filter,
    })


@login_required
def report_detail(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)

    env_statuses = _q(EnvRunStatus.objects.filter(run=run).order_by("env_type"))

    env_data   = []
    has_action = False

    for es in env_statuses:
        # Server checks
        server_checks = list(
            _q(ServerCheckResult.objects.select_related("server")
               .filter(env_status=es))
        )
        # DB checks
        db_checks_qs = list(
            _q(DBCheckResult.objects.select_related("server", "oracle_db")
               .filter(env_status=es))
        )

        for sc in server_checks:
            if sc.any_action():
                has_action = True

        # Build DB check data with tablespace + RMAN
        db_check_data = []
        for dc in db_checks_qs:
            if dc.any_action():
                has_action = True
            ts_rows   = list(_q(TablespaceUsage.objects.filter(db_check=dc).order_by("-used_pct")))
            rman_rows = list(_q(RMANBackupDetail.objects.filter(db_check=dc)))
            db_check_data.append({
                "check":     dc,
                "ts_rows":   ts_rows,
                "rman_rows": rman_rows,
            })

        env_data.append({
            "env_status":    es,
            "server_checks": server_checks,
            "db_checks":     db_check_data,
        })

    step_log     = _q(RunStepLog.objects.filter(run=run).order_by("step_order"))
    alerts       = _q(AlertHistory.objects.filter(run=run).order_by("-sent_at"))
    action_filter = request.GET.get("action")

    return render(request, "healthcheck/report_detail.html", {
        "run":           run,
        "env_data":      env_data,
        "step_log":      step_log,
        "alerts":        alerts,
        "has_action":    has_action,
        "action_filter": action_filter,
        "active_page":   "reports",
    })


@login_required
def download_excel(request, run_id):
    """Generate or re-generate the Excel for a run and serve as download."""
    _engine_path()
    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader
    from engine.core.logger import SilentLogger
    from engine.reports.excel_generator import ExcelReportGenerator

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            gen = ExcelReportGenerator(db, run_id, SilentLogger())
            filepath, title = gen.generate()

        dl_date  = datetime.now().strftime("%d-%b-%Y")
        orig     = os.path.basename(filepath)
        dl_name  = orig.replace(".xlsx", f"_DL-{dl_date}.xlsx")

        return FileResponse(
            open(filepath, "rb"),
            content_type=(
                "application/vnd.openxmlformats-officedocument"
                ".spreadsheetml.sheet"),
            as_attachment=True,
            filename=dl_name,
        )
    except Exception as exc:
        messages.error(request, f"Could not generate Excel: {exc}")
        return redirect("report_detail", run_id=run_id)


# ──────────────────────────────────────────────────────────────
# LOGS
# ──────────────────────────────────────────────────────────────

@login_required
def run_logs(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)

    qs = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))
    level_filter = request.GET.get("level")
    if level_filter:
        qs = qs.filter(log_level=level_filter)

    page = Paginator(qs, 200).get_page(request.GET.get("page", 1))

    return render(request, "healthcheck/run_logs.html", {
        "run":          run,
        "page_obj":     page,
        "level_filter": level_filter,
        "log_levels":   ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        "active_page":  "reports",
    })


@login_required
def download_logs(request, run_id):
    run  = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    logs = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))

    lines = [
        f"{log.logged_at.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} "
        f"[{log.log_level:<8}] "
        f"[{log.py_file}::{log.py_function}():L{log.py_line}] "
        f"{log.message}"
        for log in logs
    ]
    fname = (
        f"run_{run_id}_{run.customer.name}_"
        f"{datetime.now().strftime('%Y%m%d')}.log"
    )
    resp = HttpResponse("\n".join(lines), content_type="text/plain; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="{fname}"'
    return resp


# ──────────────────────────────────────────────────────────────
# ESCALATION
# ──────────────────────────────────────────────────────────────

@login_required
def escalation_view(request):
    issues     = _q(
        IssueTracker.objects.select_related(
            "customer", "test_catalog",
            "first_failed_run", "last_failed_run")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")
    )
    esc_configs = _q(EscalationConfig.objects.select_related("customer").all())

    return render(request, "healthcheck/escalation.html", {
        "issues":      issues,
        "esc_configs": esc_configs,
        "active_page": "escalation",
    })


@login_required
@is_admin
@require_POST
def pause_escalation(request, pk):
    obj    = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    hours  = int(request.POST.get("hours", 168))
    reason = request.POST.get("reason", "Manual pause")

    obj.is_paused    = True
    obj.paused_until = datetime.utcnow() + timedelta(hours=hours)
    obj.pause_reason = reason
    obj.save(using=_DB)

    messages.success(
        request,
        f"Escalation paused for {obj.customer.name}/{obj.env_type} "
        f"for {hours}h.")
    return redirect("escalation")


@login_required
@is_admin
@require_POST
def resume_escalation(request, pk):
    obj = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    obj.is_paused    = False
    obj.paused_until = None
    obj.pause_reason = ""
    obj.save(using=_DB)
    messages.success(request,
                     f"Escalation resumed for {obj.customer.name}/{obj.env_type}.")
    return redirect("escalation")


# ──────────────────────────────────────────────────────────────
# RERUN
# ──────────────────────────────────────────────────────────────

@login_required
def rerun_view(request):
    pending = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")
    )
    recent = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .exclude(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("-created_at")[:20]
    )
    return render(request, "healthcheck/rerun.html", {
        "pending":     pending,
        "recent":      recent,
        "active_page": "rerun",
    })


@login_required
@is_admin
@require_POST
def trigger_rerun(request, run_id):
    _engine_path()
    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            run = db.fetch_one(
                "SELECT * FROM execution_runs WHERE id=%s", (run_id,))
            if not run:
                messages.error(request, f"Run #{run_id} not found.")
                return redirect("rerun")
            new_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id, env_types, run_type, status, triggered_by,
                    rerun_of_run_id, rerun_attempt)
                   VALUES (%s,%s,'RERUN','PENDING','admin:rerun',%s,1)""",
                (run["customer_id"], run["env_types"], run_id))

        from healthcheck.scheduler_service import _run_in_thread
        t = threading.Thread(target=_run_in_thread, args=(new_id,),
                             daemon=True, name=f"hc_rerun_{new_id}")
        t.start()
        messages.success(request,
                         f"Rerun #{new_id} started in background.")
    except Exception as exc:
        messages.error(request, f"Error starting rerun: {exc}")
    return redirect("rerun")


# ──────────────────────────────────────────────────────────────
# ADMIN: Manual Run
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def manual_run(request):
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))
    if request.method == "POST":
        customer_id = request.POST.get("customer_id")
        env_types   = request.POST.get("env_types", "").upper().strip()
        if customer_id and env_types:
            from healthcheck.scheduler_service import run_customer_now
            run_id = run_customer_now(int(customer_id), env_types)
            if run_id:
                messages.success(
                    request,
                    f"Run #{run_id} started in background. "
                    f"Check dashboard for status.")
                return redirect("dashboard")
            messages.error(request, "Failed to start run. Check server logs.")
        else:
            messages.error(request, "Please select a customer and environment.")

    return render(request, "healthcheck/manual_run.html", {
        "customers":   customers,
        "active_page": "manual_run",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Scheduler
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def scheduler_view(request):
    from healthcheck.scheduler_service import scheduler_status
    schedules = _q(
        Schedule.objects.select_related("customer").order_by("customer__name"))
    return render(request, "healthcheck/scheduler.html", {
        "sched_status": scheduler_status(),
        "schedules":    schedules,
        "active_page":  "scheduler",
    })


@login_required
@is_admin
@require_POST
def scheduler_action(request):
    from healthcheck.scheduler_service import (
        start_scheduler, stop_scheduler, restart_scheduler, run_now_sync)

    action = request.POST.get("action")
    if action == "start":
        start_scheduler()
        messages.success(request, "Scheduler started.")
    elif action == "stop":
        stop_scheduler()
        messages.success(request, "Scheduler stopped.")
    elif action == "restart":
        restart_scheduler()
        messages.success(request, "Scheduler restarted — schedules reloaded from DB.")
    elif action == "run_now":
        sched_id = int(request.POST.get("schedule_id", 0))
        run_id   = run_now_sync(sched_id)
        if run_id:
            messages.success(request,
                             f"Schedule fired — Run #{run_id} running in background.")
        else:
            messages.error(request, "Could not fire schedule. Check server logs.")
    return redirect("scheduler")


# ──────────────────────────────────────────────────────────────
# ADMIN: Customers
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def customer_list(request):
    customers = _q(
        Customer.objects.prefetch_related("environment_set")
        .order_by("name"))
    return render(request, "healthcheck/customer_list.html", {
        "customers":   customers,
        "active_page": "customers",
    })


@login_required
@is_admin
def customer_form(request, pk=None):
    from healthcheck.forms import CustomerForm
    instance = get_object_or_404(_q(Customer.objects), pk=pk) if pk else None

    if request.method == "POST":
        form = CustomerForm(request.POST, instance=instance)
        if form.is_valid():
            form.save(using=_DB) if hasattr(form, "save") else None
            obj = form.save(commit=False)
            obj.save(using=_DB)
            messages.success(request, "Customer saved.")
            return redirect("customer_list")
    else:
        form = CustomerForm(instance=instance)

    return render(request, "healthcheck/customer_form.html", {
        "form":        form,
        "instance":    instance,
        "active_page": "customers",
    })


@login_required
@is_admin
@require_POST
def customer_delete(request, pk):
    obj  = get_object_or_404(_q(Customer.objects), pk=pk)
    name = obj.name
    obj.delete(using=_DB)
    messages.success(request, f"Customer '{name}' deleted.")
    return redirect("customer_list")


@login_required
@is_admin
def environment_form(request, pk=None):
    from healthcheck.forms import EnvironmentForm
    instance = get_object_or_404(_q(Environment.objects), pk=pk) if pk else None

    if request.method == "POST":
        form = EnvironmentForm(request.POST, instance=instance)
        if form.is_valid():
            obj = form.save(commit=False)
            plain_pwd = form.cleaned_data.get("plain_password")
            if plain_pwd:
                _engine_path()
                from engine.utils.crypto import encrypt_password
                obj.server_pwd = encrypt_password(plain_pwd)
            elif not obj.server_pwd:
                # Preserve existing encrypted password
                if instance:
                    obj.server_pwd = instance.server_pwd
            obj.save(using=_DB)
            messages.success(request, "Environment saved.")
            return redirect("customer_list")
    else:
        form = EnvironmentForm(instance=instance)

    return render(request, "healthcheck/environment_form.html", {
        "form":        form,
        "instance":    instance,
        "active_page": "customers",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Config
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def config_list(request):
    sys_configs  = _q(SystemConfig.objects.all().order_by("config_group", "config_key"))
    mail_configs = _q(MailConfig.objects.all())
    mail_rcpts   = _q(MailRecipient.objects.select_related("customer").all())
    return render(request, "healthcheck/config_list.html", {
        "sys_configs":  sys_configs,
        "mail_configs": mail_configs,
        "mail_rcpts":   mail_rcpts,
        "active_page":  "config",
    })


@login_required
@is_admin
@require_POST
def config_update(request, pk):
    obj = get_object_or_404(_q(SystemConfig.objects), pk=pk)
    obj.config_value = request.POST.get("config_value", "")
    obj.save(using=_DB)
    messages.success(request, f"Config '{obj.config_key}' updated.")
    return redirect("config_list")


# ──────────────────────────────────────────────────────────────
# API: Live status (JSON)
# ──────────────────────────────────────────────────────────────

@login_required
def api_run_status(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    return JsonResponse({
        "id":           run.id,
        "status":       run.status,
        "latest_step":  run.latest_step or "",
        "started_at":   run.started_at.isoformat()   if run.started_at  else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    })


@login_required
def api_scheduler_status(request):
    from healthcheck.scheduler_service import scheduler_status
    return JsonResponse(scheduler_status())

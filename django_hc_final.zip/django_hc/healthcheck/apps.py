from django.apps import AppConfig


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """Called once when Django starts. Start the background scheduler."""
        import os
        # Only start scheduler in the main process (not in manage.py commands
        # or runserver's reloader child process)
        if os.environ.get("RUN_MAIN") == "true" or not os.environ.get("RUN_MAIN"):
            try:
                from healthcheck.scheduler_service import start_scheduler
                start_scheduler()
            except Exception as e:
                import logging
                logging.getLogger("hc.scheduler").warning(
                    f"Could not start scheduler on startup: {e}")

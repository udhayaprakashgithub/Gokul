from django.urls import path
from healthcheck import views

urlpatterns = [
    # Auth
    path("login/",   views.login_view,  name="login"),
    path("logout/",  views.logout_view, name="logout"),

    # Dashboard (main)
    path("",         views.dashboard,   name="dashboard"),

    # Reports
    path("reports/",                    views.reports_list,   name="reports_list"),
    path("reports/<int:run_id>/",       views.report_detail,  name="report_detail"),
    path("reports/<int:run_id>/logs/",  views.run_logs,       name="run_logs"),
    path("reports/<int:run_id>/logs/download/", views.download_logs, name="download_logs"),
    path("reports/<int:run_id>/excel/", views.download_excel, name="download_excel"),

    # Escalation
    path("escalation/",                        views.escalation_view,    name="escalation"),
    path("escalation/<int:pk>/pause/",         views.pause_escalation,   name="pause_escalation"),
    path("escalation/<int:pk>/resume/",        views.resume_escalation,  name="resume_escalation"),

    # Rerun
    path("rerun/",                             views.rerun_view,         name="rerun"),
    path("rerun/<int:run_id>/trigger/",        views.trigger_rerun,      name="trigger_rerun"),

    # Admin: Manual run
    path("manual-run/",                        views.manual_run,         name="manual_run"),

    # Admin: Scheduler
    path("scheduler/",                         views.scheduler_view,     name="scheduler"),
    path("scheduler/action/",                  views.scheduler_action,   name="scheduler_action"),

    # Admin: Customers
    path("customers/",                         views.customer_list,      name="customer_list"),
    path("customers/add/",                     views.customer_form,      name="customer_add"),
    path("customers/<int:pk>/edit/",           views.customer_form,      name="customer_edit"),
    path("customers/<int:pk>/delete/",         views.customer_delete,    name="customer_delete"),

    # Admin: Environments
    path("environments/add/",                  views.environment_form,   name="environment_add"),
    path("environments/<int:pk>/edit/",        views.environment_form,   name="environment_edit"),

    # Admin: Config
    path("config/",                            views.config_list,        name="config_list"),
    path("config/<int:pk>/update/",            views.config_update,      name="config_update"),

    # API (JSON for live updates)
    path("api/run/<int:run_id>/status/",       views.api_run_status,     name="api_run_status"),
    path("api/scheduler/status/",             views.api_scheduler_status, name="api_scheduler_status"),
]

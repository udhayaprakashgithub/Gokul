"""
healthcheck/scheduler_service.py
=================================
Wraps APScheduler BackgroundScheduler.
- Reads schedules from HC DB and registers them as cron jobs.
- Each job fires in its own thread (async / simultaneous runs).
- Does NOT create any extra DB tables (in-memory job store only).
- Jobs are refreshed from DB every REFRESH_INTERVAL_MINUTES minutes
  so newly added/disabled schedules take effect without a restart.
"""
import logging
import os
import sys
import threading
from datetime import datetime
from typing import Optional

logger = logging.getLogger("hc.scheduler")

_scheduler = None
_scheduler_lock = threading.Lock()
_scheduler_thread = None


# ──────────────────────────────────────────────────────────────
def _get_engine_config():
    """
    Build AppConfig for the HC engine from Django settings / env vars.
    Returns (AppConfig, DBManager) pair.
    """
    # Add engine to path
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader, DB_CONFIG

    db = DBManager()
    db.connect()
    cfg = ConfigLoader.load(db)
    return cfg, db


def _run_schedule_job(schedule_id: int, customer_id: int,
                      env_types: str, schedule_name: str,
                      customer_name: str):
    """
    Called by APScheduler in a background thread.
    Creates a new execution_run and fires RunLauncher.
    """
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader
    from engine.scheduling.run_launcher import RunLauncher

    logger.info(
        f"[APScheduler] Firing schedule '{schedule_name}' | "
        f"{customer_name}/{env_types}")

    try:
        with DBManager() as db:
            cfg = ConfigLoader.load(db)

            # Create run record
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id, customer_id, env_types,
                    run_type, status, triggered_by)
                   VALUES (%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            logger.info(
                f"[APScheduler] Run #{run_id} started | "
                f"{customer_name}/{env_types}")

            # Update schedule last_run_at
            db.execute(
                "UPDATE schedules SET last_run_at=NOW() WHERE id=%s",
                (schedule_id,))

            # Launch (blocking within this thread)
            RunLauncher(db, run_id, cfg).launch()

            final = db.fetch_one(
                "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            status = final["status"] if final else "UNKNOWN"
            logger.info(
                f"[APScheduler] Run #{run_id} {status} | "
                f"{customer_name}/{env_types}")

    except Exception as exc:
        logger.error(
            f"[APScheduler] Error in schedule '{schedule_name}': {exc}",
            exc_info=True)


def _load_schedules_from_db():
    """
    Load all active schedules from DB.
    Returns list of dicts with id, customer_id, env_types, cron, name.
    """
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    try:
        from engine.core.db_manager import DBManager
        with DBManager() as db:
            rows = db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, c.name AS customer_name
                   FROM schedules s JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
        return rows
    except Exception as exc:
        logger.error(f"Cannot load schedules from DB: {exc}")
        return []


def _register_all_jobs(scheduler):
    """Register all active DB schedules as APScheduler jobs."""
    from apscheduler.triggers.cron import CronTrigger

    # Remove all existing schedule jobs (keep the refresh job)
    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            job.remove()

    schedules = _load_schedules_from_db()
    logger.info(f"Registering {len(schedules)} active schedule(s)")

    for sched in schedules:
        job_id = f"sched_{sched['id']}"
        try:
            cron_parts = sched["cron_expression"].strip().split()
            trigger = CronTrigger(
                minute=cron_parts[0] if len(cron_parts) > 0 else "*",
                hour=cron_parts[1]   if len(cron_parts) > 1 else "*",
                day=cron_parts[2]    if len(cron_parts) > 2 else "*",
                month=cron_parts[3]  if len(cron_parts) > 3 else "*",
                day_of_week=cron_parts[4] if len(cron_parts) > 4 else "*",
            )
            scheduler.add_job(
                _run_schedule_job,
                trigger=trigger,
                id=job_id,
                name=sched["schedule_name"],
                args=[
                    sched["id"],
                    sched["customer_id"],
                    sched["env_types"],
                    sched["schedule_name"],
                    sched["customer_name"],
                ],
                max_instances=1,      # prevent same schedule overlapping itself
                coalesce=True,        # skip missed fires
                replace_existing=True,
                misfire_grace_time=300,
            )
            logger.info(
                f"  Registered: [{sched['id']}] {sched['schedule_name']} "
                f"| cron={sched['cron_expression']}")
        except Exception as exc:
            logger.error(
                f"  Failed to register schedule id={sched['id']}: {exc}")


def get_scheduler():
    """Return the global APScheduler instance (or None if not started)."""
    return _scheduler


def start_scheduler():
    """Start the APScheduler BackgroundScheduler if not already running."""
    global _scheduler

    with _scheduler_lock:
        if _scheduler is not None and _scheduler.running:
            logger.info("Scheduler already running — skipping start")
            return _scheduler

        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor

            executors = {
                # Allow up to 20 simultaneous schedule jobs
                "default": ThreadPoolExecutor(max_workers=20)
            }
            job_defaults = {
                "coalesce": True,
                "max_instances": 1,
            }
            _scheduler = BackgroundScheduler(
                executors=executors,
                job_defaults=job_defaults,
                timezone="UTC")

            # Register all active schedules
            _register_all_jobs(_scheduler)

            # Refresh schedules from DB every 5 minutes
            _scheduler.add_job(
                lambda: _register_all_jobs(_scheduler),
                "interval",
                minutes=5,
                id="refresh_schedules",
                name="Refresh schedules from DB",
            )

            _scheduler.start()
            logger.info("APScheduler started with in-memory job store")
            return _scheduler

        except ImportError:
            logger.error(
                "APScheduler not installed. "
                "Run: pip install apscheduler")
            return None
        except Exception as exc:
            logger.error(f"Failed to start scheduler: {exc}", exc_info=True)
            return None


def stop_scheduler():
    """Stop the APScheduler BackgroundScheduler."""
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("APScheduler stopped")
        _scheduler = None


def restart_scheduler():
    """Stop then restart the scheduler (reload all schedules from DB)."""
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """Return a dict describing current scheduler state."""
    if _scheduler is None or not _scheduler.running:
        return {
            "running": False,
            "job_count": 0,
            "jobs": [],
        }
    jobs = []
    for job in _scheduler.get_jobs():
        next_run = job.next_run_time
        jobs.append({
            "id":       job.id,
            "name":     job.name,
            "next_run": next_run.strftime("%Y-%m-%d %H:%M:%S") if next_run else "—",
            "is_schedule": job.id.startswith("sched_"),
        })
    return {
        "running":   True,
        "job_count": len([j for j in jobs if j["is_schedule"]]),
        "jobs":      jobs,
    }


def run_now_sync(schedule_id: int) -> Optional[int]:
    """
    Fire a specific schedule immediately (from admin UI).
    Returns the new run_id.
    """
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader
    from engine.scheduling.run_launcher import RunLauncher

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            sched = db.fetch_one(
                """SELECT s.*, c.name AS cname FROM schedules s
                   JOIN customers c ON c.id=s.customer_id WHERE s.id=%s""",
                (schedule_id,))
            if not sched:
                return None

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id, customer_id, env_types,
                    run_type, status, triggered_by)
                   VALUES (%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (sched["id"], sched["customer_id"], sched["env_types"]))

            # Fire in background thread so HTTP request returns immediately
            t = threading.Thread(
                target=_run_in_thread,
                args=(run_id,),
                daemon=True,
                name=f"hc_manual_{run_id}")
            t.start()
            return run_id
    except Exception as exc:
        logger.error(f"run_now_sync failed: {exc}")
        return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """
    Fire a manual run for a customer+env.
    Returns the new run_id.
    """
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id, env_types, run_type, status, triggered_by)
                   VALUES (%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            t = threading.Thread(
                target=_run_in_thread,
                args=(run_id,),
                daemon=True,
                name=f"hc_manual_{run_id}")
            t.start()
            return run_id
    except Exception as exc:
        logger.error(f"run_customer_now failed: {exc}")
        return None


def _run_in_thread(run_id: int):
    """Execute a run inside a background thread."""
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader
    from engine.scheduling.run_launcher import RunLauncher

    try:
        with DBManager() as db:
            cfg = ConfigLoader.load(db)
            RunLauncher(db, run_id, cfg).launch()
    except Exception as exc:
        logger.error(f"Run #{run_id} thread error: {exc}", exc_info=True)

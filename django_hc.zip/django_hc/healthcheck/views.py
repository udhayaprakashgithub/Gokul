"""
healthcheck/views.py
All user-facing views (Bootstrap 5, database=healthcheck_db).
Admin-only: manual run, schedule start/stop/restart.
User views: dashboard, escalation, rerun, reports, log viewer.
"""
import json
import os
from datetime import datetime

from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.http import (FileResponse, Http404, JsonResponse,
                         HttpResponseForbidden)
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from healthcheck.models import (
    AlertHistory, Customer, DBCheckResult, EnvRunStatus, Environment,
    EscalationConfig, ExecutionLog, ExecutionRun, IssueTracker,
    MailConfig, MailRecipient, MailTemplate, OracleDatabase,
    RerunQueue, RunStepLog, Schedule, Server, ServerCheckResult,
    SystemConfig, TestCatalog, TestOverride,
)
from healthcheck.scheduler_service import (
    restart_scheduler, run_customer_now, run_now_sync,
    scheduler_status, start_scheduler, stop_scheduler,
)

is_admin = user_passes_test(lambda u: u.is_staff)
_DB = "healthcheck_db"


def _using(qs):
    return qs.using(_DB)


# ──────────────────────────────────────────────────────────────
# AUTH
# ──────────────────────────────────────────────────────────────

def login_view(request):
    from django.contrib.auth import authenticate, login
    error = None
    if request.method == "POST":
        u = authenticate(request,
                         username=request.POST.get("username"),
                         password=request.POST.get("password"))
        if u:
            login(request, u)
            return redirect(request.GET.get("next", "/"))
        error = "Invalid username or password."
    return render(request, "healthcheck/login.html", {"error": error})


def logout_view(request):
    from django.contrib.auth import logout
    logout(request)
    return redirect("/login/")


# ──────────────────────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    runs = _using(
        ExecutionRun.objects.select_related("customer")
        .order_by("-id")[:20]
    )

    open_issues = _using(
        IssueTracker.objects.select_related("customer", "test_catalog")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")[:20]
    )

    pending_reruns = _using(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status="PENDING")
        .order_by("scheduled_at")[:10]
    )

    paused_escalations = _using(
        EscalationConfig.objects.select_related("customer")
        .filter(is_paused=True)
    )

    recent_alerts = _using(
        AlertHistory.objects.order_by("-sent_at")[:10]
    )

    sched_status = scheduler_status()

    ctx = {
        "runs": runs,
        "open_issues": open_issues,
        "pending_reruns": pending_reruns,
        "paused_escalations": paused_escalations,
        "recent_alerts": recent_alerts,
        "scheduler_status": sched_status,
        "active_page": "dashboard",
    }
    return render(request, "healthcheck/dashboard.html", ctx)


# ──────────────────────────────────────────────────────────────
# REPORTS (list + detail + download)
# ──────────────────────────────────────────────────────────────

@login_required
def reports_list(request):
    qs = _using(
        ExecutionRun.objects.select_related("customer")
        .filter(status__in=["COMPLETED", "PARTIAL", "FAILED"])
        .order_by("-id")
    )

    # Filters
    customer_id = request.GET.get("customer")
    env_type    = request.GET.get("env")
    status      = request.GET.get("status")
    if customer_id:
        qs = qs.filter(customer_id=customer_id)
    if env_type:
        qs = qs.filter(env_types__contains=env_type)
    if status:
        qs = qs.filter(status=status)

    paginator = Paginator(qs, 20)
    page = paginator.get_page(request.GET.get("page", 1))

    customers = _using(Customer.objects.filter(is_active=True).order_by("name"))
    ctx = {
        "page_obj":  page,
        "customers": customers,
        "active_page": "reports",
        "selected_customer": customer_id,
        "selected_env": env_type,
        "selected_status": status,
    }
    return render(request, "healthcheck/reports_list.html", ctx)


@login_required
def report_detail(request, run_id):
    run = get_object_or_404(_using(
        ExecutionRun.objects.select_related("customer")), id=run_id)

    env_statuses = _using(
        EnvRunStatus.objects.filter(run=run).order_by("env_type"))

    # Collect all server+DB check results per env
    env_data = []
    has_action = False
    for es in env_statuses:
        server_checks = _using(
            ServerCheckResult.objects.select_related("server")
            .filter(env_status=es))
        db_checks = _using(
            DBCheckResult.objects.select_related("server", "oracle_db")
            .filter(env_status=es))

        for sc in server_checks:
            if sc.any_action():
                has_action = True
        for dc in db_checks:
            if dc.any_action():
                has_action = True

        # Tablespace and RMAN per DB check
        db_check_data = []
        for dc in db_checks:
            ts_rows = _using(
                TablespaceUsage.objects.filter(db_check=dc)
                .order_by("-used_pct")) if hasattr(dc, "id") else []
            rman_rows = _using(
                RMANBackupDetail.objects.filter(db_check=dc)) if hasattr(dc, "id") else []
            db_check_data.append({
                "check":    dc,
                "ts_rows":  _using(
                    __import__("healthcheck.models", fromlist=["TablespaceUsage"])
                    .TablespaceUsage.objects.filter(db_check=dc).order_by("-used_pct")),
                "rman_rows": _using(
                    __import__("healthcheck.models", fromlist=["RMANBackupDetail"])
                    .RMANBackupDetail.objects.filter(db_check=dc)),
            })

        env_data.append({
            "env_status":    es,
            "server_checks": server_checks,
            "db_checks":     db_check_data,
        })

    # Step log
    step_log = _using(RunStepLog.objects.filter(run=run).order_by("step_order"))

    # Action filter
    action_filter = request.GET.get("action")  # "yes" or None

    # Alert history for this run
    alerts = _using(
        AlertHistory.objects.filter(run=run).order_by("-sent_at"))

    ctx = {
        "run":           run,
        "env_data":      env_data,
        "step_log":      step_log,
        "alerts":        alerts,
        "has_action":    has_action,
        "action_filter": action_filter,
        "active_page":   "reports",
    }
    return render(request, "healthcheck/report_detail.html", ctx)


@login_required
def download_excel(request, run_id):
    """Generate (or re-serve) the Excel file for a run."""
    import sys
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader
    from engine.reports.excel_generator import ExcelReportGenerator

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            gen = ExcelReportGenerator(db, run_id,
                                       __import__("engine.core.logger",
                                                  fromlist=["SilentLogger"]).SilentLogger())
            filepath, title = gen.generate()

        # Add download date to filename
        dl_date = datetime.now().strftime("%d-%b-%Y")
        orig_name = os.path.basename(filepath)
        # Insert download date before .xlsx
        dl_name = orig_name.replace(".xlsx", f"_DL-{dl_date}.xlsx")

        response = FileResponse(
            open(filepath, "rb"),
            content_type=(
                "application/vnd.openxmlformats-officedocument"
                ".spreadsheetml.sheet"),
            as_attachment=True,
            filename=dl_name,
        )
        return response
    except Exception as exc:
        messages.error(request, f"Could not generate Excel: {exc}")
        return redirect("report_detail", run_id=run_id)


# ──────────────────────────────────────────────────────────────
# LOGS (view + download)
# ──────────────────────────────────────────────────────────────

@login_required
def run_logs(request, run_id):
    run = get_object_or_404(
        _using(ExecutionRun.objects.select_related("customer")), id=run_id)

    qs = _using(
        ExecutionLog.objects.filter(run=run).order_by("logged_at"))

    level_filter = request.GET.get("level")
    if level_filter:
        qs = qs.filter(log_level=level_filter)

    paginator = Paginator(qs, 200)
    page = paginator.get_page(request.GET.get("page", 1))

    ctx = {
        "run":          run,
        "page_obj":     page,
        "level_filter": level_filter,
        "log_levels":   ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        "active_page":  "reports",
    }
    return render(request, "healthcheck/run_logs.html", ctx)


@login_required
def download_logs(request, run_id):
    """Download all logs for a run as plain text."""
    run = get_object_or_404(
        _using(ExecutionRun.objects.select_related("customer")), id=run_id)
    logs = _using(ExecutionLog.objects.filter(run=run).order_by("logged_at"))

    from django.http import HttpResponse
    lines = [
        f"{log.logged_at.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} "
        f"[{log.log_level:<8}] [{log.py_file}::{log.py_function}():L{log.py_line}] "
        f"{log.message}"
        for log in logs
    ]
    content = "\n".join(lines)
    fname = f"run_{run_id}_{run.customer.name}_{datetime.now().strftime('%Y%m%d')}.log"
    resp = HttpResponse(content, content_type="text/plain")
    resp["Content-Disposition"] = f'attachment; filename="{fname}"'
    return resp


# ──────────────────────────────────────────────────────────────
# ESCALATION (user view)
# ──────────────────────────────────────────────────────────────

@login_required
def escalation_view(request):
    issues = _using(
        IssueTracker.objects.select_related(
            "customer", "test_catalog",
            "first_failed_run", "last_failed_run")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")
    )
    esc_configs = _using(
        EscalationConfig.objects.select_related("customer").all())

    ctx = {
        "issues":      issues,
        "esc_configs": esc_configs,
        "active_page": "escalation",
    }
    return render(request, "healthcheck/escalation.html", ctx)


# ──────────────────────────────────────────────────────────────
# RERUN (user view + admin action)
# ──────────────────────────────────────────────────────────────

@login_required
def rerun_view(request):
    pending = _using(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")
    )
    recent = _using(
        RerunQueue.objects.select_related("customer", "original_run")
        .exclude(status="PENDING")
        .order_by("-created_at")[:20]
    )
    ctx = {
        "pending":     pending,
        "recent":      recent,
        "active_page": "rerun",
    }
    return render(request, "healthcheck/rerun.html", ctx)


@login_required
@is_admin
@require_POST
def trigger_rerun(request, run_id):
    """Admin: manually trigger a rerun for a failed run."""
    import sys
    engine_path = os.path.join(os.path.dirname(__file__), "engine")
    if engine_path not in sys.path:
        sys.path.insert(0, engine_path)

    from engine.core.db_manager import DBManager
    from engine.core.config import ConfigLoader

    try:
        with DBManager() as db:
            ConfigLoader.load(db)
            run = db.fetch_one("SELECT * FROM execution_runs WHERE id=%s", (run_id,))
            if not run:
                messages.error(request, f"Run #{run_id} not found.")
                return redirect("rerun")
            new_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id, env_types, run_type, status, triggered_by,
                    rerun_of_run_id, rerun_attempt)
                   VALUES (%s,%s,'RERUN','PENDING','admin:rerun',%s,1)""",
                (run["customer_id"], run["env_types"], run_id))

        from healthcheck.scheduler_service import _run_in_thread
        import threading
        t = threading.Thread(target=_run_in_thread, args=(new_id,),
                             daemon=True, name=f"hc_rerun_{new_id}")
        t.start()
        messages.success(request, f"Rerun #{new_id} started in background.")
    except Exception as exc:
        messages.error(request, f"Error starting rerun: {exc}")

    return redirect("rerun")


# ──────────────────────────────────────────────────────────────
# ADMIN: Manual Run
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def manual_run(request):
    customers = _using(Customer.objects.filter(is_active=True).order_by("name"))
    if request.method == "POST":
        customer_id = request.POST.get("customer_id")
        env_types   = request.POST.get("env_types", "").upper().strip()
        if customer_id and env_types:
            run_id = run_customer_now(int(customer_id), env_types)
            if run_id:
                messages.success(
                    request,
                    f"Run #{run_id} started in background. "
                    f"Check dashboard for status.")
                return redirect("dashboard")
            else:
                messages.error(request, "Failed to start run. Check logs.")
        else:
            messages.error(request, "Please select a customer and environment.")
    ctx = {
        "customers":   customers,
        "active_page": "manual_run",
    }
    return render(request, "healthcheck/manual_run.html", ctx)


# ──────────────────────────────────────────────────────────────
# ADMIN: Scheduler control
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def scheduler_view(request):
    sched_status = scheduler_status()
    schedules    = _using(
        Schedule.objects.select_related("customer").order_by("customer__name"))
    ctx = {
        "sched_status": sched_status,
        "schedules":    schedules,
        "active_page":  "scheduler",
    }
    return render(request, "healthcheck/scheduler.html", ctx)


@login_required
@is_admin
@require_POST
def scheduler_action(request):
    action = request.POST.get("action")
    if action == "start":
        start_scheduler()
        messages.success(request, "Scheduler started.")
    elif action == "stop":
        stop_scheduler()
        messages.success(request, "Scheduler stopped.")
    elif action == "restart":
        restart_scheduler()
        messages.success(request, "Scheduler restarted and schedules reloaded.")
    elif action == "run_now":
        sched_id = int(request.POST.get("schedule_id", 0))
        run_id   = run_now_sync(sched_id)
        if run_id:
            messages.success(
                request, f"Schedule fired — Run #{run_id} running in background.")
        else:
            messages.error(request, "Could not fire schedule.")
    return redirect("scheduler")


# ──────────────────────────────────────────────────────────────
# ADMIN: Customer / Environment / Config management
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def customer_list(request):
    customers = _using(Customer.objects.prefetch_related(
        "environment_set").order_by("name"))
    ctx = {"customers": customers, "active_page": "customers"}
    return render(request, "healthcheck/customer_list.html", ctx)


@login_required
@is_admin
def customer_form(request, pk=None):
    from healthcheck.forms import CustomerForm
    instance = None
    if pk:
        instance = get_object_or_404(_using(Customer.objects), pk=pk)
    if request.method == "POST":
        form = CustomerForm(request.POST, instance=instance)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.save(using=_DB)
            messages.success(request, "Customer saved.")
            return redirect("customer_list")
    else:
        form = CustomerForm(instance=instance)
    ctx = {"form": form, "instance": instance, "active_page": "customers"}
    return render(request, "healthcheck/customer_form.html", ctx)


@login_required
@is_admin
@require_POST
def customer_delete(request, pk):
    obj = get_object_or_404(_using(Customer.objects), pk=pk)
    name = obj.name
    obj.delete(using=_DB)
    messages.success(request, f"Customer '{name}' deleted.")
    return redirect("customer_list")


@login_required
@is_admin
def environment_form(request, pk=None):
    from healthcheck.forms import EnvironmentForm
    instance = None
    if pk:
        instance = get_object_or_404(_using(Environment.objects), pk=pk)
    if request.method == "POST":
        form = EnvironmentForm(request.POST, instance=instance)
        if form.is_valid():
            # Encrypt password
            obj = form.save(commit=False)
            plain_pwd = form.cleaned_data.get("plain_password")
            if plain_pwd:
                import sys
                engine_path = os.path.join(os.path.dirname(__file__), "engine")
                if engine_path not in sys.path:
                    sys.path.insert(0, engine_path)
                from engine.utils.crypto import encrypt_password
                obj.server_pwd = encrypt_password(plain_pwd)
            obj.save(using=_DB)
            messages.success(request, "Environment saved.")
            return redirect("customer_list")
    else:
        form = EnvironmentForm(instance=instance)
    ctx = {"form": form, "instance": instance, "active_page": "customers"}
    return render(request, "healthcheck/environment_form.html", ctx)


@login_required
@is_admin
def config_list(request):
    sys_configs  = _using(SystemConfig.objects.all().order_by("config_group", "config_key"))
    mail_configs = _using(MailConfig.objects.all())
    mail_rcpts   = _using(MailRecipient.objects.select_related("customer").all())
    ctx = {
        "sys_configs":  sys_configs,
        "mail_configs": mail_configs,
        "mail_rcpts":   mail_rcpts,
        "active_page":  "config",
    }
    return render(request, "healthcheck/config_list.html", ctx)


@login_required
@is_admin
@require_POST
def config_update(request, pk):
    obj = get_object_or_404(_using(SystemConfig.objects), pk=pk)
    new_val = request.POST.get("config_value", "")
    obj.config_value = new_val
    obj.save(using=_DB)
    messages.success(request, f"Config '{obj.config_key}' updated.")
    return redirect("config_list")


# ──────────────────────────────────────────────────────────────
# ESCALATION admin controls
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
@require_POST
def pause_escalation(request, pk):
    obj = get_object_or_404(_using(EscalationConfig.objects), pk=pk)
    hours = int(request.POST.get("hours", 168))
    reason = request.POST.get("reason", "Manual pause")
    from datetime import timedelta
    obj.is_paused    = True
    obj.paused_until = datetime.utcnow() + timedelta(hours=hours)
    obj.pause_reason = reason
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation paused for {obj.customer.name}/{obj.env_type} "
        f"for {hours} hours.")
    return redirect("escalation")


@login_required
@is_admin
@require_POST
def resume_escalation(request, pk):
    obj = get_object_or_404(_using(EscalationConfig.objects), pk=pk)
    obj.is_paused    = False
    obj.paused_until = None
    obj.pause_reason = ""
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation resumed for {obj.customer.name}/{obj.env_type}.")
    return redirect("escalation")


# ──────────────────────────────────────────────────────────────
# API: Live run status (for dashboard auto-refresh)
# ──────────────────────────────────────────────────────────────

@login_required
def api_run_status(request, run_id):
    run = get_object_or_404(
        _using(ExecutionRun.objects.select_related("customer")), id=run_id)
    return JsonResponse({
        "id":          run.id,
        "status":      run.status,
        "latest_step": run.latest_step or "",
        "started_at":  run.started_at.isoformat() if run.started_at else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    })


@login_required
def api_scheduler_status(request):
    return JsonResponse(scheduler_status())


# ──────────────────────────────────────────────────────────────
# Missing model imports for report_detail (fix)
# ──────────────────────────────────────────────────────────────

from healthcheck.models import TablespaceUsage, RMANBackupDetail  # noqa: E402, F401

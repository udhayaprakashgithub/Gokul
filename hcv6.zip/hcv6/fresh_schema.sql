-- ============================================================
-- Health Check v5  --  FRESH COMPLETE SCHEMA
-- Database: hc_v5
--
-- HOW TO USE:
--   mysql -u admin -p < fresh_schema.sql
--
-- Includes:
--   • All tables with proper FK constraints
--   • All default configuration values
--   • MMS / DEV test customer (from existing data)
--   • Test catalog (36 tests)
--   • Oracle queries
--   • SMTP config (from hcdata.sql)
--   • Email recipients (from hcdata.sql)
--   • Email templates (HTML)
--   • Escalation config for MMS/DEV
--   • One weekly schedule for MMS/DEV
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP DATABASE IF EXISTS `hc_v5`;
CREATE DATABASE `hc_v5` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `hc_v5`;

-- ============================================================
-- TABLE 1: customers
-- ============================================================
CREATE TABLE `customers` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(255) NOT NULL,
  `code`         VARCHAR(50)  NOT NULL UNIQUE  COMMENT 'Short code used in CLI e.g. MMS',
  `tenant_type`  ENUM('Single','Multi') NOT NULL DEFAULT 'Single',
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`        VARCHAR(500) NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 2: environments
-- ============================================================
CREATE TABLE `environments` (
  `id`          INT          NOT NULL AUTO_INCREMENT,
  `customer_id` INT          NOT NULL,
  `env_type`    ENUM('PRD','VAL','DEV') NOT NULL,
  `server_user` VARCHAR(255) NOT NULL   COMMENT 'Windows domain user e.g. DOMAIN\\user',
  `server_pwd`  VARCHAR(700) NOT NULL   COMMENT 'AES-256-CBC encrypted by encrypt-password command',
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`       VARCHAR(500) NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_env_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 3: servers
-- ============================================================
CREATE TABLE `servers` (
  `id`                   INT          NOT NULL AUTO_INCREMENT,
  `env_id`               INT          NOT NULL,
  `server_role`          ENUM('DB','Web','ESM','OAM') NOT NULL,
  `server_name`          VARCHAR(100) NOT NULL  COMMENT 'Display name e.g. Database Server',
  `host`                 VARCHAR(255) NOT NULL  COMMENT 'IP or hostname',
  `service_listeners`    TEXT         NULL      COMMENT 'Comma-separated Windows service names to check',
  `task_scheduler_names` TEXT         NULL      COMMENT 'Comma-separated scheduled task names to check',
  `is_active`            TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`                VARCHAR(500) NULL,
  `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_srv_env` FOREIGN KEY (`env_id`) REFERENCES `environments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 4: oracle_databases
-- ============================================================
CREATE TABLE `oracle_databases` (
  `id`        INT          NOT NULL AUTO_INCREMENT,
  `server_id` INT          NOT NULL,
  `db_name`   VARCHAR(255) NOT NULL  COMMENT 'Oracle service/SID name',
  `db_type`   ENUM('Argus','FMW')    NOT NULL,
  `db_user`   VARCHAR(255) NOT NULL,
  `db_pwd`    VARCHAR(700) NOT NULL  COMMENT 'AES-256-CBC encrypted',
  `port`      INT          NOT NULL DEFAULT 1521,
  `is_active` TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`     VARCHAR(500) NULL,
  `created_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_db_srv` FOREIGN KEY (`server_id`) REFERENCES `servers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 5: test_catalog  (36 standard tests)
-- ============================================================
CREATE TABLE `test_catalog` (
  `id`            INT          NOT NULL,
  `test_name`     VARCHAR(500) NOT NULL,
  `category`      ENUM('INFO','SERVER','DATABASE') NOT NULL DEFAULT 'SERVER',
  `server_role`   ENUM('DB','Web','ESM','OAM','ALL') NOT NULL DEFAULT 'ALL',
  `db_type`       ENUM('Argus','FMW','ALL') NOT NULL DEFAULT 'ALL',
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1  COMMENT 'Global on/off. Can be overridden per customer in test_override',
  `display_order` INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 6: test_override  (per-customer/env test enable/disable)
-- ============================================================
CREATE TABLE `test_override` (
  `id`              INT          NOT NULL AUTO_INCREMENT,
  `customer_id`     INT          NOT NULL,
  `env_type`        ENUM('PRD','VAL','DEV') NULL  COMMENT 'NULL = applies to ALL envs of this customer',
  `test_catalog_id` INT          NOT NULL,
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 0  COMMENT '0=disabled for this customer/env, 1=enabled',
  `reason`          VARCHAR(300) NULL,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_test_override` (`customer_id`,`env_type`,`test_catalog_id`),
  CONSTRAINT `fk_to_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_to_test`     FOREIGN KEY (`test_catalog_id`) REFERENCES `test_catalog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Override global test_catalog.is_active for a specific customer/env';

-- ============================================================
-- TABLE 7: oracle_queries
-- ============================================================
CREATE TABLE `oracle_queries` (
  `id`          INT          NOT NULL AUTO_INCREMENT,
  `query_key`   VARCHAR(100) NOT NULL UNIQUE,
  `query_sql`   TEXT         NOT NULL,
  `description` VARCHAR(500) NOT NULL,
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 8: mail_config  (SMTP server settings)
-- Only ONE row should have is_active=1 at a time.
-- ============================================================
CREATE TABLE `mail_config` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `config_name`  VARCHAR(100) NOT NULL DEFAULT 'default'  COMMENT 'Logical name e.g. default, backup',
  `smtp_host`    VARCHAR(255) NOT NULL,
  `smtp_port`    INT          NOT NULL DEFAULT 587,
  `use_tls`      TINYINT(1)   NOT NULL DEFAULT 1,
  `smtp_user`    VARCHAR(255) NOT NULL,
  `smtp_password` VARCHAR(500) NOT NULL  COMMENT 'Plain AWS SES SMTP password',
  `from_address` VARCHAR(255) NOT NULL,
  `reply_to`     VARCHAR(255) NULL,
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`        VARCHAR(300) NULL,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'SMTP connection settings. Set is_active=1 for the one to use.';

-- ============================================================
-- TABLE 9: mail_recipients  (TO/CC per alert type, per customer)
-- customer_id NULL = global default used for ALL customers.
-- customer_id = N = overrides global for that specific customer.
-- ============================================================
CREATE TABLE `mail_recipients` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `alert_type`   ENUM('SUCCESS','FAILURE','ESCALATION','RERUN_FAILURE') NOT NULL,
  `customer_id`  INT          NULL  COMMENT 'NULL = global default for all customers',
  `to_addresses` TEXT         NOT NULL  COMMENT 'Comma-separated TO emails',
  `cc_addresses` TEXT         NULL      COMMENT 'Comma-separated CC emails',
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`        VARCHAR(300) NULL,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mr_lookup` (`alert_type`,`customer_id`),
  CONSTRAINT `fk_mr_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Email recipients per alert type. Customer-specific overrides global.';

-- ============================================================
-- TABLE 10: mail_templates  (Subject + HTML body per email type)
-- ============================================================
CREATE TABLE `mail_templates` (
  `id`               INT          NOT NULL AUTO_INCREMENT,
  `template_key`     VARCHAR(100) NOT NULL UNIQUE
                       COMMENT 'Keys: success | failure | escalation | rerun_failure',
  `subject_template` VARCHAR(500) NOT NULL  COMMENT 'Use {customer}, {env}, {ordinal} etc.',
  `body_html`        MEDIUMTEXT   NOT NULL  COMMENT 'Full HTML body with {placeholders}',
  `is_active`        TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`            VARCHAR(300) NULL,
  `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Email subject and HTML body templates. Edit body_html to customise emails.';

-- ============================================================
-- TABLE 11: system_config  (operational settings by group)
-- ============================================================
CREATE TABLE `system_config` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `config_key`   VARCHAR(200) NOT NULL UNIQUE,
  `config_value` TEXT         NOT NULL,
  `config_group` VARCHAR(50)  NOT NULL DEFAULT 'general'
                   COMMENT 'Groups: paths | operational | display',
  `description`  VARCHAR(500) NOT NULL DEFAULT '',
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Runtime operational config. All email/SMTP config is in mail_config and mail_recipients.';

-- ============================================================
-- TABLE 12: escalation_config  (per customer+env escalation rules)
-- ============================================================
CREATE TABLE `escalation_config` (
  `id`                    INT          NOT NULL AUTO_INCREMENT,
  `customer_id`           INT          NOT NULL,
  `env_type`              ENUM('PRD','VAL','DEV') NOT NULL,
  `threshold`             INT          NOT NULL DEFAULT 3
                            COMMENT 'Consecutive failures before first escalation email',
  `interval_hours`        INT          NOT NULL DEFAULT 168
                            COMMENT 'Minimum hours between escalation emails for same issue',
  `max_escalations`       INT          NOT NULL DEFAULT 0
                            COMMENT '0 = unlimited; N = stop escalating after N emails',
  `is_paused`             TINYINT(1)   NOT NULL DEFAULT 0
                            COMMENT '1 = escalation emails paused right now',
  `paused_until`          DATETIME     NULL
                            COMMENT 'Auto-resume at this time (NULL = manual resume required)',
  `pause_reason`          VARCHAR(300) NULL,
  `notify_rerun_fail`     TINYINT(1)   NOT NULL DEFAULT 1
                            COMMENT '1 = send email when all reruns exhausted',
  `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_esc_cfg` (`customer_id`,`env_type`),
  CONSTRAINT `fk_esc_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Per-customer+env escalation settings. Pause/resume here.';

-- ============================================================
-- TABLE 13: schedules  (per-customer cron schedule)
-- ============================================================
CREATE TABLE `schedules` (
  `id`              INT          NOT NULL AUTO_INCREMENT,
  `customer_id`     INT          NOT NULL,
  `env_types`       VARCHAR(50)  NOT NULL  COMMENT 'Comma-sep e.g. PRD or DEV,VAL',
  `schedule_name`   VARCHAR(200) NOT NULL,
  `cron_expression` VARCHAR(100) NOT NULL  COMMENT 'Standard 5-field cron e.g. 0 1 * * 0',
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `last_run_at`     DATETIME     NULL,
  `next_run_at`     DATETIME     NULL,
  `notes`           VARCHAR(300) NULL,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_sched_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 14: execution_runs
-- ============================================================
CREATE TABLE `execution_runs` (
  `id`             INT          NOT NULL AUTO_INCREMENT,
  `schedule_id`    INT          NULL,
  `customer_id`    INT          NOT NULL,
  `env_types`      VARCHAR(50)  NOT NULL,
  `run_type`       ENUM('SCHEDULED','MANUAL','RERUN') NOT NULL DEFAULT 'SCHEDULED',
  `status`         ENUM('PENDING','IN_PROGRESS','COMPLETED','FAILED','PARTIAL') NOT NULL DEFAULT 'PENDING',
  `triggered_by`   VARCHAR(100) NOT NULL DEFAULT 'system',
  `started_at`     DATETIME     NULL,
  `completed_at`   DATETIME     NULL,
  `error_summary`  TEXT         NULL,
  `rerun_of_run_id` INT         NULL,
  `rerun_attempt`  TINYINT      NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_run_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 15: env_run_status
-- ============================================================
CREATE TABLE `env_run_status` (
  `id`            INT          NOT NULL AUTO_INCREMENT,
  `run_id`        INT          NOT NULL,
  `customer_id`   INT          NOT NULL,
  `env_type`      VARCHAR(10)  NOT NULL,
  `tenant`        VARCHAR(50)  NOT NULL DEFAULT '',
  `status`        ENUM('PENDING','IN_PROGRESS','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  `error_message` TEXT         NULL,
  `started_at`    DATETIME     NULL,
  `completed_at`  DATETIME     NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_ers_run` FOREIGN KEY (`run_id`) REFERENCES `execution_runs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 16: execution_logs
-- ============================================================
CREATE TABLE `execution_logs` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `run_id`      INT          NOT NULL,
  `customer_id` INT          NULL,
  `env_type`    VARCHAR(10)  NULL,
  `server_id`   INT          NULL,
  `db_id`       INT          NULL,
  `log_level`   ENUM('DEBUG','INFO','WARNING','ERROR','CRITICAL') NOT NULL DEFAULT 'INFO',
  `py_file`     VARCHAR(200) NOT NULL DEFAULT '',
  `py_module`   VARCHAR(200) NOT NULL DEFAULT '',
  `py_function` VARCHAR(200) NOT NULL DEFAULT '',
  `py_line`     INT          NULL,
  `message`     TEXT         NOT NULL,
  `logged_at`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_log_run`          (`run_id`),
  KEY `idx_log_customer_env` (`customer_id`,`env_type`),
  KEY `idx_log_level`        (`log_level`),
  CONSTRAINT `fk_log_run` FOREIGN KEY (`run_id`) REFERENCES `execution_runs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 17: server_check_results
-- ============================================================
CREATE TABLE `server_check_results` (
  `id`                    INT          NOT NULL AUTO_INCREMENT,
  `env_status_id`         INT          NOT NULL,
  `server_id`             INT          NOT NULL,
  `connection_status`     VARCHAR(200) NOT NULL DEFAULT '',
  `connection_ok`         TINYINT(1)   NOT NULL DEFAULT 0,
  `win_update_status`     TEXT         NULL,
  `win_update_action`     TINYINT(1)   NULL,
  `task_scheduler_detail` TEXT         NULL,
  `task_scheduler_action` TINYINT(1)   NULL,
  `listeners_detail`      TEXT         NULL,
  `listeners_action`      TINYINT(1)   NULL,
  `disk_space_detail`     TEXT         NULL,
  `disk_space_action`     TINYINT(1)   NULL,
  `checked_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_scr_env` FOREIGN KEY (`env_status_id`) REFERENCES `env_run_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 18: db_check_results
-- ============================================================
CREATE TABLE `db_check_results` (
  `id`                      INT          NOT NULL AUTO_INCREMENT,
  `env_status_id`           INT          NOT NULL,
  `server_id`               INT          NOT NULL,
  `oracle_db_id`            INT          NOT NULL,
  `connection_status`       VARCHAR(200) NOT NULL DEFAULT '',
  `connection_ok`           TINYINT(1)   NOT NULL DEFAULT 0,
  `schema_password_detail`  TEXT         NULL,
  `schema_password_action`  TINYINT(1)   NULL,
  `tablespace_detail`       TEXT         NULL,
  `tablespace_action`       TINYINT(1)   NULL,
  `archive_mode`            VARCHAR(50)  NULL,
  `archive_mode_action`     TINYINT(1)   NULL,
  `archive_log_detail`      TEXT         NULL,
  `archive_log_action`      TINYINT(1)   NULL,
  `archive_path_detail`     TEXT         NULL,
  `archive_path_action`     TINYINT(1)   NULL,
  `rman_detail`             TEXT         NULL,
  `rman_action`             TINYINT(1)   NULL,
  `checked_at`              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_dcr_env` FOREIGN KEY (`env_status_id`) REFERENCES `env_run_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 19: tablespace_usage
-- ============================================================
CREATE TABLE `tablespace_usage` (
  `id`               INT           NOT NULL AUTO_INCREMENT,
  `db_check_id`      INT           NOT NULL,
  `tablespace_name`  VARCHAR(100)  NOT NULL,
  `used_space_kb`    BIGINT        NULL,
  `total_space_kb`   BIGINT        NULL,
  `used_pct`         DECIMAL(7,2)  NULL,
  `recorded_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_ts_db` FOREIGN KEY (`db_check_id`) REFERENCES `db_check_results` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 20: rman_backup_details
-- ============================================================
CREATE TABLE `rman_backup_details` (
  `id`                 INT          NOT NULL AUTO_INCREMENT,
  `db_check_id`        INT          NOT NULL,
  `start_time`         VARCHAR(100) NULL,
  `end_time`           VARCHAR(100) NULL,
  `output_device_type` VARCHAR(50)  NULL,
  `backup_type`        VARCHAR(50)  NULL,
  `time_taken_display` VARCHAR(50)  NULL,
  `status`             VARCHAR(100) NULL,
  `recorded_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_rman_db` FOREIGN KEY (`db_check_id`) REFERENCES `db_check_results` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 21: issue_tracker
-- ============================================================
CREATE TABLE `issue_tracker` (
  `id`                     INT          NOT NULL AUTO_INCREMENT,
  `customer_id`            INT          NOT NULL,
  `env_type`               VARCHAR(10)  NOT NULL,
  `server_id`              INT          NULL,
  `oracle_db_id`           INT          NULL,
  `test_catalog_id`        INT          NOT NULL,
  `first_failed_run_id`    INT          NOT NULL,
  `last_failed_run_id`     INT          NOT NULL,
  `consecutive_failures`   INT          NOT NULL DEFAULT 1,
  `total_failures`         INT          NOT NULL DEFAULT 1,
  `last_error_detail`      TEXT         NULL,
  `status`                 ENUM('OPEN','RESOLVED','ESCALATED') NOT NULL DEFAULT 'OPEN',
  `resolved_run_id`        INT          NULL,
  `last_escalated_at`      DATETIME     NULL  COMMENT 'When last escalation email was sent for this issue',
  `escalation_send_count`  INT          NOT NULL DEFAULT 0,
  `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_issue_lookup` (`customer_id`,`env_type`,`test_catalog_id`),
  CONSTRAINT `fk_issue_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_issue_test`     FOREIGN KEY (`test_catalog_id`) REFERENCES `test_catalog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 22: alert_history  (every email sent/attempted)
-- ============================================================
CREATE TABLE `alert_history` (
  `id`                   INT          NOT NULL AUTO_INCREMENT,
  `run_id`               INT          NULL,
  `issue_id`             INT          NULL,
  `alert_type`           ENUM('SUCCESS','FAILURE','ESCALATION','RERUN_FAILURE') NOT NULL,
  `customer_id`          INT          NULL,
  `customer_name`        VARCHAR(255) NULL,
  `env_type`             VARCHAR(10)  NULL,
  `run_env_types`        VARCHAR(50)  NULL,
  `subject`              VARCHAR(500) NOT NULL,
  `recipients_to`        TEXT         NOT NULL,
  `recipients_cc`        TEXT         NULL,
  `escalation_count`     INT          NOT NULL DEFAULT 0,
  `escalation_ordinal`   VARCHAR(50)  NULL  COMMENT 'e.g. First, Second, Third',
  `attachment_name`      VARCHAR(500) NULL,
  `attachment_size_bytes` BIGINT      NULL,
  `triggered_by`         VARCHAR(100) NULL,
  `send_status`          ENUM('SENT','FAILED') NOT NULL DEFAULT 'SENT',
  `error_message`        TEXT         NULL,
  `sent_at`              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ah_customer`   (`customer_id`),
  KEY `idx_ah_alert_type` (`alert_type`),
  KEY `idx_ah_sent_at`    (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 23: rerun_queue
-- ============================================================
CREATE TABLE `rerun_queue` (
  `id`               INT          NOT NULL AUTO_INCREMENT,
  `original_run_id`  INT          NOT NULL,
  `customer_id`      INT          NOT NULL,
  `env_types`        VARCHAR(50)  NOT NULL,
  `attempt_number`   TINYINT      NOT NULL DEFAULT 1,
  `max_attempts`     TINYINT      NOT NULL DEFAULT 3,
  `status`           ENUM('PENDING','IN_PROGRESS','COMPLETED','EXHAUSTED') NOT NULL DEFAULT 'PENDING',
  `scheduled_at`     DATETIME     NOT NULL,
  `started_at`       DATETIME     NULL,
  `completed_at`     DATETIME     NULL,
  `last_error`       TEXT         NULL,
  `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_rq_run` FOREIGN KEY (`original_run_id`) REFERENCES `execution_runs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- ============================================================
--   DATA SECTION
-- ============================================================
-- ============================================================

-- ============================================================
-- TEST CATALOG (36 standard tests)
-- is_active=1 means enabled globally.
-- Disable per-customer using test_override table.
-- ============================================================
INSERT INTO `test_catalog` (`id`,`test_name`,`category`,`server_role`,`db_type`,`display_order`) VALUES
(1,  'Customer',                                       'INFO',     'ALL', 'ALL',   1),
(2,  'Environment',                                    'INFO',     'ALL', 'ALL',   2),
(3,  'Instance',                                       'INFO',     'ALL', 'ALL',   3),
(4,  'Private IP of DB Server',                        'INFO',     'DB',  'ALL',   4),
(5,  'Private IP of Web Server',                       'INFO',     'Web', 'ALL',   5),
(6,  'Private IP of ESM Server',                       'INFO',     'ESM', 'ALL',   6),
(7,  'Private IP of OAM Server',                       'INFO',     'OAM', 'ALL',   7),
(8,  'Connection Status (DB Server)',                  'SERVER',   'DB',  'ALL',   8),
(9,  'Connection Status (Web Server)',                 'SERVER',   'Web', 'ALL',   9),
(10, 'Connection Status (ESM Server)',                 'SERVER',   'ESM', 'ALL',   10),
(11, 'Connection Status (OAM Server)',                 'SERVER',   'OAM', 'ALL',   11),
(12, 'Service Listeners (Argus and FMW)',              'SERVER',   'DB',  'ALL',   12),
(13, 'Database name of Oracle Service (Argus)',        'DATABASE', 'DB',  'Argus', 13),
(14, 'Database name of Oracle Service (FMW)',          'DATABASE', 'DB',  'FMW',   14),
(15, 'Database Connection (Argus)',                    'DATABASE', 'DB',  'Argus', 15),
(16, 'Database Connection (FMW)',                      'DATABASE', 'DB',  'FMW',   16),
(17, 'Schema Password check Oracle Service (Argus)',   'DATABASE', 'DB',  'Argus', 17),
(18, 'Schema Password check Oracle Service (FMW)',     'DATABASE', 'DB',  'FMW',   18),
(19, 'Table Space availability check (Argus)',         'DATABASE', 'DB',  'Argus', 19),
(20, 'Table Space availability check (FMW)',           'DATABASE', 'DB',  'FMW',   20),
(21, 'Archive Mode and Automatic Archival (Argus)',    'DATABASE', 'DB',  'Argus', 21),
(22, 'Archive Directory check (Argus)',                'DATABASE', 'DB',  'Argus', 22),
(23, 'Last 8 Day Archive Log Deleted (Argus)',         'DATABASE', 'DB',  'Argus', 23),
(24, 'RMAN Backup (Argus)',                            'DATABASE', 'DB',  'Argus', 24),
(25, 'Windows Auto Update Check (DB Server)',          'SERVER',   'DB',  'ALL',   25),
(26, 'Windows Auto Update Check (Web Server)',         'SERVER',   'Web', 'ALL',   26),
(27, 'Windows Auto Update Check (ESM Server)',         'SERVER',   'ESM', 'ALL',   27),
(28, 'Windows Auto Update Check (OAM Server)',         'SERVER',   'OAM', 'ALL',   28),
(29, 'Disk Space Availability - DB Server',            'SERVER',   'DB',  'ALL',   29),
(30, 'Disk Space Availability - Web Server',           'SERVER',   'Web', 'ALL',   30),
(31, 'Disk Space Availability - ESM Server',           'SERVER',   'ESM', 'ALL',   31),
(32, 'Disk Space Availability - OAM Server',           'SERVER',   'OAM', 'ALL',   32),
(33, 'Task Schedulers (DB Server)',                    'SERVER',   'DB',  'ALL',   33),
(34, 'Task Schedulers (Web Server)',                   'SERVER',   'Web', 'ALL',   34),
(35, 'Task Schedulers (ESM Server)',                   'SERVER',   'ESM', 'ALL',   35),
(36, 'Task Schedulers (OAM Server)',                   'SERVER',   'OAM', 'ALL',   36);

-- ============================================================
-- ORACLE QUERIES
-- ============================================================
INSERT INTO `oracle_queries` (`query_key`,`query_sql`,`description`) VALUES
('tablespace_low',
 'SELECT * FROM DBA_TABLESPACE_USAGE_METRICS WHERE USED_PERCENT>=75',
 'Tablespaces at or above 75% usage (less than 25% free)'),
('tablespace_all',
 'SELECT TABLESPACE_NAME, USED_SPACE, TABLESPACE_SIZE, USED_PERCENT FROM DBA_TABLESPACE_USAGE_METRICS',
 'All tablespace utilisation metrics'),
('schema_expiry_base',
 "SELECT username, account_status, EXPIRY_DATE FROM DBA_USERS WHERE username IN ('SYS','SYSTEM','ARGUS_LOGIN_IPS','ARGUS_LOGIN_I','ARGUSDBA','ESM_OWNER','ARGUSUSER','item1','item2','ARGUS_APP','ARGUS_LOGIN','ESM_LOGIN')",
 'Argus schema password expiry - item1/item2 are replaced at runtime with WHODD/MEDDRA usernames'),
('schema_expiry_fmw',
 "SELECT USERNAME, account_status, EXPIRY_DATE FROM DBA_USERS WHERE username LIKE '%OAM%'",
 'FMW schema password expiry'),
('latest_usernames',
 "SELECT username FROM dba_users WHERE username LIKE 'MEDDRA%' OR username LIKE 'WHODD%' ORDER BY created DESC",
 'Find latest WHODD and MEDDRA schema usernames for dynamic substitution'),
('archive_logmode',
 'SELECT LOG_MODE FROM V$DATABASE',
 'Check if database is in ARCHIVELOG mode'),
('archive_path',
 "SELECT DESTINATION FROM V$ARCHIVE_DEST WHERE STATUS = 'VALID'",
 'Archive log destinations - alert if on C: drive'),
('archive_last8days',
 'SELECT FIRST_TIME, SEQUENCE#, THREAD#, STATUS, DELETED, BACKUP_COUNT FROM V$ARCHIVED_LOG WHERE FIRST_TIME >= sysdate - 8 ORDER BY 3,1',
 'Archive logs from last 8 days - check DELETED status'),
('rman_recent',
 "SELECT a.Start_time, a.end_time, a.output_device_type, (CASE WHEN a.INPUT_TYPE='DB INCR' AND (b.incremental_level=0 OR (b.backup_type='L' AND b.incremental_level IS NULL)) THEN 'DB Full' ELSE a.INPUT_TYPE END) AS backuptype, CAST(a.ELAPSED_SECONDS AS DECIMAL(10,2)) AS Timetaken, a.status FROM V$RMAN_BACKUP_JOB_DETAILS a LEFT JOIN V$BACKUP_SET b ON a.session_recid = b.recid WHERE TO_DATE(a.start_time,'DD-MON-YY') = (SELECT TO_DATE(sysdate,'DD-MON-YY') FROM dual) AND TO_DATE(a.end_time,'DD-MON-YY') = (SELECT TO_DATE(sysdate,'DD-MON-YY') FROM dual) UNION ALL SELECT START_TIME, END_TIME, output_device_type, operation, 0, status FROM v$rman_status WHERE TO_DATE(start_time,'DD-MON-YY') = (SELECT TO_DATE(sysdate,'DD-MON-YY') FROM dual) AND TO_DATE(end_time,'DD-MON-YY') = (SELECT TO_DATE(sysdate,'DD-MON-YY') FROM dual) AND operation IN ('DELETE') ORDER BY Start_time",
 'RMAN backup jobs for today including DELETE operations');

-- ============================================================
-- MAIL CONFIG (SMTP settings from existing hcdata.sql)
-- To change SMTP: UPDATE mail_config SET smtp_host='...' WHERE config_name='default';
-- ============================================================
INSERT INTO `mail_config` (`config_name`,`smtp_host`,`smtp_port`,`use_tls`,`smtp_user`,`smtp_password`,`from_address`,`is_active`,`notes`) VALUES
('default',
 'email-smtp.us-east-1.amazonaws.com',
 2587, 1,
 'AKIAVCYLC7ABOWX6PLE3',
 'BBrefAqS4WsmKGVacbz7WEaYmgOd9gGnHBw2LKzjwXQk',
 'NavitasBOT@navitascloud.com',
 1,
 'AWS SES SMTP - us-east-1. Migrated from system_config.');

-- ============================================================
-- MAIL RECIPIENTS (global defaults - customer_id NULL)
-- To add customer-specific: INSERT with customer_id = N
-- All 4 alert types must have a global row (customer_id NULL).
-- ============================================================
INSERT INTO `mail_recipients` (`alert_type`,`customer_id`,`to_addresses`,`cc_addresses`,`is_active`,`notes`) VALUES
('SUCCESS',      NULL, 'udhayaprakash.g@navitaslifesciences.com,saravanan.v@navitaslifesciences.com', 'udhayaprakash.g@navitaslifesciences.com', 1, 'Global success TO/CC - change as needed'),
('FAILURE',      NULL, 'udhayaprakash.g@navitaslifesciences.com',                                     'udhayaprakash.g@navitaslifesciences.com', 1, 'Global failure TO/CC'),
('ESCALATION',   NULL, 'udhayaprakash.g@navitaslifesciences.com',                                     'udhayaprakash.g@navitaslifesciences.com', 1, 'Global escalation TO/CC'),
('RERUN_FAILURE',NULL, 'udhayaprakash.g@navitaslifesciences.com',                                     'udhayaprakash.g@navitaslifesciences.com', 1, 'Global rerun-exhausted TO/CC');

-- ============================================================
-- MAIL TEMPLATES (HTML email bodies)
-- Edit body_html here to customise email layout.
-- Placeholders: {customer}, {env}, {run_id}, {date_time},
--               {report_title}, {attachment}, {error},
--               {ordinal}, {issue_table}, {max_attempts}
-- ============================================================
INSERT INTO `mail_templates` (`template_key`,`subject_template`,`body_html`,`notes`) VALUES

('success',
 'Health Check Report - {customer} - {env}',
 '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;font-size:14px;color:#333;margin:0;padding:20px">
<div style="max-width:680px;margin:auto">
  <div style="background:#1565C0;color:#fff;padding:16px 20px;border-radius:6px 6px 0 0">
    <h2 style="margin:0;font-size:18px">&#x2705; Health Check Report</h2>
  </div>
  <div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
      <tr><td style="padding:6px 8px;font-weight:bold;width:130px;color:#555">Customer</td>
          <td style="padding:6px 8px">{customer}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Environment</td>
          <td style="padding:6px 8px">{env}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Run ID</td>
          <td style="padding:6px 8px">#{run_id}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Generated</td>
          <td style="padding:6px 8px">{date_time}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Attachment</td>
          <td style="padding:6px 8px">{attachment}</td></tr>
    </table>
    <p style="margin:12px 0">Hi Team,</p>
    <p style="margin:12px 0">Please find the attached <strong>{report_title}</strong> for your review and necessary action.</p>
    <p style="margin:12px 0">If the <em>Action Required</em> column shows <strong style="color:#C62828">Yes</strong>, action is needed. If it shows <strong style="color:#2E7D32">No</strong>, no action required.</p>
    <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
    <p style="color:#888;font-size:12px;margin:0">This is an automated email from Health Check Automation. Please do not reply.</p>
  </div>
</div>
</body></html>',
 'Success email with Excel attachment'),

('failure',
 'Job Failure Notification - Health Check - {customer} - {env}',
 '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;font-size:14px;color:#333;margin:0;padding:20px">
<div style="max-width:680px;margin:auto">
  <div style="background:#C62828;color:#fff;padding:16px 20px;border-radius:6px 6px 0 0">
    <h2 style="margin:0;font-size:18px">&#x26A0; Health Check Failure</h2>
  </div>
  <div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
      <tr><td style="padding:6px 8px;font-weight:bold;width:130px;color:#555">Customer</td>
          <td style="padding:6px 8px">{customer}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Environment</td>
          <td style="padding:6px 8px">{env}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Run ID</td>
          <td style="padding:6px 8px">#{run_id}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Time</td>
          <td style="padding:6px 8px">{date_time}</td></tr>
    </table>
    <p>This is an automated failure notification:</p>
    <div style="background:#FFEBEE;border-left:4px solid #C62828;padding:12px;margin:12px 0;border-radius:0 4px 4px 0;font-family:monospace;font-size:13px">{error}</div>
    <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
    <p style="color:#888;font-size:12px;margin:0">For concerns, reach out to the Navitas RPA team. Do not reply to this email.</p>
  </div>
</div>
</body></html>',
 'Failure notification email'),

('escalation',
 'ACTION REQUIRED - {ordinal}: Health Check - {customer} - {env}',
 '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;font-size:14px;color:#333;margin:0;padding:20px">
<div style="max-width:680px;margin:auto">
  <div style="background:#E65100;color:#fff;padding:16px 20px;border-radius:6px 6px 0 0">
    <h2 style="margin:0;font-size:18px">&#x1F6A8; ACTION REQUIRED &mdash; {ordinal}</h2>
  </div>
  <div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
      <tr><td style="padding:6px 8px;font-weight:bold;width:130px;color:#555">Customer</td>
          <td style="padding:6px 8px">{customer}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Environment</td>
          <td style="padding:6px 8px">{env}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Generated</td>
          <td style="padding:6px 8px">{date_time}</td></tr>
    </table>
    <p>The following health checks have been <strong>continuously failing</strong> and require immediate attention:</p>
    <table style="border-collapse:collapse;width:100%;margin:12px 0">
      <tr style="background:#FFE0B2">
        <th style="padding:8px;border:1px solid #ccc;text-align:left">Test Name</th>
        <th style="padding:8px;border:1px solid #ccc;text-align:center">Consecutive Failures</th>
        <th style="padding:8px;border:1px solid #ccc;text-align:center">Total Failures</th>
        <th style="padding:8px;border:1px solid #ccc;text-align:left">Last Error</th>
      </tr>
      {issue_table}
    </table>
    <p>Please investigate and take corrective action immediately.</p>
    <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
    <p style="color:#888;font-size:12px;margin:0">Escalation emails will continue until the issue is resolved. Generated by Health Check Automation.</p>
  </div>
</div>
</body></html>',
 'Escalation email - {ordinal} becomes First/Second/Third etc.'),

('rerun_failure',
 'RERUN EXHAUSTED - Health Check - {customer} ({env})',
 '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;font-size:14px;color:#333;margin:0;padding:20px">
<div style="max-width:680px;margin:auto">
  <div style="background:#6A1B9A;color:#fff;padding:16px 20px;border-radius:6px 6px 0 0">
    <h2 style="margin:0;font-size:18px">&#x1F504; All Rerun Attempts Exhausted</h2>
  </div>
  <div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 6px 6px">
    <p>All automatic rerun attempts have been exhausted. <strong>Manual intervention required.</strong></p>
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
      <tr><td style="padding:6px 8px;font-weight:bold;width:130px;color:#555">Customer</td>
          <td style="padding:6px 8px">{customer}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Environment</td>
          <td style="padding:6px 8px">{env}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Original Run ID</td>
          <td style="padding:6px 8px">#{run_id}</td></tr>
      <tr style="background:#f9f9f9">
          <td style="padding:6px 8px;font-weight:bold;color:#555">Attempts Made</td>
          <td style="padding:6px 8px;color:#C62828;font-weight:bold">{max_attempts}</td></tr>
      <tr><td style="padding:6px 8px;font-weight:bold;color:#555">Time</td>
          <td style="padding:6px 8px">{date_time}</td></tr>
    </table>
    <p>Please investigate and re-run manually: <code>python main.py rerun --run-id {run_id}</code></p>
    <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
    <p style="color:#888;font-size:12px;margin:0">For concerns, reach out to the Navitas RPA team.</p>
  </div>
</div>
</body></html>',
 'Email sent when all rerun attempts are exhausted');

-- ============================================================
-- SYSTEM CONFIG (operational settings only - no email/SMTP here)
-- ============================================================
INSERT INTO `system_config` (`config_key`,`config_value`,`config_group`,`description`) VALUES
-- paths
('excel_output_path',      'C:\\cloudFTP\\Health-Check-OUT\\Excel', 'paths', 'Folder where Excel reports are saved'),
('log_output_path',        'C:\\cloudFTP\\Health-Check-OUT\\Log',   'paths', 'Folder where run log files are saved'),
('oracle_dll_path',        'C:\\RPA_Packages\\oracledb_dll\\instantclient_23_6', 'paths', 'Oracle Instant Client path on Windows'),
-- operational
('conn_retry_attempts',    '3',   'operational', 'WMI and Oracle connection retry count'),
('conn_retry_delay_sec',   '10',  'operational', 'Seconds to wait between retries'),
('disk_free_threshold_gb', '10',  'operational', 'Alert if any drive has less than this GB free'),
('tablespace_free_pct',    '25',  'operational', 'Alert if tablespace used% exceeds 100-this value'),
('rerun_interval_hours',   '24',  'operational', 'Hours between automatic rerun attempts'),
('rerun_max_attempts',     '3',   'operational', 'Maximum automatic rerun attempts per failed run'),
('log_retention_days',     '90',  'operational', 'Delete execution_logs rows older than this many days'),
-- display
('excel_title_prefix',     'Health Check Report', 'display', 'Prefix for Excel file and email title');

-- ============================================================
-- CUSTOMERS (MMS from hcdata.sql)
-- ============================================================
INSERT INTO `customers` (`id`,`name`,`code`,`tenant_type`,`is_active`,`notes`) VALUES
(1, 'MMS', 'MMS', 'Single', 1, 'Test customer from hcdata.sql');

-- ============================================================
-- ENVIRONMENTS (DEV from hcdata.sql)
-- server_pwd is AES-256-CBC encrypted. Re-encrypt using:
--   python main.py encrypt-password
-- ============================================================
INSERT INTO `environments` (`id`,`customer_id`,`env_type`,`server_user`,`server_pwd`,`is_active`,`notes`) VALUES
(1, 1, 'DEV', 'NAVITASCLOUD\\HC_AUTOMMSD', 'N9VqdfI5Ari5Fk6d4nsiUVMF5dPmMfNOM03R68qd4H0=', 1, 'DEV environment from hcdata.sql');

-- ============================================================
-- SERVERS (Database server from hcdata.sql)
-- ============================================================
INSERT INTO `servers` (`id`,`env_id`,`server_role`,`server_name`,`host`,`is_active`,`notes`) VALUES
(1, 1, 'DB', 'Database', '10.105.0.61', 1, 'DB server from hcdata.sql');

-- ============================================================
-- ORACLE DATABASES (MMSDDB from execution logs)
-- db_pwd is AES-256-CBC encrypted. Re-encrypt using:
--   python main.py encrypt-password
-- NOTE: Replace this placeholder with the actual encrypted password.
-- ============================================================
INSERT INTO `oracle_databases` (`id`,`server_id`,`db_name`,`db_type`,`db_user`,`db_pwd`,`port`,`is_active`,`notes`) VALUES
(1, 1, 'MMSDDB', 'Argus', 'Argus_app', 'PLACEHOLDER_ENCRYPT_ME', 1521, 1, 'Argus DB from hcdata.sql - re-encrypt password');

-- ============================================================
-- ESCALATION CONFIG (MMS DEV - default thresholds)
-- ============================================================
INSERT INTO `escalation_config` (`customer_id`,`env_type`,`threshold`,`interval_hours`,`max_escalations`,`is_paused`,`notify_rerun_fail`) VALUES
(1, 'DEV', 3, 168, 0, 0, 1);

-- ============================================================
-- SCHEDULES (MMS DEV - weekly on Sunday at 01:00 AM)
-- is_active=0 so it won't fire accidentally. Set to 1 when ready.
-- ============================================================
INSERT INTO `schedules` (`customer_id`,`env_types`,`schedule_name`,`cron_expression`,`is_active`,`notes`) VALUES
(1, 'DEV', 'MMS DEV Weekly', '0 1 * * 0', 0, 'Every Sunday at 1AM. Set is_active=1 to enable.');

-- ============================================================
-- AUTO-INCREMENT alignment
-- ============================================================
ALTER TABLE `customers`          AUTO_INCREMENT = 10;
ALTER TABLE `environments`       AUTO_INCREMENT = 10;
ALTER TABLE `servers`            AUTO_INCREMENT = 10;
ALTER TABLE `oracle_databases`   AUTO_INCREMENT = 10;
ALTER TABLE `execution_runs`     AUTO_INCREMENT = 1;
ALTER TABLE `env_run_status`     AUTO_INCREMENT = 1;
ALTER TABLE `server_check_results` AUTO_INCREMENT = 1;
ALTER TABLE `db_check_results`   AUTO_INCREMENT = 1;
ALTER TABLE `tablespace_usage`   AUTO_INCREMENT = 1;

-- ============================================================
-- VERIFY
-- ============================================================
SELECT 'Schema created successfully.' AS status;
SELECT TABLE_NAME, TABLE_ROWS
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'hc_v5'
ORDER BY TABLE_NAME;

"""
core/executor.py  (v5)
=======================
Main health check executor.

Flow:
  execution_run → customers → environments → servers → Oracle DBs

Logs use clean messages (no [file|func()] prefix in message text).
File/function/line are captured automatically by RunLogger.

Test skipping:
  Before running any test, executor checks test_override table.
  If a test is disabled for this customer/env, it is skipped silently
  and will not appear in server_check_results / db_check_results.
"""
import traceback
from typing import Dict, List, Optional

from core.config import ConfigLoader, AppConfig
from core.db_manager import DBManager
from core.logger import RunLogger
from checks.server_manager import ServerManager
from checks.oracle_manager import OracleManager


class HealthCheckExecutor:
    """
    Executes all health checks for one execution_run record.

    Usage:
        executor = HealthCheckExecutor(db, run_id, logger)
        final_status = executor.run()
        # returns 'COMPLETED' | 'PARTIAL' | 'FAILED'
    """

    def __init__(self, db: DBManager, run_id: int, logger: RunLogger):
        self.db      = db
        self.run_id  = run_id
        self.logger  = logger
        self.cfg: AppConfig = ConfigLoader.get()

    # ================================================================== #
    # TOP LEVEL
    # ================================================================== #

    def run(self) -> str:
        """Execute all health checks. Returns 'COMPLETED', 'PARTIAL', or 'FAILED'."""
        self.logger.info(f"Executor starting for run_id={self.run_id}")

        run = self.db.fetch_one("SELECT * FROM execution_runs WHERE id=%s", (self.run_id,))
        if not run:
            raise ValueError(f"execution_run id={self.run_id} not found in DB")

        self.db.execute(
            "UPDATE execution_runs SET status='IN_PROGRESS', started_at=NOW() WHERE id=%s",
            (self.run_id,))

        customer = self.db.fetch_one("SELECT * FROM customers WHERE id=%s", (run["customer_id"],))
        if not customer:
            raise ValueError(f"Customer id={run['customer_id']} not found in DB")

        self.logger.set_context(customer_id=customer["id"])
        self.logger.section(
            f"Run #{self.run_id} | Customer: {customer['name']} ({customer['code']}) | Envs: {run['env_types']}")

        env_types   = [e.strip() for e in run["env_types"].split(",")]
        any_success = False
        any_failure = False

        for env_type in env_types:
            self.logger.info(f"Processing environment: {env_type}")
            success = self._run_environment(customer, env_type)
            if success:
                any_success = True
            else:
                any_failure = True

        if any_failure and not any_success:
            final_status = "FAILED"
        elif any_failure:
            final_status = "PARTIAL"
        else:
            final_status = "COMPLETED"

        self.db.execute(
            "UPDATE execution_runs SET status=%s, completed_at=NOW() WHERE id=%s",
            (final_status, self.run_id))
        self.logger.info(f"Run #{self.run_id} finished with status: {final_status}")
        return final_status

    # ================================================================== #
    # ENVIRONMENT
    # ================================================================== #

    def _run_environment(self, customer: Dict, env_type: str) -> bool:
        self.logger.set_context(env_type=env_type)
        self.logger.info(f"Customer={customer['name']} | Env={env_type}")

        env = self.db.fetch_one(
            "SELECT e.* FROM environments e WHERE e.customer_id=%s AND e.env_type=%s AND e.is_active=1",
            (customer["id"], env_type))
        if not env:
            self.logger.warning(
                f"No active environment record for customer='{customer['name']}' env_type='{env_type}'. Skipping.")
            return False

        env_status_id = self.db.insert_get_id(
            "INSERT INTO env_run_status (run_id,customer_id,env_type,tenant,status,started_at) VALUES(%s,%s,%s,%s,'IN_PROGRESS',NOW())",
            (self.run_id, customer["id"], env_type, customer["tenant_type"]))
        self.logger.debug(f"Created env_run_status id={env_status_id} for {env_type}")

        try:
            servers = self.db.fetch_all(
                "SELECT * FROM servers WHERE env_id=%s AND is_active=1 ORDER BY server_role",
                (env["id"],))
            self.logger.info(f"Found {len(servers)} active server(s) in {env_type}")
            if not servers:
                self.logger.warning(f"No active servers configured for env {env_type}")

            for server in servers:
                self.logger.reset_server_context()
                self._run_server(env, server, env_status_id, customer["id"], env_type)

            self.db.execute(
                "UPDATE env_run_status SET status='COMPLETED', completed_at=NOW() WHERE id=%s",
                (env_status_id,))
            self.logger.info(f"Environment {env_type} completed successfully")
            return True

        except Exception as exc:
            tb = traceback.format_exc()
            self.logger.error(f"Environment {env_type} FAILED: {exc}\n{tb}")
            self.db.execute(
                "UPDATE env_run_status SET status='FAILED', error_message=%s, completed_at=NOW() WHERE id=%s",
                (f"{exc}\n{tb}"[:2000], env_status_id))
            return False

    # ================================================================== #
    # SERVER
    # ================================================================== #

    def _run_server(self, env: Dict, server: Dict, env_status_id: int,
                    customer_id: int, env_type: str):
        server_id = server["id"]
        self.logger.set_context(server_id=server_id)
        self.logger.info(
            f"Server: id={server_id} name='{server['server_name']}' "
            f"host={server['host']} role={server['server_role']}")

        sm = ServerManager(
            host=server["host"],
            username=env["server_user"],
            encrypted_password=env["server_pwd"],
            logger=self.logger)

        connected  = sm.connect()
        conn_status = "Connection Established" if connected else "Not able to Connect Server"
        conn_ok     = 1 if connected else 0

        scr_id = self.db.insert_get_id(
            "INSERT INTO server_check_results (env_status_id,server_id,connection_status,connection_ok) VALUES(%s,%s,%s,%s)",
            (env_status_id, server_id, conn_status, conn_ok))
        self.logger.debug(f"Created server_check_results id={scr_id} | connection={'OK' if connected else 'FAILED'}")

        if not connected:
            self.logger.error(
                f"Cannot connect to server '{server['server_name']}' ({server['host']}). "
                f"All server checks skipped.")
            sm.disconnect()
            return

        self._run_server_checks(sm, scr_id, server, customer_id, env_type)

        if server["server_role"] == "DB":
            databases = self.db.fetch_all(
                "SELECT * FROM oracle_databases WHERE server_id=%s AND is_active=1",
                (server_id,))
            self.logger.info(
                f"Found {len(databases)} Oracle database(s) on server '{server['server_name']}'")
            for odb in databases:
                self.logger.reset_db_context()
                self._run_database(env, server, odb, env_status_id, customer_id, env_type)
        else:
            self.logger.debug(
                f"Server role='{server['server_role']}' — no Oracle DB checks needed")

        sm.disconnect()

    # ================================================================== #
    # SERVER WMI CHECKS
    # ================================================================== #

    def _is_test_enabled(self, test_id: int, customer_id: int, env_type: str) -> bool:
        """
        Check if a test should run for this customer/env.
        Returns True if enabled (default), False if disabled via test_override.
        Global is_active=0 in test_catalog also disables.
        """
        # Check global test_catalog.is_active
        global_row = self.db.fetch_one(
            "SELECT is_active FROM test_catalog WHERE id=%s", (test_id,))
        if global_row and not global_row["is_active"]:
            return False

        # Check customer-specific override
        override = self.db.fetch_one(
            """SELECT is_active FROM test_override
               WHERE customer_id=%s AND test_catalog_id=%s
               AND (env_type=%s OR env_type IS NULL)
               ORDER BY env_type DESC LIMIT 1""",
            (customer_id, test_id, env_type))
        if override is not None:
            return bool(override["is_active"])

        return True  # default: enabled

    def _run_server_checks(self, sm: ServerManager, scr_id: int, server: Dict,
                           customer_id: int, env_type: str):
        """Run WMI checks on a connected server and update server_check_results."""
        updates: Dict = {}
        sname = server["server_name"]
        role  = server["server_role"]

        # Map role to test IDs
        role_wu   = {"DB": 25, "Web": 26, "ESM": 27, "OAM": 28}
        role_disk = {"DB": 29, "Web": 30, "ESM": 31, "OAM": 32}
        role_task = {"DB": 33, "Web": 34, "ESM": 35, "OAM": 36}

        # ---- Windows Update ----
        wu_id = role_wu.get(role, 25)
        if self._is_test_enabled(wu_id, customer_id, env_type):
            self.logger.info(f"Checking Windows Update service on '{sname}'")
            try:
                state, start_mode = sm.check_service("wuauserv")
                win_text   = f"Status: {state}, StartMode: {start_mode}"
                win_action = 1 if (state == "Running" or start_mode == "Auto") else 0
                updates["win_update_status"] = win_text
                updates["win_update_action"] = win_action
                self.logger.info(f"Windows Update: {win_text} | Action={win_action}")
            except Exception as exc:
                self.logger.error(f"Windows Update check failed on '{sname}': {exc}")
        else:
            self.logger.debug(f"Windows Update check (test {wu_id}) disabled for {sname}")

        # ---- Task Schedulers ----
        task_id = role_task.get(role, 33)
        if self._is_test_enabled(task_id, customer_id, env_type):
            task_names_raw = server.get("task_scheduler_names") or ""
            task_names = [t.strip() for t in task_names_raw.split(",") if t.strip()]
            if task_names:
                self.logger.info(f"Checking {len(task_names)} task(s) on '{sname}': {task_names}")
                try:
                    failed_tasks = []
                    for tname in task_names:
                        _, status = sm.check_task_scheduler(tname)
                        if status not in ("Ready", "Running"):
                            failed_tasks.append(f"{tname} [{status}]")
                            self.logger.warning(f"Task '{tname}' on '{sname}': {status} (action required)")
                        else:
                            self.logger.debug(f"Task '{tname}' on '{sname}': {status} (OK)")
                    if failed_tasks:
                        updates["task_scheduler_detail"] = "Not running: " + ", ".join(failed_tasks)
                        updates["task_scheduler_action"] = 1
                    else:
                        updates["task_scheduler_detail"] = "All schedulers running"
                        updates["task_scheduler_action"] = 0
                except Exception as exc:
                    self.logger.error(f"Task scheduler check failed on '{sname}': {exc}")
            else:
                self.logger.debug(f"No task scheduler names configured for '{sname}' — skipping")
        else:
            self.logger.debug(f"Task scheduler check (test {task_id}) disabled for {sname}")

        # ---- Service Listeners (DB only, test 12) ----
        if role == "DB" and self._is_test_enabled(12, customer_id, env_type):
            listeners_raw = server.get("service_listeners") or ""
            listeners = [l.strip() for l in listeners_raw.split(",") if l.strip()]
            if listeners:
                self.logger.info(f"Checking {len(listeners)} service listener(s) on '{sname}'")
                try:
                    failed_listeners = []
                    for svc in listeners:
                        state, _ = sm.check_service(svc)
                        if state != "Running":
                            failed_listeners.append(f"{svc} [{state}]")
                            self.logger.warning(f"Service '{svc}' on '{sname}': {state} (action required)")
                        else:
                            self.logger.debug(f"Service '{svc}' on '{sname}': Running (OK)")
                    if failed_listeners:
                        updates["listeners_detail"] = "Not running: " + ", ".join(failed_listeners)
                        updates["listeners_action"] = 1
                    else:
                        updates["listeners_detail"] = "All service listeners running"
                        updates["listeners_action"] = 0
                except Exception as exc:
                    self.logger.error(f"Service listener check failed on '{sname}': {exc}")

        # ---- Disk Space ----
        disk_id = role_disk.get(role, 29)
        if self._is_test_enabled(disk_id, customer_id, env_type):
            self.logger.info(f"Checking disk space on '{sname}'")
            try:
                disk_info = sm.get_disk_info()
                threshold = self.cfg.disk_free_threshold_gb
                low_disks: List[str] = []
                disk_parts: List[str] = []

                for drive, info in disk_info.items():
                    if "error" in info:
                        disk_parts.append(f"{drive}: {info['error']}")
                        continue
                    summary = (
                        f"{drive}: {info['free_gb']:.2f}GB free / "
                        f"{info['total_gb']:.2f}GB total ({info['free_pct']:.1f}% free)")
                    disk_parts.append(summary)
                    if info["free_gb"] < threshold:
                        low_disks.append(f"{drive} only {info['free_gb']:.2f}GB free")
                        self.logger.warning(f"{summary} — BELOW threshold ({threshold}GB)")
                    else:
                        self.logger.debug(f"{summary} — OK")

                updates["disk_space_detail"] = " | ".join(disk_parts)[:2000]
                updates["disk_space_action"] = 1 if low_disks else 0
                if low_disks:
                    self.logger.warning(f"Disk action required on '{sname}': {low_disks}")
            except Exception as exc:
                self.logger.error(f"Disk space check failed on '{sname}': {exc}")
        else:
            self.logger.debug(f"Disk space check (test {disk_id}) disabled for {sname}")

        if updates:
            set_clauses = ", ".join(f"{k}=%s" for k in updates)
            self.db.execute(
                f"UPDATE server_check_results SET {set_clauses} WHERE id=%s",
                tuple(updates.values()) + (scr_id,))
            self.logger.debug(f"Updated server_check_results id={scr_id} with {len(updates)} field(s)")

    # ================================================================== #
    # DATABASE
    # ================================================================== #

    def _run_database(self, env: Dict, server: Dict, odb: Dict, env_status_id: int,
                      customer_id: int, env_type: str):
        db_id = odb["id"]
        self.logger.set_context(db_id=db_id)
        self.logger.info(
            f"Oracle DB: id={db_id} name='{odb['db_name']}' type={odb['db_type']} port={odb['port']}")

        om = OracleManager(
            host=server["host"],
            port=odb["port"],
            service_name=odb["db_name"],
            username=odb["db_user"],
            encrypted_password=odb["db_pwd"],
            db_type=odb["db_type"],
            logger=self.logger)
        connected = om.connect()

        conn_status = "Connection Established" if connected else "Not able to Connect Database"
        dcr_id = self.db.insert_get_id(
            "INSERT INTO db_check_results (env_status_id,server_id,oracle_db_id,connection_status,connection_ok) VALUES(%s,%s,%s,%s,%s)",
            (env_status_id, server["id"], db_id, conn_status, 1 if connected else 0))
        self.logger.debug(f"Created db_check_results id={dcr_id} | connection={'OK' if connected else 'FAILED'}")

        if not connected:
            self.logger.error(f"Cannot connect to Oracle '{odb['db_name']}'. All DB checks skipped.")
            return

        try:
            self._run_db_checks(om, odb, env_status_id, dcr_id, customer_id, env_type)
        finally:
            om.disconnect()

    # ================================================================== #
    # ORACLE CHECKS
    # ================================================================== #

    def _run_db_checks(self, om: OracleManager, odb: Dict, env_status_id: int,
                       dcr_id: int, customer_id: int, env_type: str):
        """Run all Oracle health checks and update db_check_results."""
        updates: Dict = {}
        db_type = odb["db_type"]
        db_name = odb["db_name"]

        # Test ID mappings for enable/disable
        ts_test_id     = 19 if db_type == "Argus" else 20
        schema_test_id = 17 if db_type == "Argus" else 18

        # ---- Tablespace ----
        if self._is_test_enabled(ts_test_id, customer_id, env_type):
            self.logger.info(f"Running tablespace check on '{db_name}' ({db_type})")
            try:
                low_sql = self.db.get_oracle_query("tablespace_low")
                all_sql = self.db.get_oracle_query("tablespace_all")
                has_low, all_rows = om.check_tablespace(low_sql, all_sql)

                updates["tablespace_detail"] = (
                    "Table space below 25% (action needed)" if has_low else "Table space adequate")
                updates["tablespace_action"] = 1 if has_low else 0

                ts_data = []
                for r in all_rows:
                    try:
                        ts_data.append((dcr_id, str(r[0]),
                                        int(float(r[1])) if r[1] is not None else None,
                                        int(float(r[2])) if r[2] is not None else None,
                                        float(r[3])      if r[3] is not None else None))
                    except Exception as e:
                        self.logger.warning(f"Cannot parse tablespace row {r}: {e}")
                if ts_data:
                    self.db.execute_many(
                        "INSERT INTO tablespace_usage (db_check_id,tablespace_name,used_space_kb,total_space_kb,used_pct) VALUES(%s,%s,%s,%s,%s)",
                        ts_data)
                    self.logger.debug(f"Stored {len(ts_data)} tablespace rows for db_check_id={dcr_id}")
            except Exception as exc:
                self.logger.error(f"Tablespace check FAILED on '{db_name}': {exc}")
        else:
            self.logger.debug(f"Tablespace check (test {ts_test_id}) disabled for {db_name}")

        # ---- Schema Password ----
        if self._is_test_enabled(schema_test_id, customer_id, env_type):
            self.logger.info(f"Running schema password check on '{db_name}' ({db_type})")
            try:
                if db_type == "FMW":
                    sql = self.db.get_oracle_query("schema_expiry_fmw")
                    has_expiry, detail = om.check_schema_password(sql)
                else:
                    latest_sql = self.db.get_oracle_query("latest_usernames")
                    item1, item2 = om.get_latest_usernames(latest_sql)
                    base_sql = self.db.get_oracle_query("schema_expiry_base")
                    sql = base_sql
                    if item1:
                        sql = sql.replace("item1", item1)
                        self.logger.debug(f"Substituted item1 → '{item1}'")
                    else:
                        sql = sql.replace(",'item1'", "").replace("'item1',", "")
                        self.logger.warning(f"No WHODD username found in '{db_name}'")
                    if item2:
                        sql = sql.replace("item2", item2)
                        self.logger.debug(f"Substituted item2 → '{item2}'")
                    else:
                        sql = sql.replace(",'item2'", "").replace("'item2',", "")
                        self.logger.warning(f"No MEDDRA username found in '{db_name}'")
                    has_expiry, detail = om.check_schema_password(sql)

                updates["schema_password_detail"] = detail[:2000] if detail else "No expiry found"
                updates["schema_password_action"] = 1 if has_expiry else 0
                self.logger.info(f"Schema password: has_expiry={has_expiry}")
            except Exception as exc:
                self.logger.error(f"Schema password check FAILED on '{db_name}': {exc}")
        else:
            self.logger.debug(f"Schema password check (test {schema_test_id}) disabled for {db_name}")

        # ---- Archive checks (Argus only) ----
        if db_type != "FMW":
            # Archive mode (test 21)
            if self._is_test_enabled(21, customer_id, env_type):
                self.logger.info(f"Running archive mode check on '{db_name}'")
                try:
                    mode_sql = self.db.get_oracle_query("archive_logmode")
                    in_archive, mode_str = om.check_archive_mode(mode_sql)
                    updates["archive_mode"]        = mode_str
                    updates["archive_mode_action"] = 0 if in_archive else 1
                except Exception as exc:
                    self.logger.error(f"Archive mode check FAILED on '{db_name}': {exc}")

            # Archive path (test 22)
            if self._is_test_enabled(22, customer_id, env_type):
                self.logger.info(f"Running archive path check on '{db_name}'")
                try:
                    path_sql = self.db.get_oracle_query("archive_path")
                    path_ok, path_detail = om.check_archive_path(path_sql)
                    updates["archive_path_detail"] = path_detail[:1000]
                    updates["archive_path_action"] = 0 if path_ok else 1
                except Exception as exc:
                    self.logger.error(f"Archive path check FAILED on '{db_name}': {exc}")

            # Archive logs last 8 days (test 23)
            if self._is_test_enabled(23, customer_id, env_type):
                self.logger.info(f"Running archive log (last 8 days) check on '{db_name}'")
                try:
                    logs_sql = self.db.get_oracle_query("archive_last8days")
                    logs_ok, logs_detail = om.check_archive_logs_8days(logs_sql)
                    updates["archive_log_detail"] = logs_detail[:1000]
                    updates["archive_log_action"] = 0 if logs_ok else 1
                except Exception as exc:
                    self.logger.error(f"Archive log check FAILED on '{db_name}': {exc}")

            # RMAN backup (test 24)
            if self._is_test_enabled(24, customer_id, env_type):
                self.logger.info(f"Running RMAN backup check on '{db_name}'")
                try:
                    rman_sql = self.db.get_oracle_query("rman_recent")
                    rman_ok, rman_rows = om.check_rman(rman_sql)

                    updates["rman_detail"] = (
                        "Backup Completed" if rman_ok
                        else "RMAN backup not completed or missing for today")
                    updates["rman_action"] = 0 if rman_ok else 1

                    rman_data = [(dcr_id,
                                  str(r[0]) if r[0] else None,
                                  str(r[1]) if r[1] else None,
                                  str(r[2]) if r[2] else None,
                                  str(r[3]) if r[3] else None,
                                  str(r[4]) if r[4] else None,
                                  str(r[5]) if r[5] else None)
                                 for r in rman_rows]
                    if rman_data:
                        self.db.execute_many(
                            "INSERT INTO rman_backup_details (db_check_id,start_time,end_time,output_device_type,backup_type,time_taken_display,status) VALUES(%s,%s,%s,%s,%s,%s,%s)",
                            rman_data)
                        self.logger.debug(f"Stored {len(rman_data)} RMAN rows for db_check_id={dcr_id}")
                except Exception as exc:
                    self.logger.error(f"RMAN check FAILED on '{db_name}': {exc}")
            else:
                self.logger.debug(f"RMAN check (test 24) disabled for {db_name}")

        if updates:
            set_clauses = ", ".join(f"{k}=%s" for k in updates)
            self.db.execute(
                f"UPDATE db_check_results SET {set_clauses} WHERE id=%s",
                tuple(updates.values()) + (dcr_id,))
            self.logger.debug(f"Updated db_check_results id={dcr_id} with {len(updates)} field(s)")

        self.logger.info(f"All checks complete for '{db_name}' ({db_type})")

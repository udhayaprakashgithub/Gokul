"""
core/issue_tracker.py  (v5)
============================
Tracks consecutive/total failures per test across runs.

Key behaviours:
 - Issues stay ESCALATED until the test PASSES in a subsequent run.
 - Each issue tracks last_escalated_at so escalation respects the
   per-customer interval (from escalation_config table).
 - Tests disabled in test_override for this customer/env are ignored.
"""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from core.db_manager import DBManager
from core.config import ConfigLoader

ROLE_INDEX   = {"DB": 0, "Web": 1, "ESM": 2, "OAM": 3}
CONN_IDS     = [8,  9,  10, 11]
WIN_UPD_IDS  = [25, 26, 27, 28]
DISK_IDS     = [29, 30, 31, 32]
TASK_IDS     = [33, 34, 35, 36]
LISTENERS_ID = 12

DB_TEST_IDS = {
    "connection_Argus": 15, "connection_FMW": 16,
    "schema_password_Argus": 17, "schema_password_FMW": 18,
    "tablespace_Argus": 19, "tablespace_FMW": 20,
    "archive_mode_Argus": 21, "archive_path_Argus": 22,
    "archive_log_Argus": 23, "rman_Argus": 24,
}


class IssueTrackerService:
    def __init__(self, db: DBManager):
        self.db  = db
        self.cfg = ConfigLoader.get()

    def process_run_results(self, run_id: int, customer_id: int, env_type: str, logger):
        logger.info(f"Issue tracking: run={run_id} customer_id={customer_id} env={env_type}")

        env_status = self.db.fetch_one(
            "SELECT * FROM env_run_status WHERE run_id=%s AND customer_id=%s AND env_type=%s",
            (run_id, customer_id, env_type))
        if not env_status:
            logger.warning(f"No env_run_status for run={run_id}/{env_type}")
            return

        failures = self._collect_failures(env_status["id"], logger)
        logger.info(f"Collected {len(failures)} failure(s) for {env_type}")

        # Get escalation threshold for this customer/env
        esc_cfg = self.db.fetch_one(
            "SELECT threshold FROM escalation_config WHERE customer_id=%s AND env_type=%s",
            (customer_id, env_type))
        threshold = esc_cfg["threshold"] if esc_cfg else 3

        open_issues = self.db.fetch_all(
            "SELECT * FROM issue_tracker WHERE customer_id=%s AND env_type=%s AND status IN ('OPEN','ESCALATED')",
            (customer_id, env_type))
        open_map = {(r["test_catalog_id"], r["server_id"], r["oracle_db_id"]): r for r in open_issues}

        for (tid, sid, did), detail in failures.items():
            key = (tid, sid, did)
            if key in open_map:
                issue = open_map[key]
                nc = issue["consecutive_failures"] + 1
                nt = issue["total_failures"] + 1
                ns = "ESCALATED" if nc >= threshold else issue["status"]
                self.db.execute(
                    """UPDATE issue_tracker
                       SET consecutive_failures=%s,total_failures=%s,
                           last_failed_run_id=%s,last_error_detail=%s,status=%s,updated_at=NOW()
                       WHERE id=%s""",
                    (nc, nt, run_id, str(detail)[:2000], ns, issue["id"]))
                logger.info(f"Updated issue id={issue['id']} test_id={tid}: consecutive={nc} status={ns}")
            else:
                nid = self.db.insert_get_id(
                    """INSERT INTO issue_tracker
                       (customer_id,env_type,server_id,oracle_db_id,test_catalog_id,
                        first_failed_run_id,last_failed_run_id,consecutive_failures,
                        total_failures,last_error_detail,status)
                       VALUES(%s,%s,%s,%s,%s,%s,%s,1,1,%s,'OPEN')""",
                    (customer_id, env_type, sid, did, tid, run_id, run_id, str(detail)[:2000]))
                logger.info(f"Opened new issue id={nid}: test_id={tid}")

        # Resolve tests that passed this run
        for key, issue in open_map.items():
            if key not in failures:
                self.db.execute(
                    "UPDATE issue_tracker SET status='RESOLVED',resolved_run_id=%s,consecutive_failures=0,updated_at=NOW() WHERE id=%s",
                    (run_id, issue["id"]))
                logger.info(f"Resolved issue id={issue['id']} test_id={issue['test_catalog_id']}")

    def get_escalated_issues(self, customer_id: int, env_type: str) -> List[Dict]:
        """Return ESCALATED issues with test names."""
        return self.db.fetch_all(
            """SELECT it.*, tc.test_name
               FROM issue_tracker it
               JOIN test_catalog tc ON tc.id=it.test_catalog_id
               WHERE it.customer_id=%s AND it.env_type=%s AND it.status='ESCALATED'
               ORDER BY it.consecutive_failures DESC""",
            (customer_id, env_type))

    def should_send_escalation(self, issue: Dict, interval_hours: int) -> bool:
        """Check if enough time has passed since last escalation for this issue."""
        last = issue.get("last_escalated_at")
        if last is None:
            return True
        return datetime.now() >= last + timedelta(hours=interval_hours)

    def mark_escalated(self, issue_id: int):
        """Record that an escalation email was just sent for this issue."""
        self.db.execute(
            "UPDATE issue_tracker SET last_escalated_at=NOW(), escalation_send_count=escalation_send_count+1 WHERE id=%s",
            (issue_id,))

    def _collect_failures(self, env_status_id: int, logger) -> Dict[Tuple, str]:
        failures: Dict[Tuple, str] = {}

        for row in self.db.fetch_all("SELECT * FROM server_check_results WHERE env_status_id=%s", (env_status_id,)):
            srv  = self.db.fetch_one("SELECT server_role FROM servers WHERE id=%s", (row["server_id"],))
            role = srv["server_role"] if srv else "DB"
            ri   = ROLE_INDEX.get(role, 0)
            sid  = row["server_id"]
            if not row["connection_ok"]:
                failures[(CONN_IDS[ri],    sid, None)] = row["connection_status"]
            if row.get("win_update_action"):
                failures[(WIN_UPD_IDS[ri], sid, None)] = row.get("win_update_status", "")
            if row.get("task_scheduler_action"):
                failures[(TASK_IDS[ri],    sid, None)] = row.get("task_scheduler_detail", "")
            if row.get("listeners_action") and role == "DB":
                failures[(LISTENERS_ID,    sid, None)] = row.get("listeners_detail", "")
            if row.get("disk_space_action"):
                failures[(DISK_IDS[ri],    sid, None)] = row.get("disk_space_detail", "")

        for row in self.db.fetch_all("SELECT * FROM db_check_results WHERE env_status_id=%s", (env_status_id,)):
            odb = self.db.fetch_one("SELECT db_type FROM oracle_databases WHERE id=%s", (row["oracle_db_id"],))
            dt  = odb["db_type"] if odb else "Argus"
            sid = row["server_id"]
            did = row["oracle_db_id"]
            if not row["connection_ok"]:
                failures[(DB_TEST_IDS[f"connection_{dt}"],      sid, did)] = row["connection_status"]
            if row.get("schema_password_action"):
                failures[(DB_TEST_IDS[f"schema_password_{dt}"], sid, did)] = row.get("schema_password_detail","")
            if row.get("tablespace_action"):
                failures[(DB_TEST_IDS[f"tablespace_{dt}"],      sid, did)] = row.get("tablespace_detail","")
            if dt == "Argus":
                if row.get("archive_mode_action"):
                    failures[(DB_TEST_IDS["archive_mode_Argus"],  sid, did)] = row.get("archive_mode","")
                if row.get("archive_path_action"):
                    failures[(DB_TEST_IDS["archive_path_Argus"],  sid, did)] = row.get("archive_path_detail","")
                if row.get("archive_log_action"):
                    failures[(DB_TEST_IDS["archive_log_Argus"],   sid, did)] = row.get("archive_log_detail","")
                if row.get("rman_action"):
                    failures[(DB_TEST_IDS["rman_Argus"],          sid, did)] = row.get("rman_detail","")
        return failures

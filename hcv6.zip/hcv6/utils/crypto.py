"""
utils/crypto.py
===============
AES-256-CBC password encryption / decryption.

The encryption key is read from the HC_ENC_KEY environment variable.
It must be exactly 32 bytes (256 bits).

Usage:
    from utils.crypto import encrypt_password, decrypt_password

    # Encrypt before storing in DB:
    enc = encrypt_password("MyPlainPassword")

    # Decrypt after reading from DB:
    plain = decrypt_password(enc)
"""
import base64
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend


# ------------------------------------------------------------------ #
# Key management
# ------------------------------------------------------------------ #

def _get_key() -> bytes:
    """
    Load the 32-byte AES key from the environment.
    Falls back to the original hardcoded key from the legacy code.
    """
    raw = os.getenv("HC_ENC_KEY", "3cb950cf5dd21c4d4e3618ddf3f317b2")
    key = raw.encode("utf-8") if isinstance(raw, str) else raw
    if len(key) != 32:
        raise ValueError(
            f"HC_ENC_KEY must be exactly 32 bytes. Got {len(key)} bytes. "
            f"Set HC_ENC_KEY=<32-character-string> in your environment."
        )
    return key


# ------------------------------------------------------------------ #
# Core encrypt / decrypt
# ------------------------------------------------------------------ #

def encrypt_password(plaintext: str) -> str:
    """
    Encrypt a plain-text password with AES-256-CBC.
    Returns a base64-encoded string (IV prepended to ciphertext).
    This is the value to store in the database.
    """
    key = _get_key()
    iv = os.urandom(16)  # Random 16-byte IV every call
    # PKCS7 padding to 16-byte boundary
    raw = plaintext.encode("utf-8")
    pad_len = 16 - (len(raw) % 16)
    padded = raw + bytes([pad_len] * pad_len)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    ct = cipher.encryptor().update(padded) + cipher.encryptor().finalize()
    # Prepend IV so decrypt can recover it
    return base64.b64encode(iv + ct).decode("utf-8")


def decrypt_password(ciphertext: str) -> str:
    """
    Decrypt a base64-encoded AES-256-CBC ciphertext (IV-prepended).
    Returns the original plain-text password.
    """
    key = _get_key()
    raw = base64.b64decode(ciphertext)
    iv = raw[:16]
    ct = raw[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    dec = cipher.decryptor()
    padded = dec.update(ct) + dec.finalize()
    pad_len = padded[-1]
    return padded[:-pad_len].decode("utf-8")


def is_encrypted(value: str) -> bool:
    """
    Heuristic: if the value decodes cleanly as base64 and is ≥32 bytes, assume encrypted.
    Used so the application can gracefully handle both plain and encrypted values.
    """
    try:
        decoded = base64.b64decode(value)
        return len(decoded) >= 32
    except Exception:
        return False

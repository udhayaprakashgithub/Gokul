"""
utils/password_helper.py
========================
Interactive CLI to encrypt passwords before inserting them into the database.

Usage:
    python utils/password_helper.py

    Enter the plain password when prompted.
    Copy the output encrypted string into your INSERT / UPDATE statement.

Example:
    python utils/password_helper.py
    > Enter plain password: MyServerPass123
    > Encrypted (store this in DB): b64string...

    -- Then use in SQL:
    UPDATE environments SET server_pwd='<encrypted>' WHERE id=1;
    UPDATE oracle_databases SET db_pwd='<encrypted>' WHERE id=1;
"""
import sys
import getpass

# Allow running from project root
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.crypto import encrypt_password, decrypt_password


def main():
    print("=" * 60)
    print("Health Check v3 - Password Encryption Helper")
    print("=" * 60)
    print()
    print("This tool encrypts passwords for storage in the database.")
    print("Set HC_ENC_KEY environment variable to your 32-char key,")
    print("or leave blank to use the default key.")
    print()

    while True:
        action = input("Action? [E]ncrypt / [D]ecrypt / [Q]uit: ").strip().upper()

        if action == "Q":
            print("Exiting.")
            break

        elif action == "E":
            plain = getpass.getpass("Enter plain-text password: ")
            if not plain:
                print("  ERROR: Password cannot be empty.\n")
                continue
            encrypted = encrypt_password(plain)
            print(f"\n  Encrypted value (copy this into DB):\n  {encrypted}\n")
            # Verify round-trip
            try:
                check = decrypt_password(encrypted)
                if check == plain:
                    print("  [OK] Round-trip verification passed.\n")
                else:
                    print("  [WARNING] Round-trip mismatch! Check your HC_ENC_KEY.\n")
            except Exception as e:
                print(f"  [ERROR] Round-trip failed: {e}\n")

        elif action == "D":
            enc = input("Enter encrypted value: ").strip()
            if not enc:
                print("  ERROR: Value cannot be empty.\n")
                continue
            try:
                plain = decrypt_password(enc)
                print(f"\n  Decrypted: {plain}\n")
            except Exception as e:
                print(f"  ERROR: Decryption failed: {e}\n")

        else:
            print("  Invalid option. Enter E, D, or Q.\n")


if __name__ == "__main__":
    main()

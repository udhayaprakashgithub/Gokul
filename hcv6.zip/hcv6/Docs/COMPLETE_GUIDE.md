# Health Check v5 — Complete Configuration, Testing & Workflow Guide

**Version:** 5.0  
**Date:** April 2026  
**System:** Automated Windows Server + Oracle DB Health Monitoring

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Database Setup (Fresh Start)](#2-database-setup)
3. [Environment Variables (DB Connection)](#3-environment-variables)
4. [Configure One Customer — Step by Step](#4-configure-one-customer)
5. [Configure Email (SMTP + TO/CC)](#5-configure-email)
6. [How to Test All Features](#6-testing-all-features)
7. [Disable / Enable Specific Tests](#7-test-management)
8. [Manage Escalation (Pause/Resume)](#8-escalation-management)
9. [Schedule Management](#9-schedule-management)
10. [Excel Report Explained](#10-excel-report)
11. [CLI Command Reference](#11-cli-commands)
12. [Database Tables Reference](#12-database-tables)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. System Overview

Health Check v5 automatically monitors Windows servers and Oracle databases for customers. Every run:

1. Connects to each Windows server via WMI
2. Checks disk space, Windows Update, task schedulers, service listeners
3. Connects to each Oracle database
4. Checks tablespace, schema passwords, archive logs, RMAN backups
5. Generates an Excel report (one file, one tab per environment)
6. Sends email with the Excel attached
7. Tracks consecutive failures — escalates when threshold reached
8. Automatically reruns on failure

### Console Output Difference

**Manual run** (clean numbered steps):
```
============================================================
  HC Run #8  |  MMS  |  DEV  |  MANUAL
============================================================
10:30:01 [INFO    ] [1/6] (16% done, 5 remaining) Executing health checks
10:30:45 [INFO    ] [2/6] (33% done, 4 remaining) Running issue tracker
10:30:46 [INFO    ] [3/6] (50% done, 3 remaining) Checking escalations
10:30:46 [INFO    ] [4/6] (66% done, 2 remaining) Generating Excel report
10:30:48 [INFO    ] [5/6] (83% done, 1 remaining) Sending email notifications
10:30:49 [INFO    ] [6/6] (100% done, 0 remaining) Queuing rerun if needed
============================================================
  DONE  |  Status: COMPLETED  |  Duration: 48s
============================================================
```

**Scheduler** (timestamped format):
```
[SCHEDULER] 2026-04-20 01:00:00 | Tick #42
[SCHEDULER] 2026-04-20 01:00:00 | MMS/DEV | Weekly Sunday 1AM | Firing
[SCHEDULER] 2026-04-20 01:00:01 | MMS/DEV | Run #8 started
[SCHEDULER] 2026-04-20 01:00:49 | MMS/DEV | Run #8 COMPLETED in 48s
[SCHEDULER] 2026-04-20 01:00:49 | MMS/DEV | Next run: 2026-04-27 01:00
```

---

## 2. Database Setup

### 2.1 Create fresh database (new install)

```bash
mysql -u admin -p < fresh_schema.sql
```

This creates database `hc_v5` with:
- All 23 tables
- MMS/DEV test customer and environment
- 36 test definitions
- SMTP config (from existing hcdata.sql values)
- Email recipients (navitaslifesciences.com addresses)
- Email HTML templates
- Escalation config for MMS/DEV
- One weekly schedule (disabled by default)

### 2.2 Re-encrypt the Oracle DB password

The oracle_databases row has a placeholder password. You **must** re-encrypt your actual password:

```bash
python main.py encrypt-password
```

Enter the plain password → copy the output → update the database:

```sql
UPDATE oracle_databases
SET db_pwd = 'paste-encrypted-value-here'
WHERE db_name = 'MMSDDB';
```

---

## 3. Environment Variables (DB Connection)

Set these before running anything:

```bash
# Linux / Mac
export HC_DB_HOST=nividous-dev.ci286ttk64x8.us-east-1.rds.amazonaws.com
export HC_DB_PORT=3306
export HC_DB_NAME=hc_v5
export HC_DB_USER=admin
export HC_DB_PASSWORD=Password321

# Windows CMD
set HC_DB_HOST=nividous-dev.ci286ttk64x8.us-east-1.rds.amazonaws.com
set HC_DB_NAME=hc_v5
set HC_DB_USER=admin
set HC_DB_PASSWORD=Password321
```

---

## 4. Configure One Customer — Step by Step

### Step 1: Add the customer

```sql
INSERT INTO customers (name, code, tenant_type, is_active)
VALUES ('My Customer', 'CUST1', 'Single', 1);
-- Note the id returned (e.g. id=2)
```

### Step 2: Add environment(s)

```sql
INSERT INTO environments (customer_id, env_type, server_user, server_pwd, is_active)
VALUES (2, 'PRD', 'DOMAIN\\hc_user', 'ENCRYPTED_PASSWORD_HERE', 1);
-- Get the env id (e.g. id=2)
```

To get the encrypted password:
```bash
python main.py encrypt-password
# Enter: YourPlainPassword
# Copy output to server_pwd above
```

### Step 3: Add server(s)

```sql
-- DB server
INSERT INTO servers (env_id, server_role, server_name, host, service_listeners, task_scheduler_names, is_active)
VALUES (2, 'DB', 'Database Server', '10.10.0.100', 'OracleServiceARGUS,OracleTNSListenerARGUS', 'Argus_Scheduler', 1);

-- Web server (optional)
INSERT INTO servers (env_id, server_role, server_name, host, is_active)
VALUES (2, 'Web', 'Web Server', '10.10.0.101', 1);
```

- `service_listeners`: comma-separated Windows services to check (Running/Stopped)
- `task_scheduler_names`: comma-separated Task Scheduler task names to check

### Step 4: Add Oracle database

```sql
INSERT INTO oracle_databases (server_id, db_name, db_type, db_user, db_pwd, port, is_active)
VALUES (
  (SELECT id FROM servers WHERE host='10.10.0.100' AND server_role='DB'),
  'MYDB', 'Argus', 'argus_app', 'ENCRYPTED_DB_PASSWORD', 1521, 1
);
```

### Step 5: Add escalation config

```sql
INSERT INTO escalation_config (customer_id, env_type, threshold, interval_hours, max_escalations, notify_rerun_fail)
VALUES (2, 'PRD', 3, 168, 0, 1);
-- threshold=3: escalate after 3 consecutive failures
-- interval_hours=168: send escalation at most once per week per issue
-- max_escalations=0: no limit (0=unlimited)
-- notify_rerun_fail=1: send email when all reruns exhausted
```

### Step 6: Add a schedule

```sql
INSERT INTO schedules (customer_id, env_types, schedule_name, cron_expression, is_active)
VALUES (2, 'PRD', 'CUST1 PRD Weekly', '0 1 * * 0', 1);
-- Cron: every Sunday at 01:00 AM
-- is_active=1: enabled immediately
```

Common cron expressions:
| Cron | Meaning |
|------|---------|
| `0 1 * * 0` | Every Sunday at 01:00 |
| `0 2 * * 1` | Every Monday at 02:00 |
| `0 6 * * *` | Every day at 06:00 |
| `0 0 1 * *` | First of every month at midnight |

### Step 7: Test the run

```bash
python main.py run --customer CUST1 --env PRD
```

### Step 8: Enable the schedule for production

```bash
python main.py list-schedules
# Find the schedule ID
python main.py enable-schedule --schedule-id 2
```

---

## 5. Configure Email (SMTP + TO/CC)

### 5.1 SMTP Settings (mail_config table)

```sql
-- View current SMTP config
SELECT config_name, smtp_host, smtp_port, use_tls, smtp_user, from_address, is_active
FROM mail_config;

-- Update SMTP host or password
UPDATE mail_config
SET smtp_host = 'your-smtp.example.com',
    smtp_user = 'newuser',
    smtp_password = 'newpassword'
WHERE config_name = 'default';

-- Add a backup SMTP (set is_active=0 to keep as standby)
INSERT INTO mail_config (config_name, smtp_host, smtp_port, use_tls, smtp_user, smtp_password, from_address, is_active)
VALUES ('backup', 'backup-smtp.example.com', 587, 1, 'user', 'pass', 'hc@example.com', 0);

-- Switch to backup
UPDATE mail_config SET is_active=0 WHERE config_name='default';
UPDATE mail_config SET is_active=1 WHERE config_name='backup';
```

### 5.2 Email Recipients (mail_recipients table)

**Global defaults** (customer_id IS NULL) — used for ALL customers:

```sql
-- View all recipients
SELECT alert_type, customer_id, to_addresses, cc_addresses
FROM mail_recipients ORDER BY alert_type;

-- Update SUCCESS global TO/CC (3 email IDs)
UPDATE mail_recipients
SET to_addresses = 'person1@company.com,person2@company.com,person3@company.com',
    cc_addresses = 'manager@company.com'
WHERE alert_type = 'SUCCESS' AND customer_id IS NULL;

-- Update FAILURE global TO/CC
UPDATE mail_recipients
SET to_addresses = 'oncall@company.com,team@company.com',
    cc_addresses = 'manager@company.com'
WHERE alert_type = 'FAILURE' AND customer_id IS NULL;

-- Update ESCALATION global TO/CC
UPDATE mail_recipients
SET to_addresses = 'escalation@company.com,manager@company.com',
    cc_addresses = 'director@company.com'
WHERE alert_type = 'ESCALATION' AND customer_id IS NULL;
```

**Customer-specific override** — overrides global for ONE customer:

```sql
-- Customer id=2 gets different SUCCESS recipients
INSERT INTO mail_recipients (alert_type, customer_id, to_addresses, cc_addresses, is_active)
VALUES ('SUCCESS', 2, 'cust2-team@company.com', 'cust2-manager@company.com', 1);

-- Customer id=2 gets different ESCALATION recipients
INSERT INTO mail_recipients (alert_type, customer_id, to_addresses, cc_addresses, is_active)
VALUES ('ESCALATION', 2, 'cust2-escalation@company.com', 'cust2-director@company.com', 1);
```

**Important:** All 4 alert types need a global row (customer_id NULL). The fresh_schema.sql inserts these automatically.

### 5.3 Email Templates (mail_templates table)

```sql
-- View all templates
SELECT template_key, subject_template FROM mail_templates;

-- Update escalation subject (ordinal is automatically inserted)
UPDATE mail_templates
SET subject_template = 'ACTION REQUIRED - {ordinal}: Health Check - {customer} - {env}'
WHERE template_key = 'escalation';

-- Update success email body HTML
UPDATE mail_templates
SET body_html = '...your custom HTML...'
WHERE template_key = 'success';
```

**Template placeholders:**

| Placeholder | Description | Used in |
|-------------|-------------|---------|
| `{customer}` | Customer name | All types |
| `{env}` | Environment label | All types |
| `{run_id}` | Run number | All types |
| `{date_time}` | Timestamp | All types |
| `{ordinal}` | First/Second/Third... | escalation |
| `{issue_table}` | HTML table of failing tests | escalation |
| `{error}` | Error message | failure |
| `{report_title}` | Full Excel title | success |
| `{attachment}` | Excel filename | success |
| `{max_attempts}` | Max rerun count | rerun_failure |

---

## 6. Testing All Features

### Test 1: Basic Run

```bash
python main.py run --customer MMS --env DEV
```

Expected console:
```
============================================================
  HC Run #1  |  MMS  |  DEV  |  MANUAL
============================================================
10:30:01 [INFO] [1/6] (16% done) Executing health checks
...
============================================================
  DONE  |  Status: COMPLETED  |  Duration: 48s
============================================================
```

Verify in DB:
```sql
SELECT id, status, started_at, completed_at FROM execution_runs ORDER BY id DESC LIMIT 1;
SELECT status, env_type FROM env_run_status ORDER BY id DESC LIMIT 1;
```

### Test 2: Excel Verification

Open the generated Excel file (path from system_config `excel_output_path`).

**Expected Excel layout:**
- Tab 1: Customer name (e.g. "MMS")
  - Column A: Test number
  - Column B: Test name
  - Column C: Value (actual result for PASS, **empty** for FAIL)
  - Column D: Action Required (No/Yes)
  - Column E: Failure Reason (**empty** for PASS, detail for FAIL)
- Tab "Failures": Only rows where Action Required = Yes, deduplicated
- Tab "Development - Argus - TS": Tablespace detail
- Tab "Development - Argus - RMAN": RMAN backup detail

**Key rule:** If a test FAILS — the Value column must be EMPTY and the Failure Reason must have the detail. Both should never have the same text.

### Test 3: Multi-Environment Excel

```bash
python main.py run --customer MMS --env DEV,PRD
```

Expected: One Excel file, one column block per environment on the same sheet.

### Test 4: Email Received

After a run completes, check:
```sql
SELECT alert_type, subject, recipients_to, recipients_cc, attachment_name, send_status, sent_at
FROM alert_history ORDER BY sent_at DESC LIMIT 5;
```

### Test 5: Escalation — Ordinal Subject

Simulate consecutive failures:
```sql
-- Manually set an issue to ESCALATED with 3 consecutive failures
INSERT INTO issue_tracker 
  (customer_id,env_type,server_id,oracle_db_id,test_catalog_id,
   first_failed_run_id,last_failed_run_id,consecutive_failures,
   total_failures,last_error_detail,status)
VALUES (1,'DEV',1,1,24,1,1,3,3,'RMAN backup not found today','ESCALATED');

-- Trigger a run — escalation email should fire
python main.py run --customer MMS --env DEV
```

Check email subject:
```sql
SELECT subject, escalation_ordinal FROM alert_history
WHERE alert_type='ESCALATION' ORDER BY sent_at DESC LIMIT 1;
-- Expected: "ACTION REQUIRED - Third Escalation: Health Check - MMS - DEV"
```

Second time (consecutive_failures increments to 4):
- Expected: "Fourth Escalation"

### Test 6: Escalation Stays Until Resolved

The issue should remain ESCALATED until the test **passes** again:

```sql
-- Check issue status after a run
SELECT id, consecutive_failures, status, last_escalated_at
FROM issue_tracker WHERE customer_id=1 AND env_type='DEV';
-- Status should stay ESCALATED until test passes
```

When the test passes (e.g. RMAN backup completes):
- Status changes to RESOLVED
- consecutive_failures resets to 0
- No more escalation emails

### Test 7: Disable a Test

```bash
python main.py disable-test --customer MMS --test-id 24 --env DEV
```

Run again:
```bash
python main.py run --customer MMS --env DEV
```

Verify in Excel: Test 24 (RMAN Backup) row should NOT appear in the output.

Re-enable:
```bash
python main.py enable-test --customer MMS --test-id 24 --env DEV
```

### Test 8: Pause Escalation

```bash
python main.py pause-escalation --customer MMS --env DEV --hours 24 --reason "Weekend maintenance"
```

Trigger a run with failing tests. Verify no escalation email was sent:
```sql
SELECT * FROM alert_history WHERE alert_type='ESCALATION' ORDER BY sent_at DESC LIMIT 1;
-- sent_at should be before the pause was set
```

Resume:
```bash
python main.py resume-escalation --customer MMS --env DEV
```

### Test 9: Rerun Queue

Force a failure and verify rerun is queued:
```sql
-- Create a FAILED run manually
INSERT INTO execution_runs (customer_id,env_types,run_type,status,triggered_by)
VALUES (1,'DEV','MANUAL','FAILED','test');
-- Check rerun_queue (launcher auto-queues on failure)
SELECT * FROM rerun_queue ORDER BY id DESC LIMIT 1;
```

### Test 10: Rerun Exhausted Email

```sql
-- Set max to 1 for testing
UPDATE system_config SET config_value='1' WHERE config_key='rerun_max_attempts';
```

Let a run fail and wait for the scheduler to try the rerun. After it fails:
```sql
SELECT * FROM alert_history WHERE alert_type='RERUN_FAILURE' ORDER BY sent_at DESC LIMIT 1;
-- Should show rerun exhausted email
```

Reset:
```sql
UPDATE system_config SET config_value='3' WHERE config_key='rerun_max_attempts';
```

### Test 11: Dashboard

```bash
python main.py dashboard
```

Expected sections:
- RECENT RUNS (last 15)
- OPEN / ESCALATED ISSUES
- PAUSED ESCALATIONS
- PENDING RERUNS
- TEST OVERRIDES

### Test 12: Scheduler (separate output format)

```bash
python main.py scheduler
```

Expected output uses `[SCHEDULER]` prefix, different from manual run format.

---

## 7. Test Management

Tests are defined in `test_catalog` (36 standard tests). You can disable/enable them:

### Global disable (affects all customers)

```sql
UPDATE test_catalog SET is_active=0 WHERE id=24;   -- disable RMAN check globally
UPDATE test_catalog SET is_active=1 WHERE id=24;   -- re-enable
```

### Per-customer/env disable

```bash
# Disable test 24 (RMAN Backup) for MMS DEV only
python main.py disable-test --customer MMS --test-id 24 --env DEV

# Disable test 24 for ALL environments of MMS
python main.py disable-test --customer MMS --test-id 24

# Re-enable
python main.py enable-test --customer MMS --test-id 24 --env DEV
```

Or directly in the database:

```sql
-- Disable test 24 for MMS DEV
INSERT INTO test_override (customer_id, env_type, test_catalog_id, is_active, reason)
VALUES (1, 'DEV', 24, 0, 'RMAN not configured on this server');

-- Disable test 24 for ALL envs of customer 1
INSERT INTO test_override (customer_id, env_type, test_catalog_id, is_active, reason)
VALUES (1, NULL, 24, 0, 'No RMAN on any MMS server');

-- View all overrides
SELECT c.name, to2.env_type, tc.test_name, to2.is_active, to2.reason
FROM test_override to2
JOIN customers c ON c.id=to2.customer_id
JOIN test_catalog tc ON tc.id=to2.test_catalog_id;
```

**Test catalog IDs reference:**

| ID | Test Name |
|----|-----------|
| 8 | Connection Status (DB Server) |
| 9 | Connection Status (Web Server) |
| 12 | Service Listeners |
| 15 | Database Connection (Argus) |
| 17 | Schema Password (Argus) |
| 19 | Table Space (Argus) |
| 21 | Archive Mode (Argus) |
| 22 | Archive Directory (Argus) |
| 23 | Last 8 Day Archive Log (Argus) |
| 24 | RMAN Backup (Argus) |
| 25-28 | Windows Auto Update (DB/Web/ESM/OAM) |
| 29-32 | Disk Space (DB/Web/ESM/OAM) |
| 33-36 | Task Schedulers (DB/Web/ESM/OAM) |

---

## 8. Escalation Management

### How escalation works

1. A test fails → `consecutive_failures` increments in `issue_tracker`
2. When `consecutive_failures >= threshold` → issue status = ESCALATED
3. Each escalation email respects `interval_hours` (won't re-send too soon)
4. Email subject uses ordinal: First, Second, Third Escalation...
5. Issue stays ESCALATED until the test **passes** → status = RESOLVED
6. When resolved, `consecutive_failures` resets to 0

### Escalation config per customer/env

```sql
-- View escalation configs
SELECT c.name, ec.env_type, ec.threshold, ec.interval_hours,
       ec.is_paused, ec.paused_until, ec.pause_reason
FROM escalation_config ec JOIN customers c ON c.id=ec.customer_id;

-- Change threshold to 5 for MMS PRD (escalate after 5 failures)
UPDATE escalation_config SET threshold=5 WHERE customer_id=1 AND env_type='PRD';

-- Change interval to 48 hours (send escalation at most every 2 days)
UPDATE escalation_config SET interval_hours=48 WHERE customer_id=1 AND env_type='DEV';

-- Stop escalation emails completely for one customer/env
UPDATE escalation_config SET is_paused=1, pause_reason='Planned downtime' WHERE customer_id=1 AND env_type='DEV';

-- Resume
UPDATE escalation_config SET is_paused=0, paused_until=NULL WHERE customer_id=1 AND env_type='DEV';
```

### Pause via CLI

```bash
# Pause for 1 week (168 hours)
python main.py pause-escalation --customer MMS --env DEV --hours 168 --reason "Scheduled maintenance"

# Pause indefinitely (omit --hours, set paused_until=NULL manually)
python main.py pause-escalation --customer MMS --env PRD --hours 99999 --reason "Customer request"

# Resume
python main.py resume-escalation --customer MMS --env DEV
```

---

## 9. Schedule Management

### View all schedules

```bash
python main.py list-schedules
```

Output:
```
ID    Customer           Envs       Schedule                  Cron            Active   Next Run
----- ------------------ ---------- ------------------------- --------------- -------- ------------------
1     MMS                DEV        MMS DEV Weekly            0 1 * * 0       no       —
```

### Enable / Disable

```bash
python main.py enable-schedule  --schedule-id 1
python main.py disable-schedule --schedule-id 1
```

Or SQL:
```sql
UPDATE schedules SET is_active=1 WHERE id=1;
UPDATE schedules SET is_active=0 WHERE id=1;
```

### Add multi-environment schedule

```sql
-- Run DEV and VAL together every Sunday 1AM (both in same Excel)
INSERT INTO schedules (customer_id, env_types, schedule_name, cron_expression, is_active)
VALUES (1, 'DEV,VAL', 'MMS DEV+VAL Weekly', '0 1 * * 0', 1);
```

### Add a second schedule for same customer

```sql
-- Also run PRD every Wednesday night
INSERT INTO schedules (customer_id, env_types, schedule_name, cron_expression, is_active)
VALUES (1, 'PRD', 'MMS PRD Weekly', '0 22 * * 3', 1);
```

---

## 10. Excel Report Explained

### Sheet structure

| Sheet | Content |
|-------|---------|
| Customer name (e.g. "MMS") | Main results — test rows × env columns |
| Failures | Summary of all failed tests (Action Required=Yes) |
| Dev - Argus - TS | Tablespace detail for DEV/Argus |
| Dev - Argus - RMAN | RMAN backup detail for DEV/Argus |

### Column rules

| Test Result | Value column | Action Required | Failure Reason |
|-------------|-------------|-----------------|----------------|
| PASS | Actual result (e.g. "Connection Established") | No | (empty) |
| FAIL | **(empty)** | **Yes** | Error detail |
| INFO row (Customer/Env/IP) | Info text | (blank) | (empty) |
| DISABLED test | Row not shown | — | — |

**Important:** When a test FAILS, the Value column is always empty. The Failure Reason column has the detail. This prevents confusion where Value and Failure Reason show the same text.

### Color coding

- Green: PASS (action=No, has a value)
- Red: FAIL (action=Yes)
- Yellow: Column headers
- Blue header: Environment name (top of value column)

### Failures sheet (deduplicated)

Shows ONLY tests where Action Required = Yes. If the same test fails with the same reason across multiple DB checks, it appears once only (deduplicated by test_name + failure_reason).

---

## 11. CLI Commands

| Command | Example | Description |
|---------|---------|-------------|
| `scheduler` | `python main.py scheduler` | Start continuous scheduler |
| `run` | `python main.py run --customer MMS --env DEV` | Manual run for one customer/env |
| `run-all` | `python main.py run-all` | Fire all active schedules now |
| `rerun` | `python main.py rerun --run-id 42` | Rerun a failed run |
| `dashboard` | `python main.py dashboard` | Live status overview |
| `list-schedules` | `python main.py list-schedules` | Show all schedules with status |
| `enable-schedule` | `python main.py enable-schedule --schedule-id 1` | Enable a schedule |
| `disable-schedule` | `python main.py disable-schedule --schedule-id 1` | Disable a schedule |
| `disable-test` | `python main.py disable-test --customer MMS --test-id 24 --env DEV` | Hide test from Excel |
| `enable-test` | `python main.py enable-test --customer MMS --test-id 24` | Show test in Excel |
| `pause-escalation` | `python main.py pause-escalation --customer MMS --env PRD --hours 48` | Pause escalation emails |
| `resume-escalation` | `python main.py resume-escalation --customer MMS --env PRD` | Resume escalation emails |
| `encrypt-password` | `python main.py encrypt-password` | Encrypt a password for DB |

---

## 12. Database Tables Reference

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `customers` | Customer list | name, code, is_active |
| `environments` | Customer environments (DEV/VAL/PRD) | customer_id, env_type, server_user, server_pwd |
| `servers` | Windows servers per environment | env_id, server_role, host, service_listeners |
| `oracle_databases` | Oracle DBs per server | server_id, db_name, db_type, db_user, db_pwd |
| `test_catalog` | 36 standard tests | id, test_name, is_active |
| `test_override` | Per-customer test enable/disable | customer_id, env_type, test_catalog_id, is_active |
| `oracle_queries` | Oracle SQL statements | query_key, query_sql |
| `mail_config` | SMTP server settings | smtp_host, smtp_port, smtp_user, is_active |
| `mail_recipients` | TO/CC per alert type | alert_type, customer_id (NULL=global), to_addresses, cc_addresses |
| `mail_templates` | HTML email templates | template_key, subject_template, body_html |
| `system_config` | Operational settings | config_key, config_value, config_group |
| `escalation_config` | Per-customer escalation rules | customer_id, env_type, threshold, interval_hours, is_paused |
| `schedules` | Per-customer cron schedules | customer_id, env_types, cron_expression, is_active |
| `execution_runs` | Run records | customer_id, env_types, status, run_type |
| `env_run_status` | Per-env run result | run_id, env_type, status |
| `execution_logs` | Detailed logs | run_id, log_level, message, py_file, py_line |
| `server_check_results` | Server check data | env_status_id, connection_ok, disk_space_detail |
| `db_check_results` | Oracle check data | env_status_id, rman_detail, tablespace_detail |
| `tablespace_usage` | Tablespace detail rows | db_check_id, tablespace_name, used_pct |
| `rman_backup_details` | RMAN detail rows | db_check_id, status, start_time |
| `issue_tracker` | Consecutive failure tracking | customer_id, test_catalog_id, consecutive_failures, status |
| `alert_history` | All emails sent | alert_type, subject, recipients_to, send_status |
| `rerun_queue` | Automatic rerun schedule | original_run_id, attempt_number, scheduled_at |

---

## 13. Troubleshooting

### Email not sending

```sql
-- 1. Check SMTP config
SELECT * FROM mail_config WHERE is_active=1;

-- 2. Check last failed emails
SELECT alert_type, subject, send_status, error_message, sent_at
FROM alert_history WHERE send_status='FAILED' ORDER BY sent_at DESC LIMIT 5;
```

Common errors:
- `SMTP auth failed` → Check smtp_user and smtp_password in mail_config
- `Connection refused` → Check smtp_host and smtp_port

### No TO address / email skipped

```sql
SELECT alert_type, customer_id, to_addresses, is_active FROM mail_recipients;
-- Must have a row with customer_id=NULL (global default) for each alert_type
-- OR a row matching the specific customer
```

### Escalation not firing

```sql
-- Check escalation config
SELECT * FROM escalation_config WHERE customer_id=1;
-- is_paused must be 0 AND paused_until must be NULL or in the past

-- Check issue status
SELECT consecutive_failures, status, last_escalated_at FROM issue_tracker WHERE customer_id=1;
-- consecutive_failures must be >= threshold

-- Check interval
-- If last_escalated_at is recent, wait for interval_hours to pass
```

### Test appears in Excel even though disabled

```sql
-- Check override was inserted correctly
SELECT * FROM test_override WHERE customer_id=1 AND test_catalog_id=24;
-- is_active must be 0 to disable
-- env_type must match (NULL=all, or specific env)
```

### Excel value and failure reason showing same text

This was a bug in older versions. In v5:
- PASS: `value = actual result`, `reason = empty`
- FAIL: `value = empty`, `reason = error detail`

If you see the old behaviour, verify you are running v5 code (check `reports/excel_generator.py`).

### Logs query

```sql
-- All logs for a specific run
SELECT log_level, py_file, py_function, py_line, message, logged_at
FROM execution_logs WHERE run_id=8 ORDER BY logged_at;

-- Only errors
SELECT log_level, py_file, py_function, py_line, message
FROM execution_logs WHERE run_id=8 AND log_level IN ('ERROR','CRITICAL')
ORDER BY logged_at;

-- Step progress for a run
SELECT message FROM execution_logs
WHERE run_id=8 AND message LIKE '[%/%]%'
ORDER BY logged_at;
```

### Reset config cache (if you changed system_config at runtime)

```python
# In Python code:
from core.config import ConfigLoader
ConfigLoader.reset()
# Then call ConfigLoader.load(db) again
```

---

*Health Check v5 — Navitas Life Sciences RPA Team — 2026*

"""
main.py  (v5)
=============
Health Check v5 — Command-Line Entry Point

COMMANDS:
  python main.py scheduler                     Start continuous scheduler
  python main.py run --customer MMS --env DEV  Manual run
  python main.py run-all                       Trigger all active schedules
  python main.py rerun --run-id 42             Re-run a failed run
  python main.py dashboard                     Show live status dashboard

  # Test overrides per customer/env
  python main.py disable-test --customer MMS --test-id 24 --env DEV
  python main.py enable-test  --customer MMS --test-id 24 --env DEV

  # Escalation management
  python main.py pause-escalation  --customer MMS --env DEV --hours 48 --reason "Maintenance"
  python main.py resume-escalation --customer MMS --env DEV

  # Schedule management
  python main.py list-schedules
  python main.py enable-schedule  --schedule-id 1
  python main.py disable-schedule --schedule-id 1

  # Utilities
  python main.py encrypt-password
"""
import argparse
import sys
import traceback
from datetime import datetime, timedelta


def _get_customer(db, code: str):
    c = db.fetch_one("SELECT * FROM customers WHERE code=%s AND is_active=1", (code,))
    if not c:
        print(f"ERROR: Customer '{code}' not found or inactive.")
        sys.exit(1)
    return c


# ──────────────────────────────────────────────────────────────
# scheduler
# ──────────────────────────────────────────────────────────────
def cmd_scheduler(args):
    from scheduling.scheduler import HealthCheckScheduler
    sched = HealthCheckScheduler()
    try:
        sched.start()
    except KeyboardInterrupt:
        sched.stop()
        print("\n[SCHEDULER] Stopped.")


# ──────────────────────────────────────────────────────────────
# run  (manual, clear numbered output)
# ──────────────────────────────────────────────────────────────
def cmd_run(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader
    from scheduling.run_launcher import RunLauncher
    import time

    env_types = args.env.upper().replace(" ", "")
    valid = {"PRD","VAL","DEV"}
    bad   = {e.strip() for e in env_types.split(",")} - valid
    if bad:
        print(f"ERROR: Invalid env type(s): {bad}. Use PRD, VAL, or DEV.")
        sys.exit(1)

    with DBManager() as db:
        cfg      = ConfigLoader.load(db)
        customer = _get_customer(db, args.customer.upper())
        run_id   = db.insert_get_id(
            "INSERT INTO execution_runs (customer_id,env_types,run_type,status,triggered_by) VALUES(%s,%s,'MANUAL','PENDING',%s)",
            (customer["id"], env_types, "cli:run"))

        print()
        print("=" * 60)
        print(f"  HC Run #{run_id}  |  {customer['name']}  |  {env_types}  |  MANUAL")
        print("=" * 60)
        t0 = time.time()
        RunLauncher(db, run_id, cfg).launch()
        elapsed = int(time.time() - t0)
        final   = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
        status  = final["status"] if final else "UNKNOWN"
        print("=" * 60)
        print(f"  DONE  |  Status: {status}  |  Duration: {elapsed}s")
        print("=" * 60)
        print()


# ──────────────────────────────────────────────────────────────
# run-all
# ──────────────────────────────────────────────────────────────
def cmd_run_all(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader
    from scheduling.run_launcher import RunLauncher
    import time

    with DBManager() as db:
        cfg   = ConfigLoader.load(db)
        scheds = db.fetch_all(
            "SELECT s.*,c.name AS cname FROM schedules s JOIN customers c ON c.id=s.customer_id WHERE s.is_active=1 AND c.is_active=1")
        print(f"Triggering {len(scheds)} active schedule(s)...")
        for s in scheds:
            run_id = db.insert_get_id(
                "INSERT INTO execution_runs (schedule_id,customer_id,env_types,run_type,status,triggered_by) VALUES(%s,%s,%s,'MANUAL','PENDING','cli:run-all')",
                (s["id"], s["customer_id"], s["env_types"]))
            print(f"  Run #{run_id}: {s['cname']} / {s['env_types']} ...", end="", flush=True)
            t0 = time.time()
            RunLauncher(db, run_id, cfg).launch()
            elapsed = int(time.time() - t0)
            final = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            print(f" {final['status']} ({elapsed}s)")


# ──────────────────────────────────────────────────────────────
# rerun
# ──────────────────────────────────────────────────────────────
def cmd_rerun(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader
    from scheduling.run_launcher import RunLauncher
    import time

    with DBManager() as db:
        cfg = ConfigLoader.load(db)
        run = db.fetch_one("SELECT * FROM execution_runs WHERE id=%s", (args.run_id,))
        if not run:
            print(f"ERROR: Run #{args.run_id} not found."); sys.exit(1)
        new_id = db.insert_get_id(
            "INSERT INTO execution_runs (customer_id,env_types,run_type,status,triggered_by,rerun_of_run_id,rerun_attempt) VALUES(%s,%s,'RERUN','PENDING','cli:rerun',%s,1)",
            (run["customer_id"], run["env_types"], run["id"]))
        print(f"Rerun #{new_id} (from original #{args.run_id}) ...", end="", flush=True)
        t0 = time.time()
        RunLauncher(db, new_id, cfg).launch()
        elapsed = int(time.time() - t0)
        final = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (new_id,))
        print(f" {final['status']} ({elapsed}s)")


# ──────────────────────────────────────────────────────────────
# disable-test / enable-test
# ──────────────────────────────────────────────────────────────
def cmd_disable_test(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        customer = _get_customer(db, args.customer.upper())
        env_type = args.env.upper() if args.env else None
        test_id  = args.test_id

        # Upsert: if exists update, else insert
        existing = db.fetch_one(
            "SELECT id FROM test_override WHERE customer_id=%s AND env_type<=>%s AND test_catalog_id=%s",
            (customer["id"], env_type, test_id))
        if existing:
            db.execute("UPDATE test_override SET is_active=0 WHERE id=%s", (existing["id"],))
        else:
            db.execute(
                "INSERT INTO test_override (customer_id,env_type,test_catalog_id,is_active) VALUES(%s,%s,%s,0)",
                (customer["id"], env_type, test_id))

        scope = f"{args.customer}/{env_type or 'ALL'}"
        print(f"Test {test_id} DISABLED for {scope}")
        print("  This test will not appear in Excel output for this customer/env.")


def cmd_enable_test(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        customer = _get_customer(db, args.customer.upper())
        env_type = args.env.upper() if args.env else None
        test_id  = args.test_id
        existing = db.fetch_one(
            "SELECT id FROM test_override WHERE customer_id=%s AND env_type<=>%s AND test_catalog_id=%s",
            (customer["id"], env_type, test_id))
        if existing:
            db.execute("UPDATE test_override SET is_active=1 WHERE id=%s", (existing["id"],))
        else:
            db.execute(
                "INSERT INTO test_override (customer_id,env_type,test_catalog_id,is_active) VALUES(%s,%s,%s,1)",
                (customer["id"], env_type, test_id))
        scope = f"{args.customer}/{env_type or 'ALL'}"
        print(f"Test {test_id} ENABLED for {scope}")


# ──────────────────────────────────────────────────────────────
# pause-escalation / resume-escalation
# ──────────────────────────────────────────────────────────────
def cmd_pause_escalation(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        customer  = _get_customer(db, args.customer.upper())
        env_type  = args.env.upper()
        hours     = args.hours or 168
        until     = datetime.now() + timedelta(hours=hours)
        reason    = args.reason or "Manual pause"

        row = db.fetch_one("SELECT id FROM escalation_config WHERE customer_id=%s AND env_type=%s",
                           (customer["id"], env_type))
        if row:
            db.execute("UPDATE escalation_config SET is_paused=1,paused_until=%s,pause_reason=%s WHERE id=%s",
                       (until, reason, row["id"]))
        else:
            db.execute(
                "INSERT INTO escalation_config (customer_id,env_type,is_paused,paused_until,pause_reason) VALUES(%s,%s,1,%s,%s)",
                (customer["id"], env_type, until, reason))
        print(f"Escalation PAUSED for {args.customer}/{env_type}")
        print(f"  Until: {until.strftime('%Y-%m-%d %H:%M')} | Reason: {reason}")


def cmd_resume_escalation(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        customer = _get_customer(db, args.customer.upper())
        env_type = args.env.upper()
        n = db.execute("UPDATE escalation_config SET is_paused=0,paused_until=NULL WHERE customer_id=%s AND env_type=%s",
                       (customer["id"], env_type))
        print(f"Escalation RESUMED for {args.customer}/{env_type} ({n} row(s) updated)")


# ──────────────────────────────────────────────────────────────
# list-schedules / enable-schedule / disable-schedule
# ──────────────────────────────────────────────────────────────
def cmd_list_schedules(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        rows = db.fetch_all(
            "SELECT s.*,c.name AS cname FROM schedules s JOIN customers c ON c.id=s.customer_id ORDER BY c.name,s.env_types")
        print(f"\n{'ID':<5} {'Customer':<18} {'Envs':<10} {'Schedule':<25} {'Cron':<15} {'Active':<8} Next Run")
        print("-" * 100)
        for r in rows:
            nxt = r["next_run_at"].strftime("%Y-%m-%d %H:%M") if r["next_run_at"] else "—"
            active = "YES" if r["is_active"] else "no"
            print(f"{r['id']:<5} {r['cname'][:17]:<18} {r['env_types']:<10} {r['schedule_name'][:24]:<25} {r['cron_expression']:<15} {active:<8} {nxt}")
        print()


def cmd_enable_schedule(args):
    from core.db_manager import DBManager
    with DBManager() as db:
        db.execute("UPDATE schedules SET is_active=1 WHERE id=%s", (args.schedule_id,))
        print(f"Schedule #{args.schedule_id} ENABLED")

def cmd_disable_schedule(args):
    from core.db_manager import DBManager
    with DBManager() as db:
        db.execute("UPDATE schedules SET is_active=0 WHERE id=%s", (args.schedule_id,))
        print(f"Schedule #{args.schedule_id} DISABLED")


# ──────────────────────────────────────────────────────────────
# dashboard
# ──────────────────────────────────────────────────────────────
def cmd_dashboard(args):
    from core.db_manager import DBManager
    from core.config import ConfigLoader

    with DBManager() as db:
        ConfigLoader.load(db)
        W = 90
        print(f"\n{'='*W}")
        print(f"  HEALTH CHECK v5 — DASHBOARD  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*W}")

        # Recent runs
        runs = db.fetch_all(
            "SELECT er.id,c.name,er.env_types,er.run_type,er.status,er.started_at FROM execution_runs er JOIN customers c ON c.id=er.customer_id ORDER BY er.id DESC LIMIT 15")
        print(f"\nRECENT RUNS (last 15)")
        print(f"  {'ID':<6} {'Customer':<18} {'Envs':<10} {'Type':<12} {'Status':<12} Started")
        print(f"  {'-'*6} {'-'*18} {'-'*10} {'-'*12} {'-'*12} {'-'*18}")
        for r in runs:
            started = r["started_at"].strftime("%Y-%m-%d %H:%M") if r["started_at"] else "—"
            print(f"  {r['id']:<6} {r['name'][:17]:<18} {r['env_types']:<10} {r['run_type']:<12} {r['status']:<12} {started}")

        # Open issues
        issues = db.fetch_all(
            """SELECT c.name,it.env_type,tc.test_name,it.consecutive_failures,
                      it.total_failures,it.status,it.escalation_send_count
               FROM issue_tracker it JOIN customers c ON c.id=it.customer_id
               JOIN test_catalog tc ON tc.id=it.test_catalog_id
               WHERE it.status IN ('OPEN','ESCALATED') ORDER BY it.consecutive_failures DESC LIMIT 20""")
        print(f"\nOPEN / ESCALATED ISSUES")
        if not issues:
            print("  None.")
        else:
            print(f"  {'Customer':<18} {'Env':<5} {'Test':<36} {'Consec':<8} {'Total':<7} {'Status':<12} Esc#")
            for i in issues:
                print(f"  {i['name'][:17]:<18} {i['env_type']:<5} {i['test_name'][:35]:<36} "
                      f"{i['consecutive_failures']:<8} {i['total_failures']:<7} {i['status']:<12} {i['escalation_send_count']}")

        # Paused escalations
        try:
            pauses = db.fetch_all(
                """SELECT c.name,ep.env_type,ep.paused_until,ep.pause_reason
                   FROM escalation_config ep JOIN customers c ON c.id=ep.customer_id
                   WHERE ep.is_paused=1 AND (ep.paused_until IS NULL OR ep.paused_until>NOW())""")
            print(f"\nPAUSED ESCALATIONS")
            if not pauses:
                print("  None.")
            else:
                for p in pauses:
                    until = str(p["paused_until"]) if p["paused_until"] else "until manual resume"
                    print(f"  {p['name']}/{p['env_type']} — paused until {until} — {p['pause_reason']}")
        except Exception: pass

        # Pending reruns
        reruns = db.fetch_all(
            """SELECT rq.id,c.name,rq.env_types,rq.attempt_number,rq.max_attempts,rq.scheduled_at
               FROM rerun_queue rq JOIN customers c ON c.id=rq.customer_id WHERE rq.status='PENDING' ORDER BY rq.scheduled_at""")
        print(f"\nPENDING RERUNS ({len(reruns)})")
        for r in reruns:
            print(f"  #{r['id']:>4}  {r['name']:<18}  {r['env_types']:<8}  "
                  f"attempt {r['attempt_number']}/{r['max_attempts']}  scheduled: {r['scheduled_at']}")
        if not reruns: print("  None.")

        # Active test overrides
        try:
            ovr = db.fetch_all(
                """SELECT c.name,to2.env_type,tc.test_name,to2.is_active
                   FROM test_override to2 JOIN customers c ON c.id=to2.customer_id
                   JOIN test_catalog tc ON tc.id=to2.test_catalog_id""")
            print(f"\nTEST OVERRIDES")
            if not ovr: print("  None.")
            else:
                for o in ovr:
                    state = "ENABLED" if o["is_active"] else "DISABLED"
                    env = o["env_type"] or "ALL"
                    print(f"  {o['name']}/{env} — test '{o['test_name']}' → {state}")
        except Exception: pass
        print()


def cmd_encrypt_password(args):
    import getpass
    from utils.crypto import encrypt_password, decrypt_password
    print("\nHealth Check v5 - Password Encryption")
    print("=" * 50)
    plain = getpass.getpass("Enter plain-text password: ")
    if not plain: print("ERROR: Cannot be empty."); sys.exit(1)
    enc = encrypt_password(plain)
    print(f"\nEncrypted value (store in DB):\n  {enc}")
    try:
        if decrypt_password(enc) == plain: print("\n[OK] Round-trip verified.")
        else: print("\n[WARNING] Round-trip mismatch — check HC_ENC_KEY env var.")
    except Exception as e: print(f"\n[ERROR] {e}")


# ──────────────────────────────────────────────────────────────
# Argument parser
# ──────────────────────────────────────────────────────────────
def main():
    p = argparse.ArgumentParser(description="Health Check v5", epilog=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("scheduler",        help="Start continuous scheduler")
    sub.add_parser("run-all",          help="Trigger all active schedules now")
    sub.add_parser("dashboard",        help="Show live dashboard")
    sub.add_parser("list-schedules",   help="List all schedules")
    sub.add_parser("encrypt-password", help="Encrypt a password for DB storage")

    pr = sub.add_parser("run",    help="Manual run")
    pr.add_argument("--customer", required=True, help="Customer code e.g. MMS")
    pr.add_argument("--env",      required=True, help="Env type(s) e.g. PRD or DEV,VAL")

    prr = sub.add_parser("rerun", help="Re-run a failed run")
    prr.add_argument("--run-id", type=int, required=True)

    pdt = sub.add_parser("disable-test", help="Disable a test for a customer/env")
    pdt.add_argument("--customer", required=True)
    pdt.add_argument("--test-id",  type=int, required=True, help="Test catalog ID (1-36)")
    pdt.add_argument("--env",      default=None, help="Specific env type (omit=all envs)")

    pet = sub.add_parser("enable-test", help="Enable a test for a customer/env")
    pet.add_argument("--customer", required=True)
    pet.add_argument("--test-id",  type=int, required=True)
    pet.add_argument("--env",      default=None)

    ppe = sub.add_parser("pause-escalation",  help="Pause escalation emails")
    ppe.add_argument("--customer", required=True)
    ppe.add_argument("--env",      required=True)
    ppe.add_argument("--hours",    type=int, default=168, help="Pause for N hours (default 168=1 week)")
    ppe.add_argument("--reason",   default="Manual pause")

    pre = sub.add_parser("resume-escalation", help="Resume escalation emails")
    pre.add_argument("--customer", required=True)
    pre.add_argument("--env",      required=True)

    pes = sub.add_parser("enable-schedule",  help="Enable a schedule by ID")
    pes.add_argument("--schedule-id", type=int, required=True)

    pds = sub.add_parser("disable-schedule", help="Disable a schedule by ID")
    pds.add_argument("--schedule-id", type=int, required=True)

    args = p.parse_args()
    dispatch = {
        "scheduler":          cmd_scheduler,
        "run":                cmd_run,
        "run-all":            cmd_run_all,
        "rerun":              cmd_rerun,
        "disable-test":       cmd_disable_test,
        "enable-test":        cmd_enable_test,
        "pause-escalation":   cmd_pause_escalation,
        "resume-escalation":  cmd_resume_escalation,
        "list-schedules":     cmd_list_schedules,
        "enable-schedule":    cmd_enable_schedule,
        "disable-schedule":   cmd_disable_schedule,
        "dashboard":          cmd_dashboard,
        "encrypt-password":   cmd_encrypt_password,
    }
    if not args.cmd or args.cmd not in dispatch:
        p.print_help(); sys.exit(0)
    try:
        dispatch[args.cmd](args)
    except SystemExit:
        raise
    except Exception as exc:
        print(f"\nFATAL: {exc}"); traceback.print_exc(); sys.exit(1)


if __name__ == "__main__":
    main()

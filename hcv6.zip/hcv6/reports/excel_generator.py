"""
reports/excel_generator.py  (v6)
==================================
Generates Health Check Excel report.

v6 changes vs v5:
  1. Tablespace and RMAN sheets are ALWAYS created for every Argus DB
     in the run — even when there is no data. They include column headers
     and a "No data available" row if the table is empty.
  2. First row of the main customer sheet shows the run execution time:
       "Run #8  |  Started: 2026-04-17 10:30:01  |  Completed: 2026-04-17 10:31:45"
     Test data starts at row 3 (row 2 = column headers).

Excel layout rules (unchanged from v5):
  PASS row:  Value = actual result | Action Required = No | Failure Reason = (empty)
  FAIL row:  Value = (empty)       | Action Required = Yes | Failure Reason = error detail
  INFO row:  Value = info text     | Action Required = (blank) | Failure Reason = (empty)
  DISABLED:  Row not shown at all
"""
import os
import datetime
from typing import Dict, List, Optional, Set, Tuple

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from core.db_manager import DBManager
from core.config import ConfigLoader

# Styles
_Y  = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
_G  = PatternFill(start_color="C8E6C9", end_color="C8E6C9", fill_type="solid")
_R  = PatternFill(start_color="FFCDD2", end_color="FFCDD2", fill_type="solid")
_BH = PatternFill(start_color="1565C0", end_color="1565C0", fill_type="solid")
_LB = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")  # light blue for run-time row
_BW = Font(bold=True, color="FFFFFF")
_B  = Font(bold=True)
_BR = Font(bold=True, color="C62828")

ENV_LABELS = {"PRD": "Production", "VAL": "Validation", "DEV": "Development"}

# Row offset: row 1 = run-time info, row 2 = column headers, row 3+ = test data
_DATA_ROW_OFFSET = 2  # display_order + DATA_ROW_OFFSET = actual Excel row


class ExcelReportGenerator:
    """
    Build the HC Excel report for one execution_run.

    Usage:
        gen = ExcelReportGenerator(db, run_id, logger)
        filepath, title = gen.generate()
    """

    def __init__(self, db: DBManager, run_id: int, logger):
        self.db      = db
        self.run_id  = run_id
        self.logger  = logger
        self.cfg     = ConfigLoader.get()
        self.wb      = Workbook()
        if "Sheet" in self.wb.sheetnames:
            del self.wb["Sheet"]

    # ================================================================== #
    # ENTRY POINT
    # ================================================================== #

    def generate(self) -> Tuple[str, str]:
        self.logger.info(f"Starting Excel generation for run_id={self.run_id}")

        run = self.db.fetch_one("SELECT * FROM execution_runs WHERE id=%s", (self.run_id,))
        customer = self.db.fetch_one("SELECT * FROM customers WHERE id=%s", (run["customer_id"],))

        env_statuses = self.db.fetch_all(
            "SELECT * FROM env_run_status WHERE run_id=%s AND customer_id=%s AND status='COMPLETED' ORDER BY env_type",
            (self.run_id, run["customer_id"]))

        if not env_statuses:
            raise ValueError(f"No completed environments for run_id={self.run_id}")

        active_tests = self._load_active_tests(run["customer_id"], None)
        self.logger.debug(f"Active tests: {len(active_tests)}")

        # Build title
        env_names = sorted({ENV_LABELS.get(e["env_type"], e["env_type"]) for e in env_statuses})
        env_str = (f"{env_names[0]} Server" if len(env_names) == 1
                   else ", ".join(env_names[:-1]) + f" and {env_names[-1]} Servers")
        prefix = self.cfg.excel_title_prefix
        base_title  = f"{prefix} - {customer['name']} - {env_str}"
        has_action  = self._any_action_required(run["customer_id"])
        email_title = f"Action Required - {base_title}" if has_action else base_title
        self.logger.info(f"Report title: '{email_title}'")

        # Main sheet
        ws = self.wb.create_sheet(customer["name"][:30])
        all_failures = self._write_main_sheet(ws, active_tests, customer, env_statuses, run)

        # Failures summary sheet
        if all_failures:
            self._write_failures_sheet(all_failures)

        # Detail sheets per env — ALWAYS create TS and RMAN even if no data
        for es in env_statuses:
            self._write_tablespace_sheets(es)
            self._write_rman_sheets(es)

        # Save file
        os.makedirs(self.cfg.excel_output_path, exist_ok=True)
        ts       = datetime.datetime.now().strftime("%d-%b-%y")
        filename = (f"{base_title}_{ts}_{self.run_id}.xlsx"
                    .replace("/", "-").replace("\\", "-"))
        filepath = os.path.join(self.cfg.excel_output_path, filename)
        self.wb.save(filepath)
        self.logger.info(f"Excel saved: {filepath}")
        return filepath, email_title

    # ================================================================== #
    # LOAD ACTIVE TESTS
    # ================================================================== #

    def _load_active_tests(self, customer_id: int, env_type: Optional[str]) -> List[Dict]:
        all_tests = self.db.fetch_all("SELECT * FROM test_catalog ORDER BY display_order")
        overrides: Dict[int, int] = {}
        try:
            params = [customer_id]
            q = ("SELECT test_catalog_id, is_active FROM test_override "
                 "WHERE customer_id=%s AND is_active IS NOT NULL")
            if env_type:
                q += " AND (env_type=%s OR env_type IS NULL)"
                params.append(env_type)
            else:
                q += " AND env_type IS NULL"
            for r in self.db.fetch_all(q, tuple(params)):
                overrides[r["test_catalog_id"]] = r["is_active"]
        except Exception:
            pass
        result = []
        for t in all_tests:
            tid = t["id"]
            if tid in overrides:
                if overrides[tid] == 1:
                    result.append(t)
            elif t["is_active"]:
                result.append(t)
        return result

    # ================================================================== #
    # MAIN SHEET
    # ================================================================== #

    def _write_main_sheet(self, ws, active_tests: List[Dict], customer: Dict,
                          env_statuses: List[Dict], run: Dict) -> List[Dict]:
        # ---- Row 1: Run execution time info ----
        started_str   = (run["started_at"].strftime("%Y-%m-%d %H:%M:%S")
                         if run.get("started_at") else "—")
        completed_str = (run["completed_at"].strftime("%Y-%m-%d %H:%M:%S")
                         if run.get("completed_at") else "—")
        info_text = (
            f"Run #{self.run_id}  |  Customer: {customer['name']}  |  "
            f"Started: {started_str}  |  Completed: {completed_str}  |  "
            f"Status: {run.get('status', '—')}"
        )
        # Merge row 1 across all columns (cols A to enough)
        total_cols = 2 + len(env_statuses) * 3
        ws.merge_cells(start_row=1, start_column=1,
                       end_row=1, end_column=max(total_cols, 5))
        c1 = ws.cell(row=1, column=1, value=info_text)
        c1.font = Font(bold=True, color="1565C0")
        c1.fill = _LB
        c1.alignment = Alignment(wrap_text=False, vertical="center")
        ws.row_dimensions[1].height = 20

        # ---- Row 2: Column headers (No / Test) ----
        ws.column_dimensions["A"].width = 5
        ws.column_dimensions["B"].width = 55
        for col, hdr in [(1, "No"), (2, "Test")]:
            c = ws.cell(row=2, column=col, value=hdr)
            c.font = _B; c.fill = _Y

        # ---- Rows 3+: Test names ----
        for t in active_tests:
            row = t["display_order"] + _DATA_ROW_OFFSET  # +2 because row1=info, row2=headers
            ws.cell(row=row, column=1, value=t["id"]).font   = _B
            ws.cell(row=row, column=2, value=t["test_name"]).font = _B

        ws.freeze_panes = "C3"  # freeze first two rows and first two cols

        all_failures: List[Dict] = []
        col_offset = 3
        for es in env_statuses:
            env_lbl = ENV_LABELS.get(es["env_type"], es["env_type"])
            results, env_failures = self._build_result_map(es, customer)
            all_failures.extend(env_failures)
            col_offset = self._write_env_columns(ws, active_tests, results, env_lbl, col_offset)

        return all_failures

    def _write_env_columns(self, ws, active_tests: List[Dict], results: Dict,
                           env_label: str, start_col: int) -> int:
        c1, c2, c3 = start_col, start_col + 1, start_col + 2

        # Row 2: env column headers
        h1 = ws.cell(row=2, column=c1, value=f"{env_label} — Value")
        h1.font = _BW; h1.fill = _BH
        h2 = ws.cell(row=2, column=c2, value="Action Required")
        h2.font = _B; h2.fill = _Y
        h3 = ws.cell(row=2, column=c3, value="Failure Reason")
        h3.font = _B; h3.fill = _Y
        for col in [c1, c2, c3]:
            ws.column_dimensions[get_column_letter(col)].width = 32

        for t in active_tests:
            row   = t["display_order"] + _DATA_ROW_OFFSET
            tid   = t["id"]
            data  = results.get(tid)
            if data is None:
                continue
            value  = data.get("value", "")
            action = data.get("action", "No")
            reason = data.get("reason", "")

            ws.cell(row=row, column=c1, value=value)
            ws.cell(row=row, column=c2, value=action)
            ws.cell(row=row, column=c3, value=reason)

            fill = _R if str(action).upper() == "YES" else (_G if value else None)
            if fill:
                for col in [c1, c2, c3]:
                    ws.cell(row=row, column=col).fill = fill

        return start_col + 3

    # ================================================================== #
    # BUILD RESULT MAP
    # ================================================================== #

    def _build_result_map(self, env_status: Dict, customer: Dict) -> Tuple[Dict, List[Dict]]:
        results: Dict[int, Dict] = {}
        failures: List[Dict]     = []
        esid = env_status["id"]
        elbl = ENV_LABELS.get(env_status["env_type"], env_status["env_type"])

        results[1] = {"value": customer["name"],        "action": "",  "reason": ""}
        results[2] = {"value": elbl,                    "action": "",  "reason": ""}
        results[3] = {"value": customer["tenant_type"], "action": "",  "reason": ""}

        role_ip   = {"DB": 4,  "Web": 5,  "ESM": 6,  "OAM": 7}
        role_conn = {"DB": 8,  "Web": 9,  "ESM": 10, "OAM": 11}
        role_wu   = {"DB": 25, "Web": 26, "ESM": 27, "OAM": 28}
        role_disk = {"DB": 29, "Web": 30, "ESM": 31, "OAM": 32}
        role_sched= {"DB": 33, "Web": 34, "ESM": 35, "OAM": 36}

        def _add_fail(test_name, server_db, reason):
            failures.append({"test_name": test_name, "env_label": elbl,
                              "server_db": server_db, "reason": reason})

        def _tname(tid):
            r = self.db.fetch_one("SELECT test_name FROM test_catalog WHERE id=%s", (tid,))
            return r["test_name"] if r else str(tid)

        def _r(tid, value="", action="No", reason=""):
            return {"value": value, "action": action, "reason": reason}

        for scr in self.db.fetch_all(
                "SELECT * FROM server_check_results WHERE env_status_id=%s", (esid,)):
            srv = self.db.fetch_one("SELECT * FROM servers WHERE id=%s", (scr["server_id"],))
            if not srv: continue
            role = srv["server_role"]
            slbl = srv["server_name"]

            if role in role_ip:
                results[role_ip[role]] = _r(role_ip[role], value=srv["host"])

            if role in role_conn:
                tid = role_conn[role]
                if scr["connection_ok"]:
                    results[tid] = _r(tid, value="Connection Established")
                else:
                    results[tid] = _r(tid, action="Yes", reason=scr["connection_status"])
                    _add_fail(_tname(tid), slbl, scr["connection_status"])

            if role == "DB" and scr.get("listeners_detail") is not None:
                if scr["listeners_action"]:
                    results[12] = _r(12, action="Yes", reason=scr["listeners_detail"])
                    _add_fail(_tname(12), slbl, scr["listeners_detail"])
                else:
                    results[12] = _r(12, value="All service listeners running")

            if role in role_wu and scr.get("win_update_status") is not None:
                tid = role_wu[role]
                if scr["win_update_action"]:
                    results[tid] = _r(tid, action="Yes", reason=scr["win_update_status"])
                    _add_fail(_tname(tid), slbl, scr["win_update_status"])
                else:
                    results[tid] = _r(tid, value=scr["win_update_status"])

            if role in role_disk and scr.get("disk_space_detail") is not None:
                tid = role_disk[role]
                if scr["disk_space_action"]:
                    results[tid] = _r(tid, action="Yes", reason=scr["disk_space_detail"])
                    _add_fail(_tname(tid), slbl, scr["disk_space_detail"])
                else:
                    results[tid] = _r(tid, value=scr["disk_space_detail"])

            if role in role_sched and scr.get("task_scheduler_detail") is not None:
                tid = role_sched[role]
                if scr["task_scheduler_action"]:
                    results[tid] = _r(tid, action="Yes", reason=scr["task_scheduler_detail"])
                    _add_fail(_tname(tid), slbl, scr["task_scheduler_detail"])
                else:
                    results[tid] = _r(tid, value=scr["task_scheduler_detail"])

        conn_m  = {"Argus": 15, "FMW": 16}
        schema_m = {"Argus": 17, "FMW": 18}
        ts_m    = {"Argus": 19, "FMW": 20}
        dname_m = {"Argus": 13, "FMW": 14}

        for dcr in self.db.fetch_all(
                "SELECT * FROM db_check_results WHERE env_status_id=%s", (esid,)):
            odb = self.db.fetch_one(
                "SELECT * FROM oracle_databases WHERE id=%s", (dcr["oracle_db_id"],))
            if not odb: continue
            dt   = odb["db_type"]
            dlbl = odb["db_name"]

            results[dname_m.get(dt, 13)] = _r(0, value=odb["db_name"])

            if dt in conn_m:
                tid = conn_m[dt]
                if dcr["connection_ok"]:
                    results[tid] = _r(tid, value="Connection Established")
                else:
                    results[tid] = _r(tid, action="Yes", reason=dcr["connection_status"])
                    _add_fail(_tname(tid), dlbl, dcr["connection_status"])

            if dt in schema_m and dcr.get("schema_password_detail") is not None:
                tid = schema_m[dt]
                if dcr["schema_password_action"]:
                    results[tid] = _r(tid, action="Yes", reason=dcr["schema_password_detail"])
                    _add_fail(_tname(tid), dlbl, dcr["schema_password_detail"])
                else:
                    results[tid] = _r(tid, value="No expiry issues")

            if dt in ts_m and dcr.get("tablespace_detail") is not None:
                tid = ts_m[dt]
                if dcr["tablespace_action"]:
                    results[tid] = _r(tid, action="Yes", reason=dcr["tablespace_detail"])
                    _add_fail(_tname(tid), dlbl, dcr["tablespace_detail"])
                else:
                    results[tid] = _r(tid, value="Table space adequate")

            if dt == "Argus":
                def _db_chk(tid, flag, ok_val, detail_key):
                    d = dcr.get(detail_key) or ""
                    if dcr.get(flag):
                        results[tid] = _r(tid, action="Yes", reason=d)
                        _add_fail(_tname(tid), dlbl, d)
                    elif d:
                        results[tid] = _r(tid, value=d)
                    else:
                        results[tid] = _r(tid, value=ok_val)

                if dcr.get("archive_mode") is not None:
                    _db_chk(21, "archive_mode_action", dcr.get("archive_mode", ""), "archive_mode")
                if dcr.get("archive_path_detail") is not None:
                    _db_chk(22, "archive_path_action", "Archive path OK", "archive_path_detail")
                if dcr.get("archive_log_detail") is not None:
                    _db_chk(23, "archive_log_action",  dcr.get("archive_log_detail", ""), "archive_log_detail")
                if dcr.get("rman_detail") is not None:
                    _db_chk(24, "rman_action", "Backup Completed", "rman_detail")

        return results, failures

    # ================================================================== #
    # FAILURES SHEET
    # ================================================================== #

    def _write_failures_sheet(self, failures: List[Dict]):
        ws = self.wb.create_sheet("Failures")
        headers = ["No", "Test Name", "Environment", "Server / DB",
                   "Action Required", "Failure Reason"]
        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=1, column=ci, value=h)
            c.font = _BW; c.fill = _BH
            ws.column_dimensions[get_column_letter(ci)].width = (
                5 if ci == 1 else 40 if ci in (2, 6) else 18)
        ws.freeze_panes = "A2"

        seen: Set[tuple] = set()
        rn = 2
        for f in failures:
            key = (f.get("test_name", ""), f.get("reason", ""))
            if key in seen: continue
            seen.add(key)
            ws.cell(row=rn, column=1, value=rn - 1)
            ws.cell(row=rn, column=2, value=f.get("test_name", ""))
            ws.cell(row=rn, column=3, value=f.get("env_label", ""))
            ws.cell(row=rn, column=4, value=f.get("server_db", ""))
            c = ws.cell(row=rn, column=5, value="Yes")
            c.font = _BR
            ws.cell(row=rn, column=6, value=f.get("reason", ""))
            for ci in range(1, 7):
                ws.cell(row=rn, column=ci).fill = _R
            rn += 1
        self.logger.debug(f"Failures sheet: {rn - 2} unique failure(s)")

    # ================================================================== #
    # TABLESPACE SHEETS  — ALWAYS created, even when empty
    # ================================================================== #

    def _write_tablespace_sheets(self, env_status: Dict):
        """
        Create a tablespace sheet for every Argus Oracle DB in this env.
        Sheet is created even if tablespace_usage has no rows for this check.
        """
        db_checks = self.db.fetch_all(
            "SELECT * FROM db_check_results WHERE env_status_id=%s", (env_status["id"],))

        for dcr in db_checks:
            odb = self.db.fetch_one(
                "SELECT * FROM oracle_databases WHERE id=%s", (dcr["oracle_db_id"],))
            if not odb:
                continue

            elbl = ENV_LABELS.get(env_status["env_type"], env_status["env_type"])
            sheet_name = f"{elbl[:10]} - {odb['db_type']} - TS"[:31]

            rows = self.db.fetch_all(
                """SELECT tablespace_name, used_space_kb, total_space_kb, used_pct
                   FROM tablespace_usage
                   WHERE db_check_id=%s ORDER BY used_pct DESC""",
                (dcr["id"],))

            data = [(r["tablespace_name"], r["used_space_kb"],
                     r["total_space_kb"], r["used_pct"]) for r in rows]

            self._write_detail_sheet(
                sheet_name,
                ["Tablespace Name", "Used (KB)", "Total (KB)", "Used %"],
                data,
                empty_message="No tablespace data available for this run.")
            self.logger.debug(
                f"Tablespace sheet '{sheet_name}': {len(data)} row(s)")

    # ================================================================== #
    # RMAN SHEETS — ALWAYS created, even when empty
    # ================================================================== #

    def _write_rman_sheets(self, env_status: Dict):
        """
        Create an RMAN sheet for every Argus Oracle DB in this env.
        Sheet is created even if rman_backup_details has no rows.
        """
        db_checks = self.db.fetch_all(
            "SELECT * FROM db_check_results WHERE env_status_id=%s", (env_status["id"],))

        for dcr in db_checks:
            odb = self.db.fetch_one(
                "SELECT * FROM oracle_databases WHERE id=%s", (dcr["oracle_db_id"],))
            if not odb or odb["db_type"] == "FMW":
                continue

            elbl = ENV_LABELS.get(env_status["env_type"], env_status["env_type"])
            sheet_name = f"{elbl[:10]} - {odb['db_type']} - RMAN"[:31]

            rows = self.db.fetch_all(
                """SELECT start_time, end_time, output_device_type,
                          backup_type, time_taken_display, status
                   FROM rman_backup_details WHERE db_check_id=%s""",
                (dcr["id"],))

            data = [(r["start_time"], r["end_time"], r["output_device_type"],
                     r["backup_type"], r["time_taken_display"], r["status"])
                    for r in rows]

            self._write_detail_sheet(
                sheet_name,
                ["Start Time", "End Time", "Device Type",
                 "Backup Type", "Duration", "Status"],
                data,
                empty_message="No RMAN backup data found for today. Backup may not have run.")
            self.logger.debug(
                f"RMAN sheet '{sheet_name}': {len(data)} row(s)")

    # ================================================================== #
    # DETAIL SHEET HELPER — supports empty state message
    # ================================================================== #

    def _write_detail_sheet(self, name: str, headers: List[str],
                             rows: List[tuple],
                             empty_message: str = "No data available."):
        ws = self.wb.create_sheet(name)

        # Headers
        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=1, column=ci, value=h)
            c.font = _BW; c.fill = _BH
            ws.column_dimensions[get_column_letter(ci)].width = 22
        ws.freeze_panes = "A2"

        if rows:
            for ri, row in enumerate(rows, 2):
                for ci, v in enumerate(row, 1):
                    ws.cell(row=ri, column=ci, value=v)
        else:
            # Always show at least a message row so sheet isn't blank
            c = ws.cell(row=2, column=1, value=empty_message)
            c.font = Font(italic=True, color="888888")
            ws.merge_cells(start_row=2, start_column=1,
                           end_row=2, end_column=len(headers))

    # ================================================================== #
    # HELPERS
    # ================================================================== #

    def _any_action_required(self, customer_id: int) -> bool:
        r1 = self.db.fetch_one(
            """SELECT COUNT(*) AS cnt FROM server_check_results scr
               JOIN env_run_status ers ON ers.id=scr.env_status_id
               WHERE ers.run_id=%s AND ers.customer_id=%s
               AND (scr.connection_ok=0 OR scr.win_update_action=1
                    OR scr.task_scheduler_action=1 OR scr.listeners_action=1
                    OR scr.disk_space_action=1)""",
            (self.run_id, customer_id))
        if r1 and r1["cnt"]:
            return True
        r2 = self.db.fetch_one(
            """SELECT COUNT(*) AS cnt FROM db_check_results dcr
               JOIN env_run_status ers ON ers.id=dcr.env_status_id
               WHERE ers.run_id=%s AND ers.customer_id=%s
               AND (dcr.connection_ok=0 OR dcr.schema_password_action=1
                    OR dcr.tablespace_action=1 OR dcr.archive_mode_action=1
                    OR dcr.archive_log_action=1 OR dcr.archive_path_action=1
                    OR dcr.rman_action=1)""",
            (self.run_id, customer_id))
        return bool(r2 and r2["cnt"])

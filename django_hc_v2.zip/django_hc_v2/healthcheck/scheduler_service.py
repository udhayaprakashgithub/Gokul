"""
healthcheck/scheduler_service.py  (fixed)
==========================================
APScheduler wrapper. All engine imports go through engine_bridge.

Fixes:
  - No more 'No module named engine' — uses engine_bridge
  - DB config synced from Django settings automatically
  - Live status includes running thread count
  - Async: up to 20 simultaneous cron jobs in ThreadPool
"""
import logging
import threading
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger("hc.scheduler")

_scheduler = None
_scheduler_lock = threading.Lock()
_active_runs: dict = {}          # run_id -> thread name (for live status)
_active_runs_lock = threading.Lock()


# ──────────────────────────────────────────────────────────────
# Job function (runs in background thread)
# ──────────────────────────────────────────────────────────────

def _execute_run(run_id: int, label: str):
    """Execute one HC run in a background thread."""
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()

    with _active_runs_lock:
        _active_runs[run_id] = label
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()
        final = _get_run_status(run_id)
        logger.info(f"[Scheduler] Run #{run_id} ({label}) → {final}")
    except Exception as exc:
        logger.error(f"[Scheduler] Run #{run_id} error: {exc}", exc_info=True)
    finally:
        with _active_runs_lock:
            _active_runs.pop(run_id, None)


def _get_run_status(run_id: int) -> str:
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        with eng["DBManager"]() as db:
            row = db.fetch_one(
                "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return row["status"] if row else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def _fire_schedule(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str):
    """Called by APScheduler in a worker thread."""
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()

    label = f"{customer_name}/{env_types}"
    logger.info(f"[Scheduler] Firing '{schedule_name}' | {label}")

    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))
            db.execute("UPDATE schedules SET last_run_at=NOW() WHERE id=%s",
                       (schedule_id,))

        logger.info(f"[Scheduler] Run #{run_id} created for '{schedule_name}'")
        _execute_run(run_id, label)
    except Exception as exc:
        logger.error(f"[Scheduler] Error firing '{schedule_name}': {exc}",
                     exc_info=True)


# ──────────────────────────────────────────────────────────────
# Schedule loading / registration
# ──────────────────────────────────────────────────────────────

def _load_schedules() -> list:
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        with eng["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, c.name AS customer_name
                   FROM schedules s JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


def _register_jobs(scheduler):
    """Remove all sched_* jobs and re-register from DB."""
    from apscheduler.triggers.cron import CronTrigger

    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try:
                job.remove()
            except Exception:
                pass

    schedules = _load_schedules()
    logger.info(f"[Scheduler] Registering {len(schedules)} schedule(s)")

    for s in schedules:
        job_id = f"sched_{s['id']}"
        try:
            parts = s["cron_expression"].strip().split()
            trigger = CronTrigger(
                minute=parts[0] if len(parts) > 0 else "*",
                hour  =parts[1] if len(parts) > 1 else "*",
                day   =parts[2] if len(parts) > 2 else "*",
                month =parts[3] if len(parts) > 3 else "*",
                day_of_week=parts[4] if len(parts) > 4 else "*",
            )
            scheduler.add_job(
                _fire_schedule,
                trigger=trigger,
                id=job_id,
                name=s["schedule_name"],
                args=[s["id"], s["customer_id"], s["env_types"],
                      s["schedule_name"], s["customer_name"]],
                max_instances=1,
                coalesce=True,
                replace_existing=True,
                misfire_grace_time=300,
            )
            logger.info(
                f"  ✓ [{s['id']}] {s['schedule_name']} "
                f"cron={s['cron_expression']}")
        except Exception as exc:
            logger.error(f"  ✗ Failed schedule id={s['id']}: {exc}")


# ──────────────────────────────────────────────────────────────
# Lifecycle
# ──────────────────────────────────────────────────────────────

def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("Scheduler already running")
            return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor

            _scheduler = BackgroundScheduler(
                executors={"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults={"coalesce": True, "max_instances": 1},
                timezone="UTC",
            )
            _register_jobs(_scheduler)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules",
                name="Refresh schedules from DB",
                replace_existing=True,
            )
            _scheduler.start()
            logger.info("APScheduler started (in-memory, ThreadPool x20)")
            return _scheduler
        except ImportError:
            logger.error("APScheduler not installed: pip install apscheduler")
            return None
        except Exception as exc:
            logger.error(f"Failed to start scheduler: {exc}", exc_info=True)
            return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("APScheduler stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """Return full live status dict for dashboard/API."""
    if _scheduler is None or not _scheduler.running:
        return {"running": False, "job_count": 0, "jobs": [],
                "active_runs": [], "active_run_count": 0}

    schedule_jobs = []
    for job in _scheduler.get_jobs():
        if not job.id.startswith("sched_"):
            continue
        nxt = job.next_run_time
        schedule_jobs.append({
            "id":       job.id,
            "name":     job.name,
            "next_run": nxt.strftime("%Y-%m-%d %H:%M:%S UTC") if nxt else "—",
        })

    with _active_runs_lock:
        active = [{"run_id": rid, "label": lbl}
                  for rid, lbl in _active_runs.items()]

    return {
        "running":          True,
        "job_count":        len(schedule_jobs),
        "jobs":             schedule_jobs,
        "active_runs":      active,
        "active_run_count": len(active),
    }


# ──────────────────────────────────────────────────────────────
# Manual run helpers (called from views)
# ──────────────────────────────────────────────────────────────

def run_now_sync(schedule_id: int) -> Optional[int]:
    """Fire a specific schedule immediately. Returns new run_id."""
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                """SELECT s.*,c.name AS cname FROM schedules s
                   JOIN customers c ON c.id=s.customer_id WHERE s.id=%s""",
                (schedule_id,))
            if not s:
                return None
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))

        label = f"{s['cname']}/{s['env_types']}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync error: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """Fire a manual run for customer+env. Returns new run_id."""
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        label = f"{cname}/{env_types}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_customer_now error: {exc}", exc_info=True)
        return None
